import QtQuick
import QtQuick.Layouts

Rectangle {
    id: root
    property string title: ""
    property string value: "0"
    property var themeObj
    property real uiScale: 1.0
    property string fontFamilyName: "Segoe UI"

    radius: Math.round(8 * uiScale)
    color: root.themeObj && root.themeObj.name === "Hello Kitty" ? Qt.rgba(1.0, 0.78, 0.88, 0.68) : root.themeObj.panelSoft
    border.color: root.themeObj.cardBorder
    border.width: 1
    implicitHeight: Math.round(84 * uiScale)

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: Math.round(8 * root.uiScale)
        spacing: Math.round(3 * root.uiScale)

        Text {
            text: root.title
            color: root.themeObj.textMuted
            font.family: root.fontFamilyName
            font.pixelSize: Math.max(10, Math.round(12 * root.uiScale))
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
            Layout.fillWidth: true
        }
        Item { Layout.fillHeight: true }
        Text {
            text: root.value
            color: root.themeObj.text
            font.family: root.fontFamilyName
            font.pixelSize: Math.max(16, Math.round(22 * root.uiScale))
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
            Layout.fillWidth: true
        }
        Item { Layout.fillHeight: true }
    }
}
