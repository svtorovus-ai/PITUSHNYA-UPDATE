@echo off
setlocal
cd /d "%~dp0"

set "AHK_EXE=%~dp0AutoHotkey64.exe"
set "AHK_SCRIPT=%~dp0Signal-skrin.ahk"

if not exist "%AHK_EXE%" exit /b 2
if not exist "%AHK_SCRIPT%" exit /b 3

start "" "%AHK_EXE%" "%AHK_SCRIPT%" %*
exit /b 0