import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window
import "components"

ApplicationWindow {
    id: appWindow
    visible: true
    visibility: Window.Maximized
    width: Number(backend.getConfig("window_w") || 1540)
    height: Number(backend.getConfig("window_h") || 930)
    minimumWidth: 1260
    minimumHeight: 760
    title: backend.titleText
    color: theme.window
    onClosing: function(close) {
        if (backend.forceQuitRequested) {
            close.accepted = true
            return
        }
        close.accepted = false
        if (!closeConfirmPopup.opened)
            closeConfirmPopup.open()
    }

    property int currentPage: {
        const remembered = String(backend.getConfig("remember_tab") || "Головна")
        if (remembered === "Налаштування")
            return 1
        if (remembered === "Інфо")
            return 2
        return 0
    }
    property int themeIndex: backend.themeIndex
    property real uiScale: backend.uiScale
    property int baseFontSize: backend.baseFontSize
    property string uiFontFamily: backend.fontFamily
    property int leftPanelWidth: backend.leftPanelWidth
    property var theme: themes[themeIndex]

    function px(v) { return Math.max(1, Math.round(v * uiScale)); }
    function fs(mult) { return Math.max(10, Math.round(baseFontSize * mult * uiScale)); }
    function isHelloKitty() { return theme && theme.name === "Hello Kitty"; }
    function panelFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.90, 0.96, 0.54) : fallback; }
    function panelAltFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.84, 0.92, 0.48) : fallback; }
    function panelSoftFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.78, 0.88, 0.44) : fallback; }
    function inputFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.94, 0.98, 0.60) : fallback; }
    function switchPage(pageIndex) {
        currentPage = pageIndex
        backend.setConfigValue("remember_tab", pageIndex === 0 ? "Головна" : (pageIndex === 1 ? "Налаштування" : "Інфо"))
    }
    property string dismissedUpdateVersion: ""
    property string lastPromptedUpdateVersion: ""
    function updateAvailableVersion() {
        return String(backend.getConfigString("update_available_version") || "").trim()
    }
    function updateNotesText() {
        const notes = String(backend.getConfigString("update_notes") || "").trim()
        return notes.length > 0 ? notes : "Опис оновлення не приїхав. Можна оновити зараз або відкласти до наступної перевірки."
    }
    function maybeShowUpdatePrompt(force) {
        if (!backend.updateAllowed || backend.firstRunNeeded)
            return
        const version = updateAvailableVersion()
        const url = String(backend.getConfigString("update_download_url") || "").trim()
        if (!version || !url || backend.updateBusy || updatePromptPopup.opened)
            return
        if (!force && (version === dismissedUpdateVersion || version === lastPromptedUpdateVersion))
            return
        lastPromptedUpdateVersion = version
        updatePromptPopup.open()
    }

    readonly property var themes: [
        {
            "name": "Темний OLED",
            "window": "#000000",
            "panel": "#01060b",
            "panelAlt": "#071521",
            "panelSoft": "#10253a",
            "cardBorder": "#1f4f72",
            "text": "#f1f7ff",
            "textMuted": "#b6c6d8",
            "textDim": "#7f95aa",
            "accent": "#53ea74",
            "accent2": "#3f9cff",
            "danger": "#ff8a63",
            "warning": "#f4bc3c",
            "input": "#020913",
            "inputBorder": "#2d5c82",
            "logBg": "#01060b",
            "logBorder": "#1f4f72",
            "hoverFill": "#173550",
            "hoverText": "#ffffff"
        },
        {
            "name": "Молочний графіт",
            "window": "#e9edf2",
            "panel": "#f6f7f9",
            "panelAlt": "#eceff3",
            "panelSoft": "#e3e8ef",
            "cardBorder": "#cfd8e3",
            "text": "#182433",
            "textMuted": "#48596c",
            "textDim": "#6c7d8d",
            "accent": "#2468ad",
            "accent2": "#3f8ff3",
            "danger": "#e85b52",
            "warning": "#c77b1b",
            "input": "#ffffff",
            "inputBorder": "#d1d8e2",
            "logBg": "#ffffff",
            "logBorder": "#cfd8e3",
            "hoverFill": "#d9e2ee",
            "hoverText": "#162332"
        },
        {
            "name": "Рижий монстр",
            "window": "#100804",
            "panel": "#130a05",
            "panelAlt": "#21110a",
            "panelSoft": "#3a1d0f",
            "cardBorder": "#7d3a12",
            "text": "#fff0dc",
            "textMuted": "#deb78c",
            "textDim": "#b98760",
            "accent": "#ff7a1f",
            "accent2": "#ffae3b",
            "danger": "#ff6c4a",
            "warning": "#ffb03b",
            "input": "#170b06",
            "inputBorder": "#7d3a12",
            "logBg": "#090402",
            "logBorder": "#7d3a12",
            "hoverFill": "#4b2411",
            "hoverText": "#fff8ef"
        },
        {
            "name": "Hello Kitty",
            "window": "#ffd8ea",
            "panel": "#ffe4f0",
            "panelAlt": "#ffd7e8",
            "panelSoft": "#ffc3dd",
            "cardBorder": "#ee7eb2",
            "text": "#7a224e",
            "textMuted": "#963767",
            "textDim": "#b05884",
            "accent": "#ff4fa2",
            "accent2": "#ff82bd",
            "danger": "#ff5a7f",
            "warning": "#ff8d52",
            "input": "#fff2f8",
            "inputBorder": "#f39ac3",
            "logBg": "#2e0d1f",
            "logBorder": "#ee7eb2",
            "hoverFill": "#ffb7d4",
            "hoverText": "#6b2047"
        }
    ]

    Connections {
        target: backend
        function onThemeIndexChanged() { appWindow.themeIndex = backend.themeIndex }
        function onUiScaleChanged() { appWindow.uiScale = backend.uiScale }
        function onFontSizeChanged() { appWindow.baseFontSize = backend.baseFontSize }
        function onLeftPanelWidthChanged() { appWindow.leftPanelWidth = backend.leftPanelWidth }
        function onFontFamilyChanged() { appWindow.uiFontFamily = backend.fontFamily }
        function refreshFirstRunUi() {
            pathSignalExe.text = backend.getConfigString("signal_exe") || "%LOCALAPPDATA%\\Programs\\signal-desktop\\Signal.exe"
            if (!backend.getConfigString("signal_exe")) backend.setConfigValue("signal_exe", pathSignalExe.text)
            pathSignalCli.text = backend.getConfigString("signal_cli_bat")
            frCallsign.text = backend.getConfigString("callsign")
        }
        function onFirstRunChanged() {
            refreshFirstRunUi()
            if (backend.firstRunNeeded) {
                if (!firstRunPopup.opened)
                    firstRunPopup.open()
            } else if (firstRunPopup.opened) {
                firstRunPopup.close()
            }
        }
        function onConfigMapChanged() {
            refreshFirstRunUi()
        }
        function onUpdateStateChanged() {
            if (backend.updateAllowed && !backend.firstRunNeeded)
                maybeShowUpdatePrompt(false)
        }
        function onInstructionRequested() {
            if (!instructionPopup.opened)
                instructionPopup.open()
        }
        function onNoUpdateAvailable() {
            if (!noUpdatePopup.opened)
                noUpdatePopup.open()
        }
        function onTargetWizardRequested() {}
    }

    Popup {
        id: statusPopup
        width: Math.min(appWindow.width - appWindow.px(100), appWindow.px(760))
        height: Math.min(appWindow.height - appWindow.px(120), appWindow.px(520))
        x: Math.round((appWindow.width - width) / 2)
        y: Math.round((appWindow.height - height) / 2)
        modal: true
        focus: true
        padding: appWindow.px(16)
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
        background: Rectangle {
            radius: appWindow.px(12)
            color: appWindow.panelFill(theme.panel)
            border.color: theme.cardBorder
            border.width: 1
        }
        contentItem: ColumnLayout {
            spacing: appWindow.px(10)
            Text {
                text: backend.systemStatusText
                color: backend.systemStatusOk ? theme.accent : (backend.systemStatusLevel === "ERROR" ? theme.danger : theme.warning)
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(1.08)
                font.bold: true
            }
            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: appWindow.px(10)
                color: appWindow.inputFill(theme.input)
                border.color: theme.inputBorder
                border.width: 1
                Flickable {
                    anchors.fill: parent
                    anchors.margins: appWindow.px(10)
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    contentWidth: width
                    contentHeight: reasonsText.paintedHeight
                    Text {
                        id: reasonsText
                        width: parent.width
                        text: backend.systemStatusOk ? backend.instructionText : backend.systemStatusReasonsText
                        color: theme.text
                        wrapMode: Text.WordWrap
                        font.family: appWindow.uiFontFamily
                        font.pixelSize: appWindow.fs(0.84)
                        font.bold: true
                    }
                    ScrollBar.vertical: AppScrollBar {
                        themeObj: theme
                        uiScale: appWindow.uiScale
                    }
                }
            }
        }
    }

    Popup {
        id: closeConfirmPopup
        width: Math.min(appWindow.width - appWindow.px(80), appWindow.px(560))
        height: appWindow.px(230)
        x: Math.round((appWindow.width - width) / 2)
        y: Math.round((appWindow.height - height) / 2)
        modal: true
        focus: true
        padding: appWindow.px(16)
        closePolicy: Popup.CloseOnEscape
        background: Rectangle {
            radius: appWindow.px(12)
            color: appWindow.panelFill(theme.panel)
            border.color: theme.cardBorder
            border.width: 1
        }
        contentItem: ColumnLayout {
            spacing: appWindow.px(12)
            Text {
                Layout.fillWidth: true
                text: "Що робимо з PITUSHNYA MCC?"
                color: theme.accent
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(1.18)
                font.bold: true
                wrapMode: Text.WordWrap
            }
            Text {
                Layout.fillWidth: true
                text: "Можна просто згорнути в трей і лишити гарячі клавіші працювати у фоні, або повністю закрити модулі."
                color: theme.text
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(0.86)
                font.bold: true
                wrapMode: Text.WordWrap
            }
            Item { Layout.fillHeight: true }
            RowLayout {
                Layout.fillWidth: true
                spacing: appWindow.px(10)
                ActionButton {
                    Layout.fillWidth: true
                    label: "Згорнути в фон?"
                    fillColor: theme.accent2
                    hoverColor: Qt.lighter(theme.accent2, 1.05)
                    fontSize: appWindow.baseFontSize - 2
                    uiScale: appWindow.uiScale
                    fontFamilyName: appWindow.uiFontFamily
                    onClicked: {
                        closeConfirmPopup.close()
                        backend.minimizeToTray()
                    }
                }
                ActionButton {
                    Layout.fillWidth: true
                    label: "Закрити цю поїботу."
                    fillColor: theme.danger
                    hoverColor: Qt.lighter(theme.danger, 1.05)
                    fontSize: appWindow.baseFontSize - 2
                    uiScale: appWindow.uiScale
                    fontFamilyName: appWindow.uiFontFamily
                    onClicked: {
                        closeConfirmPopup.close()
                        appWindow.hide()
                        backend.quitApplication()
                    }
                }
            }
        }
    }

    Popup {
        id: instructionPopup
        width: Math.min(appWindow.width - appWindow.px(120), appWindow.px(820))
        height: Math.min(appWindow.height - appWindow.px(140), appWindow.px(520))
        x: Math.round((appWindow.width - width) / 2)
        y: Math.round((appWindow.height - height) / 2)
        modal: false
        focus: true
        padding: appWindow.px(16)
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

        background: Rectangle {
            radius: appWindow.px(14)
            color: appWindow.panelFill(theme.panel)
            border.color: theme.accent2
            border.width: 1
        }

        contentItem: ColumnLayout {
            spacing: appWindow.px(10)

            RowLayout {
                Layout.fillWidth: true
                spacing: appWindow.px(10)

                Text {
                    Layout.fillWidth: true
                    text: "Пітушня готова до роботи"
                    color: theme.accent
                    font.family: appWindow.uiFontFamily
                    font.pixelSize: appWindow.fs(1.12)
                    font.bold: true
                    wrapMode: Text.WordWrap
                }

                ActionButton {
                    Layout.preferredWidth: appWindow.px(120)
                    label: "➕➕"
                    fillColor: theme.warning
                    hoverColor: Qt.lighter(theme.warning, 1.08)
                    textColor: "#111111"
                    hoverTextColor: "#000000"
                    fontSize: appWindow.baseFontSize - 2
                    uiScale: appWindow.uiScale
                    fontFamilyName: appWindow.uiFontFamily
                    onClicked: instructionPopup.close()
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: appWindow.px(10)
                color: appWindow.inputFill(theme.input)
                border.color: theme.inputBorder
                border.width: 1

                Flickable {
                    anchors.fill: parent
                    anchors.margins: appWindow.px(12)
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    contentWidth: width
                    contentHeight: instructionText.paintedHeight

                    Text {
                        id: instructionText
                        width: parent.width
                        text: backend.instructionText
                        color: theme.text
                        wrapMode: Text.WordWrap
                        font.family: appWindow.uiFontFamily
                        font.pixelSize: appWindow.fs(0.9)
                        font.bold: true
                        lineHeight: 1.16
                    }

                    ScrollBar.vertical: AppScrollBar {
                        themeObj: theme
                        uiScale: appWindow.uiScale
                    }
                }
            }
        }
    }
    Popup {
        id: noUpdatePopup
        width: Math.min(appWindow.width - appWindow.px(80), appWindow.px(520))
        height: appWindow.px(230)
        x: Math.round((appWindow.width - width) / 2)
        y: Math.round((appWindow.height - height) / 2)
        modal: true
        focus: true
        padding: appWindow.px(16)
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

        background: Rectangle {
            radius: appWindow.px(12)
            color: appWindow.panelFill(theme.panel)
            border.color: theme.cardBorder
            border.width: 1
        }

        contentItem: ColumnLayout {
            spacing: appWindow.px(12)

            Text {
                Layout.fillWidth: true
                text: "Дядя, в тебе і так вже остання актуальна версія"
                color: theme.accent
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(1.08)
                font.bold: true
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
            }

            Text {
                Layout.fillWidth: true
                text: "Не переживай- я якщо що маякну"
                color: theme.text
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(0.92)
                font.bold: true
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
            }

            Item { Layout.fillHeight: true }

            ActionButton {
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredWidth: appWindow.px(140)
                label: "➕➕"
                fillColor: theme.warning
                hoverColor: Qt.lighter(theme.warning, 1.08)
                textColor: "#111111"
                hoverTextColor: "#000000"
                fontSize: appWindow.baseFontSize
                uiScale: appWindow.uiScale
                fontFamilyName: appWindow.uiFontFamily
                onClicked: noUpdatePopup.close()
            }
        }
    }
    Popup {
        id: updatePromptPopup
        width: Math.min(appWindow.width - appWindow.px(80), appWindow.px(660))
        height: Math.min(appWindow.height - appWindow.px(120), appWindow.px(430))
        x: Math.round((appWindow.width - width) / 2)
        y: Math.round((appWindow.height - height) / 2)
        modal: true
        focus: true
        padding: appWindow.px(16)
        closePolicy: Popup.CloseOnEscape

        background: Rectangle {
            radius: appWindow.px(12)
            color: appWindow.panelFill(theme.panel)
            border.color: theme.cardBorder
            border.width: 1
        }

        contentItem: ColumnLayout {
            spacing: appWindow.px(12)

            Text {
                Layout.fillWidth: true
                text: "Є нова версія: " + appWindow.updateAvailableVersion()
                color: theme.accent
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(1.15)
                font.bold: true
                wrapMode: Text.WordWrap
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: appWindow.px(10)
                color: appWindow.inputFill(theme.input)
                border.color: theme.inputBorder
                border.width: 1

                Flickable {
                    anchors.fill: parent
                    anchors.margins: appWindow.px(10)
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    contentWidth: width
                    contentHeight: updateNotes.paintedHeight

                    Text {
                        id: updateNotes
                        width: parent.width
                        text: appWindow.updateNotesText()
                        color: theme.text
                        wrapMode: Text.WordWrap
                        font.family: appWindow.uiFontFamily
                        font.pixelSize: appWindow.fs(0.9)
                        font.bold: true
                    }

                    ScrollBar.vertical: AppScrollBar {
                        themeObj: theme
                        uiScale: appWindow.uiScale
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: appWindow.px(10)

                Item { Layout.fillWidth: true }

                ActionButton {
                    Layout.preferredWidth: appWindow.px(210)
                    label: "Забити хуй до потім"
                    fillColor: appWindow.panelSoftFill(theme.panelSoft)
                    hoverColor: theme.hoverFill
                    textColor: theme.text
                    hoverTextColor: theme.hoverText
                    fontSize: appWindow.baseFontSize - 2
                    uiScale: appWindow.uiScale
                    fontFamilyName: appWindow.uiFontFamily
                    onClicked: {
                        appWindow.dismissedUpdateVersion = appWindow.updateAvailableVersion()
                        updatePromptPopup.close()
                    }
                }

                ActionButton {
                    Layout.preferredWidth: appWindow.px(180)
                    label: "Оновити зараз"
                    fillColor: theme.accent
                    hoverColor: Qt.lighter(theme.accent, 1.04)
                    textColor: "#ffffff"
                    hoverTextColor: "#ffffff"
                    fontSize: appWindow.baseFontSize - 2
                    uiScale: appWindow.uiScale
                    fontFamilyName: appWindow.uiFontFamily
                    onClicked: {
                        updatePromptPopup.close()
                        backend.runUpdater()
                    }
                }
            }
        }
    }
    Popup {
        id: firstRunPopup
        width: Math.min(appWindow.width - appWindow.px(64), appWindow.px(1040))
        height: Math.min(appWindow.height - appWindow.px(64), appWindow.px(820))
        x: Math.round((appWindow.width - width) / 2)
        y: Math.round((appWindow.height - height) / 2)
        modal: true
        focus: true
        padding: appWindow.px(18)
        closePolicy: Popup.NoAutoClose
        background: Rectangle {
            radius: appWindow.px(14)
            color: appWindow.panelFill(theme.panel)
            border.color: theme.cardBorder
            border.width: 1
        }
        onOpened: {
            pathSignalExe.text = backend.getConfigString("signal_exe") || "%LOCALAPPDATA%\\Programs\\signal-desktop\\Signal.exe"
            if (!backend.getConfigString("signal_exe")) backend.setConfigValue("signal_exe", pathSignalExe.text)
            pathSignalCli.text = backend.getConfigString("signal_cli_bat")
            frCallsign.text = backend.getConfigString("callsign")
        }
        contentItem: Flickable {
            id: firstRunFlick
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            contentWidth: width
            contentHeight: firstRunColumn.implicitHeight

            ColumnLayout {
                id: firstRunColumn
                width: firstRunFlick.width
                spacing: appWindow.px(12)
            Text {
                text: "Перший запуск"
                color: theme.text
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(1.34)
                font.bold: true
            }
            Text {
                Layout.fillWidth: true
                text: "Це одноразова підготовка. Тут програма перевіряє Signal, signal-cli, позивний і службові шляхи, щоб потім не питати це під час роботи з цілями."
                wrapMode: Text.WordWrap
                color: theme.textMuted
                font.family: appWindow.uiFontFamily
                font.pixelSize: appWindow.fs(0.98)
                font.bold: true
            }
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: appWindow.px(154)
                radius: appWindow.px(10)
                color: appWindow.panelAltFill(theme.panelAlt)
                border.color: theme.cardBorder
                border.width: 1
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: appWindow.px(12)
                    spacing: appWindow.px(4)
                    Text { text: "1. Шлях до Signal підставляється автоматично, якщо клієнт стоїть у стандартному місці."; color: theme.text; font.family: appWindow.uiFontFamily; font.pixelSize: appWindow.fs(0.86); font.bold: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Text { text: "2. «QR прив'язка» відкриває signal-cli link. Скануєш код телефоном у Signal і чекаєш, поки акаунт підтягнеться автоматично."; color: theme.text; font.family: appWindow.uiFontFamily; font.pixelSize: appWindow.fs(0.86); font.bold: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Text { text: "3. Позивний піде у фіксацію часу, майстер цілі й готове повідомлення. Краще вписати його одразу нормально."; color: theme.text; font.family: appWindow.uiFontFamily; font.pixelSize: appWindow.fs(0.86); font.bold: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    Text { text: "4. Після завершення стартове вікно більше не вилізе, а робочий процес піде через головну вкладку."; color: theme.text; font.family: appWindow.uiFontFamily; font.pixelSize: appWindow.fs(0.86); font.bold: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                }
            }
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: appWindow.px(142)
                radius: appWindow.px(10)
                color: appWindow.panelAltFill(theme.panelAlt)
                border.color: theme.cardBorder
                border.width: 1
                Flickable {
                    anchors.fill: parent
                    anchors.margins: appWindow.px(10)
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    contentWidth: width
                    contentHeight: statusText.paintedHeight
                    Text {
                        id: statusText
                        width: parent.width
                        text: backend.firstRunStatusText
                        wrapMode: Text.WordWrap
                        color: theme.text
                        font.family: appWindow.uiFontFamily
                        font.pixelSize: appWindow.fs(0.96)
                        font.bold: true
                    }
                }
            }
            GridLayout {
                Layout.fillWidth: true
                columns: 2
                rowSpacing: appWindow.px(8)
                columnSpacing: appWindow.px(10)
                Text { text: "Позивний / назва екіпажу"; color: theme.textMuted; font.family: appWindow.uiFontFamily; font.pixelSize: appWindow.fs(0.82); font.bold: true }
                TextField {
                    id: frCallsign
                    text: backend.configMap["callsign"] || ""
                    Layout.fillWidth: true
                    color: theme.text
                    font.family: appWindow.uiFontFamily
                    font.pixelSize: appWindow.fs(0.82)
                    font.bold: true
                    padding: appWindow.px(10)
                    onTextChanged: backend.setConfigValue("callsign", text)
                    background: Rectangle { radius: appWindow.px(8); color: appWindow.inputFill(theme.input); border.color: theme.inputBorder; border.width: 1 }
                }
                Text { text: "Signal.exe"; color: theme.textMuted; font.family: appWindow.uiFontFamily; font.pixelSize: appWindow.fs(0.82); font.bold: true }
                TextField {
                    id: pathSignalExe
                    Layout.fillWidth: true
                    readOnly: true
                    color: theme.text
                    font.family: appWindow.uiFontFamily
                    font.pixelSize: appWindow.fs(0.82)
                    font.bold: true
                    padding: appWindow.px(10)
                    background: Rectangle { radius: appWindow.px(8); color: appWindow.inputFill(theme.input); border.color: theme.inputBorder; border.width: 1 }
                }
                Text { text: "signal-cli.bat"; color: theme.textMuted; font.family: appWindow.uiFontFamily; font.pixelSize: appWindow.fs(0.82); font.bold: true }
                TextField {
                    id: pathSignalCli
                    Layout.fillWidth: true
                    readOnly: true
                    color: theme.text
                    font.family: appWindow.uiFontFamily
                    font.pixelSize: appWindow.fs(0.82)
                    font.bold: true
                    padding: appWindow.px(10)
                    background: Rectangle { radius: appWindow.px(8); color: appWindow.inputFill(theme.input); border.color: theme.inputBorder; border.width: 1 }
                }
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: appWindow.px(8)
                ActionButton {
                    Layout.preferredWidth: appWindow.px(180)
                    label: "QR прив'язка"
                    fillColor: theme.accent2
                    hoverColor: Qt.lighter(theme.accent2, 1.03)
                    fontSize: appWindow.baseFontSize - 2
                    uiScale: appWindow.uiScale
                    fontFamilyName: appWindow.uiFontFamily
                    enabled: backend.firstRunCallsignReady
                    opacity: enabled ? 1.0 : 0.45
                    onClicked: backend.startSignalLink()
                }
                Item { Layout.fillWidth: true }
                ActionButton {
                    Layout.preferredWidth: appWindow.px(210)
                    label: "Завершити перший запуск"
                    enabled: backend.firstRunCanComplete
                    fillColor: theme.warning
                    hoverColor: Qt.lighter(theme.warning, 1.03)
                    fontSize: appWindow.baseFontSize - 2
                    uiScale: appWindow.uiScale
                    fontFamilyName: appWindow.uiFontFamily
                    onClicked: {
                        if (backend.completeFirstRun())
                            firstRunPopup.close()
                    }
                }
            }
        }
        }
    }



    Component.onCompleted: {
        appWindow.visibility = Window.Maximized
        if (backend.firstRunNeeded)
            firstRunPopup.open()
        else if (backend.getConfigBool("auto_start_on_launch"))
            Qt.callLater(backend.startAll)
    }

    Rectangle {
        anchors.fill: parent
        color: theme.window

        Image {
            anchors.fill: parent
            visible: theme.name === "Hello Kitty"
            source: backend.helloKittySource
            fillMode: Image.Tile
            opacity: 0.38
            asynchronous: true
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: appWindow.px(8)
            spacing: appWindow.px(8)

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: appWindow.px(56)
                radius: appWindow.px(10)
                color: appWindow.panelFill(theme.panel)
                border.color: theme.cardBorder
                border.width: 1

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: appWindow.px(6)
                    spacing: appWindow.px(8)

                    ActionButton {
                        Layout.preferredWidth: appWindow.px(114)
                        label: "Головна"
                        fillColor: appWindow.currentPage === 0 ? theme.accent2 : appWindow.panelSoftFill(theme.panelSoft)
                        hoverColor: appWindow.currentPage === 0 ? Qt.lighter(theme.accent2, 1.03) : theme.hoverFill
                        textColor: appWindow.currentPage === 0 ? "#ffffff" : theme.text
                        hoverTextColor: appWindow.currentPage === 0 ? "#ffffff" : theme.hoverText
                        fontSize: appWindow.baseFontSize - 2
                        uiScale: appWindow.uiScale
                        fontFamilyName: appWindow.uiFontFamily
                        onClicked: appWindow.switchPage(0)
                    }
                    ActionButton {
                        Layout.preferredWidth: appWindow.px(156)
                        label: "Налаштування"
                        fillColor: appWindow.currentPage === 1 ? theme.accent : appWindow.panelSoftFill(theme.panelSoft)
                        hoverColor: appWindow.currentPage === 1 ? Qt.lighter(theme.accent, 1.03) : theme.hoverFill
                        textColor: appWindow.currentPage === 1 ? "#ffffff" : theme.text
                        hoverTextColor: appWindow.currentPage === 1 ? "#ffffff" : theme.hoverText
                        fontSize: appWindow.baseFontSize - 2
                        uiScale: appWindow.uiScale
                        fontFamilyName: appWindow.uiFontFamily
                        onClicked: appWindow.switchPage(1)
                    }
                    ActionButton {
                        Layout.preferredWidth: appWindow.px(112)
                        label: "Інфо"
                        fillColor: appWindow.currentPage === 2 ? theme.accent : appWindow.panelSoftFill(theme.panelSoft)
                        hoverColor: appWindow.currentPage === 2 ? Qt.lighter(theme.accent, 1.03) : theme.hoverFill
                        textColor: appWindow.currentPage === 2 ? "#ffffff" : theme.text
                        hoverTextColor: appWindow.currentPage === 2 ? "#ffffff" : theme.hoverText
                        fontSize: appWindow.baseFontSize - 2
                        uiScale: appWindow.uiScale
                        fontFamilyName: appWindow.uiFontFamily
                        onClicked: appWindow.switchPage(2)
                    }
                    Item { Layout.fillWidth: true }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: appWindow.px(56)
                radius: appWindow.px(10)
                color: appWindow.panelFill(theme.panel)
                border.color: theme.cardBorder
                border.width: 1
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: appWindow.px(10)
                    anchors.rightMargin: appWindow.px(10)
                    spacing: appWindow.px(8)

                    Repeater {
                        model: backend.statusList
                        delegate: StatusPill {
                            label: modelData.name + ": " + (modelData.ok ? "OK" : "OFF")
                            hint: modelData.ok ? (modelData.name + " зараз живий") : (modelData.name + " зараз не відповідає")
                            ok: modelData.ok
                            themeObj: theme
                            uiScale: appWindow.uiScale
                            fontFamilyName: appWindow.uiFontFamily
                        }
                    }

                    Rectangle { Layout.preferredWidth: 1; Layout.fillHeight: true; color: theme.cardBorder }
                    Text {
                        text: "Оновлено: " + backend.lastUpdateText
                        color: theme.textMuted
                        font.family: appWindow.uiFontFamily
                        font.pixelSize: appWindow.fs(0.78)
                        font.bold: true
                    }
                    Text {
                        Layout.fillWidth: true
                        text: "Попередня ціль: " + backend.prevTargetHeader
                        color: theme.textMuted
                        font.family: appWindow.uiFontFamily
                        font.pixelSize: appWindow.fs(0.78)
                        font.bold: true
                        elide: Text.ElideRight
                    }
                    ActionButton {
                        Layout.preferredWidth: Math.max(appWindow.px(176), implicitWidth)
                        label: backend.systemStatusText
                        fillColor: backend.systemStatusOk ? theme.accent : (backend.systemStatusLevel === "ERROR" ? theme.danger : theme.warning)
                        hoverColor: backend.systemStatusOk ? Qt.lighter(theme.accent, 1.03) : (backend.systemStatusLevel === "ERROR" ? Qt.lighter(theme.danger, 1.03) : Qt.lighter(theme.warning, 1.03))
                        fontSize: appWindow.baseFontSize - 3
                        uiScale: appWindow.uiScale
                        fontFamilyName: appWindow.uiFontFamily
                        onClicked: statusPopup.open()
                    }
                }
            }

            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                HomePage {
                previewMode: settingsPage.previewAppearanceActive
                    id: homePage
                    anchors.fill: parent
                    visible: appWindow.currentPage === 0 || settingsPage.previewAppearanceActive
                    z: 1
                    themeObj: appWindow.theme
                    leftPanelWidth: appWindow.leftPanelWidth
                    uiScale: appWindow.uiScale
                    baseFontSize: appWindow.baseFontSize
                    fontFamilyName: appWindow.uiFontFamily
                }

                SettingsPage {
                    id: settingsPage
                    anchors.fill: parent
                    visible: appWindow.currentPage === 1
                    opacity: previewAppearanceActive ? 0.05 : 1.0
                    z: 2
                    themeObj: appWindow.theme
                    uiScale: appWindow.uiScale
                    baseFontSize: appWindow.baseFontSize
                    fontFamilyName: appWindow.uiFontFamily
                    leftPanelWidth: appWindow.leftPanelWidth
                }

                InfoPage {
                    id: infoPage
                    anchors.fill: parent
                    visible: appWindow.currentPage === 2
                    z: 2
                    themeObj: appWindow.theme
                    uiScale: appWindow.uiScale
                    baseFontSize: appWindow.baseFontSize
                    fontFamilyName: appWindow.uiFontFamily
                }
            }
        }
    }
}
