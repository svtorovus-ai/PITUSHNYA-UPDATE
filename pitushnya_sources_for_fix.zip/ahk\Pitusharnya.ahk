﻿#Requires AutoHotkey v2.0
#SingleInstance Force

CoordMode "Mouse", "Client"

baseDir := RegExReplace(A_ScriptDir, "\\ahk$")
dataDir := baseDir "\data"

DirCreate dataDir

stateFile := dataDir "\delta_state.ini"
readyFile := dataDir "\delta_ready.txt"
callsignFile := dataDir "\callsign.txt"
templateTimeFile := dataDir "\message_template_time_fix.txt"
runtimeProfileFile := dataDir "\runtime_profile.json"
forceWizardFile := dataDir "\force_target_wizard.txt"
signalExe := ""

if !FileExist(stateFile)
    FileAppend "[delta]`nstatus=idle`ntime=`ncycle_id=", stateFile, "UTF-8"

if !FileExist(readyFile)
    FileAppend "", readyFile, "UTF-8"

if !FileExist(forceWizardFile)
    FileAppend "", forceWizardFile, "UTF-8"

if !FileExist(callsignFile)
    FileAppend "екіпаж", callsignFile, "UTF-8"

if !FileExist(templateTimeFile)
    FileAppend "Ціль- підар, виявлено: ({time})", templateTimeFile, "UTF-8"

readyBaselineTime := ""
lastHandledReadyTime := ""
lastAutoRaw := ""

SetTimer AutoInsertReady, 400

ReadReadyRaw() {
    global readyFile

    if !FileExist(readyFile)
        return ""

    return Trim(FileRead(readyFile, "UTF-8"))
}

GetReadyFileTime() {
    global readyFile

    if !FileExist(readyFile)
        return ""

    return FileGetTime(readyFile, "M")
}

GetStatus() {
    global stateFile

    try
        return IniRead(stateFile, "delta", "status", "")
    catch
        return ""
}

SetStatus(status) {
    global stateFile
    try IniWrite status, stateFile, "delta", "status"
}

GetDetectTime() {
    global stateFile

    try
        return IniRead(stateFile, "delta", "time", "")
    catch
        return ""
}

ReadRuntimeProfileValue(key, fallback := "") {
    global runtimeProfileFile

    try {
        if FileExist(runtimeProfileFile) {
            raw := FileRead(runtimeProfileFile, "UTF-8")
            quote := Chr(34)
            pattern := quote key quote "\s*:\s*" quote "([^" quote "]*)" quote

            if RegExMatch(raw, pattern, &m) {
                value := m[1]
                value := StrReplace(value, "\\", "\")
                value := StrReplace(value, "\/", "/")
                return Trim(value)
            }
        }
    }
    catch {
    }

    return fallback
}

ResolveSignalExe() {
    configured := ReadRuntimeProfileValue("signal_exe", "")
    candidates := []
    localAppData := EnvGet("LocalAppData")
    roamingAppData := EnvGet("AppData")

    if (configured != "")
        candidates.Push(configured)

    if (localAppData != "")
        candidates.Push(localAppData "\Programs\signal-desktop\Signal.exe")

    if (roamingAppData != "")
        candidates.Push(roamingAppData "\Programs\signal-desktop\Signal.exe")

    for candidate in candidates {
        if (candidate != "" && FileExist(candidate))
            return candidate
    }

    return configured
}

WriteForceWizardRequest() {
    global forceWizardFile

    try FileDelete forceWizardFile
    try FileAppend A_Now, forceWizardFile, "UTF-8"
}

ApplyDetectTime(text) {
    detectTime := GetDetectTime()

    if (text = "")
        return ""

    if (detectTime != "") {
        if RegExMatch(text, "^\d{2}:\d{2}\s")
            text := RegExReplace(text, "^\d{2}:\d{2}", detectTime)
        else
            text := detectTime " " text
    }

    return text
}

ActivateSignal() {
    global signalExe

    if WinExist("ahk_exe Signal.exe") {
        try {
            if (WinGetMinMax("ahk_exe Signal.exe") = -1)
                WinRestore "ahk_exe Signal.exe"
        }

        try WinShow "ahk_exe Signal.exe"
        try WinActivate "ahk_exe Signal.exe"
    } else {
        signalExe := ResolveSignalExe()

        if (signalExe = "" || !FileExist(signalExe))
            return false

        Run signalExe
        Sleep 700
    }

    Loop 28 {
        hwnd := 0

        try hwnd := WinGetID("ahk_exe Signal.exe")

        if hwnd {
            try {
                if (WinGetMinMax("ahk_id " hwnd) = -1)
                    WinRestore "ahk_id " hwnd
            }

            try WinShow "ahk_id " hwnd
            try WinActivate "ahk_id " hwnd
            try DllCall("SetForegroundWindow", "ptr", hwnd)
            try DllCall("BringWindowToTop", "ptr", hwnd)

            if WinWaitActive("ahk_id " hwnd,, 0.35)
                return true
        }

        Sleep 120
    }

    return false
}

FocusSignalInput() {
    hwnd := WinGetID("ahk_exe Signal.exe")

    if !hwnd
        return false

    WinActivate "ahk_id " hwnd
    WinWaitActive "ahk_id " hwnd,, 1

    WinGetClientPos &cx, &cy, &cw, &ch, "ahk_id " hwnd

    px := Floor(cw * 0.58)
    leftSafe := Max(180, Floor(cw * 0.22))
    rightSafe := cw - Max(160, Floor(cw * 0.16))

    if (px < leftSafe)
        px := leftSafe

    if (px > rightSafe)
        px := rightSafe

    if (px < 80)
        px := Min(cw - 80, 80)

    py := ch - Max(32, Floor(ch * 0.038))

    if (px < 20 || py < 20)
        return false

    CoordMode "Mouse", "Screen"
    MouseGetPos &oldX, &oldY

    try {
        ControlClick "x" px " y" py, "ahk_id " hwnd, , "Left", 1, "NA"
        Sleep 110
        CoordMode "Mouse", "Client"
        return true
    }
    catch {
        CoordMode "Mouse", "Client"
        Click px, py, 1
        Sleep 80
        CoordMode "Mouse", "Screen"
        MouseMove oldX, oldY, 0
        CoordMode "Mouse", "Client"
        return true
    }
}

ClearInputOnly() {
    Send "^a"
    Sleep 70
    Send "{Backspace}"
    Sleep 80
}

ReplaceSignalDraft(text) {
    if (text = "")
        return false

    if !ActivateSignal()
        return false

    if !FocusSignalInput()
        return false

    ClearInputOnly()

    backupClip := ClipboardAll()
    A_Clipboard := ""
    A_Clipboard := text

    if !ClipWait(2.0) {
        A_Clipboard := backupClip
        return false
    }

    Send "^v"
    Sleep 120
    A_Clipboard := backupClip
    return true
}

AutoInsertReady() {
    global readyBaselineTime, lastHandledReadyTime, lastAutoRaw

    if (GetStatus() != "waiting_coords")
        return

    currentReadyTime := GetReadyFileTime()

    if (currentReadyTime = "")
        return

    if (readyBaselineTime != "" && currentReadyTime = readyBaselineTime)
        return

    if (lastHandledReadyTime != "" && currentReadyTime = lastHandledReadyTime)
        return

    raw := ReadReadyRaw()

    if (raw = "")
        return

    if (raw = lastAutoRaw)
        return

    text := ApplyDetectTime(raw)

    if (text = "")
        return

    if ReplaceSignalDraft(text) {
        lastAutoRaw := raw
        lastHandledReadyTime := currentReadyTime
        SetStatus("coords_applied_auto")
    }
}

^!z::
{
    WriteForceWizardRequest()
}

^!x::
{
    global lastAutoRaw, lastHandledReadyTime

    raw := ReadReadyRaw()

    if (raw = "")
        return

    text := ApplyDetectTime(raw)

    if (text = "")
        return

    if ReplaceSignalDraft(text) {
        lastAutoRaw := raw
        lastHandledReadyTime := GetReadyFileTime()
        SetStatus("coords_applied_manual")
    }
}