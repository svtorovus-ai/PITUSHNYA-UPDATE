import QtQuick

Rectangle {
    id: root
    property string label: ""
    property string hint: ""
    property var themeObj
    property color fillColor: "#22c55e"
    property color hoverColor: Qt.lighter(fillColor, 1.03)
    property color textColor: "#ffffff"
    property color hoverTextColor: textColor
    property color disabledColor: Qt.rgba(0.3, 0.35, 0.42, 0.55)
    property int radiusValue: 8
    property int fontSize: 16
    property real uiScale: 1.0
    property string fontFamilyName: "Segoe UI"
    property bool wrap: false
    signal clicked()

    implicitHeight: Math.round(42 * uiScale)
    implicitWidth: labelText.implicitWidth + Math.round(34 * uiScale)
    radius: Math.round(radiusValue * uiScale)
    color: !enabled ? disabledColor : (mouse.containsMouse ? hoverColor : fillColor)
    border.color: !enabled ? Qt.rgba(0.45, 0.5, 0.58, 0.6) : Qt.darker(fillColor, 1.08)
    border.width: 1

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: root.enabled
        enabled: root.enabled
        cursorShape: root.enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: root.clicked()
    }

    HintToolTip {
        visible: root.enabled && root.hint.length > 0 && mouse.containsMouse
        text: root.hint
        themeObj: root.themeObj
        uiScale: root.uiScale
        fontFamilyName: root.fontFamilyName
    }

    Text {
        id: labelText
        anchors.centerIn: parent
        width: parent.width - Math.round(16 * root.uiScale)
        text: root.label
        color: (!root.enabled) ? Qt.rgba(1, 1, 1, 0.55) : (mouse.containsMouse ? root.hoverTextColor : root.textColor)
        font.family: root.fontFamilyName
        font.pixelSize: Math.max(11, Math.round(root.fontSize * root.uiScale))
        fontSizeMode: Text.HorizontalFit
        minimumPixelSize: 10
        font.bold: true
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        wrapMode: root.wrap ? Text.WordWrap : Text.NoWrap
        elide: root.wrap ? Text.ElideNone : Text.ElideRight
    }
}
