import QtQuick
import QtQuick.Layouts

RowLayout {
    id: root
    property string label: ""
    property string value: ""
    property var themeObj
    property real uiScale: 1.0
    property int fontSize: 14
    property string fontFamilyName: "Segoe UI"

    Layout.fillWidth: true
    spacing: Math.round(34 * uiScale)

    Text {
        text: root.label
        color: root.themeObj.textMuted
        font.family: root.fontFamilyName
        font.pixelSize: Math.max(11, Math.round(root.fontSize * root.uiScale))
        verticalAlignment: Text.AlignTop
        font.bold: true
        Layout.preferredWidth: Math.round(260 * root.uiScale)
    }

    Text {
        text: root.value
        color: root.themeObj.text
        font.family: root.fontFamilyName
        font.pixelSize: Math.max(11, Math.round(root.fontSize * root.uiScale))
        font.bold: true
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        verticalAlignment: Text.AlignTop
    }
}
