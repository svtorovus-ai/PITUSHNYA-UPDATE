﻿#Requires AutoHotkey v2.0
#SingleInstance Force

CoordMode "Mouse", "Client"

baseDir := RegExReplace(A_ScriptDir, "\\ahk$")
dataDir := baseDir "\data"

DirCreate dataDir

stateFile := dataDir "\delta_state.ini"
callsignFile := dataDir "\callsign.txt"
templateTimeFile := dataDir "\message_template_time_fix.txt"
screenshotPasteGuardFile := dataDir "\last_screenshot_paste.txt"
timeTextGuardFile := dataDir "\last_time_text_paste.txt"
runtimeProfileFile := dataDir "\runtime_profile.json"

if !FileExist(stateFile)
    FileAppend "[delta]`nstatus=idle`ntime=`ncycle_id=", stateFile, "UTF-8"

if !FileExist(callsignFile)
    FileAppend "екіпаж", callsignFile, "UTF-8"

if !FileExist(templateTimeFile)
    FileAppend "Ціль- підар, виявлено: ({time})", templateTimeFile, "UTF-8"

signalExe := ""

GetStatus() {
    global stateFile
    try
        return IniRead(stateFile, "delta", "status", "")
    catch
        return ""
}

SetStatus(status) {
    global stateFile
    try IniWrite status, stateFile, "delta", "status"
}

GetDetectTime() {
    global stateFile
    try
        return IniRead(stateFile, "delta", "time", "")
    catch
        return ""
}

GetCycleId() {
    global stateFile
    try
        return IniRead(stateFile, "delta", "cycle_id", "")
    catch
        return ""
}

ResetBrokenCycleIfNeeded() {
    global stateFile

    status := GetStatus()

    if (
        status = "coords_applied_auto"
        || status = "coords_applied_manual"
        || status = "target_done"
        || status = "cycle_done"
        || status = "wizard_closed"
        || status = "closed"
        || status = "done"
    ) {
        try IniWrite "idle", stateFile, "delta", "status"
        try IniWrite "", stateFile, "delta", "time"
        try IniWrite "", stateFile, "delta", "cycle_id"
    }
}

EnsureCycleTimeFromScreenshot() {
    global stateFile

    ResetBrokenCycleIfNeeded()

    status := GetStatus()

    if (status != "" && status != "idle")
        return ""

    detectTime := FormatTime(A_Now, "HH:mm")
    cycleId := A_Now A_MSec

    try IniWrite detectTime, stateFile, "delta", "time"
    try IniWrite cycleId, stateFile, "delta", "cycle_id"
    SetStatus("waiting_coords")

    return detectTime
}

ReadCallsign() {
    global callsignFile

    try {
        if FileExist(callsignFile) {
            value := Trim(FileRead(callsignFile, "UTF-8"))

            if (value != "")
                return value
        }
    }
    catch {
    }

    return "екіпаж"
}

ReadTemplateTime() {
    global templateTimeFile

    try {
        if FileExist(templateTimeFile) {
            value := Trim(FileRead(templateTimeFile, "UTF-8"))

            if (value != "")
                return value
        }
    }
    catch {
    }

    return "Ціль- підар, виявлено: ({time})"
}

BuildTimeFixText(detectTime, callsign) {
    template := ReadTemplateTime()
    text := StrReplace(template, "{time}", detectTime)
    text := StrReplace(text, "{callsign}", callsign)
    return text
}

ReadRuntimeProfileValue(key, fallback := "") {
    global runtimeProfileFile

    try {
        if FileExist(runtimeProfileFile) {
            raw := FileRead(runtimeProfileFile, "UTF-8")
            quote := Chr(34)
            pattern := quote key quote "\s*:\s*" quote "([^" quote "]*)" quote

            if RegExMatch(raw, pattern, &m) {
                value := m[1]
                value := StrReplace(value, "\\", "\")
                value := StrReplace(value, "\/", "/")
                return Trim(value)
            }
        }
    }
    catch {
    }

    return fallback
}

ResolveSignalExe() {
    configured := ReadRuntimeProfileValue("signal_exe", "")
    candidates := []
    localAppData := EnvGet("LocalAppData")
    roamingAppData := EnvGet("AppData")

    if (configured != "")
        candidates.Push(configured)

    if (localAppData != "")
        candidates.Push(localAppData "\Programs\signal-desktop\Signal.exe")

    if (roamingAppData != "")
        candidates.Push(roamingAppData "\Programs\signal-desktop\Signal.exe")

    for candidate in candidates {
        if (candidate != "" && FileExist(candidate))
            return candidate
    }

    return configured
}

ShouldPasteScreenshot() {
    global screenshotPasteGuardFile

    nowTick := A_TickCount

    try {
        if FileExist(screenshotPasteGuardFile) {
            prevTick := Trim(FileRead(screenshotPasteGuardFile, "UTF-8"))

            if RegExMatch(prevTick, "^\d+$") {
                delta := nowTick - (prevTick + 0)

                if (delta >= 0 && delta < 1500)
                    return false
            }
        }
    }
    catch {
    }

    try FileDelete screenshotPasteGuardFile
    try FileAppend nowTick, screenshotPasteGuardFile, "UTF-8"

    return true
}

ShouldPasteTimeText(detectTime, cycleId := "") {
    global timeTextGuardFile

    if (detectTime = "")
        return false

    guardKey := cycleId != "" ? cycleId : detectTime
    nowTick := A_TickCount

    try {
        if FileExist(timeTextGuardFile) {
            prev := Trim(FileRead(timeTextGuardFile, "UTF-8"))
            parts := StrSplit(prev, "|")

            if (parts.Length >= 2 && parts[1] = guardKey && RegExMatch(parts[2], "^\d+$")) {
                delta := nowTick - (parts[2] + 0)

                if (delta >= 0 && delta < 7000)
                    return false
            }
        }
    }
    catch {
    }

    try FileDelete timeTextGuardFile
    try FileAppend guardKey "|" nowTick, timeTextGuardFile, "UTF-8"

    return true
}

TypeTextDirect(text) {
    if (text = "")
        return false

    SendText text
    Sleep 90
    return true
}

ActivateSignal() {
    global signalExe

    if WinExist("ahk_exe Signal.exe") {
        try {
            if (WinGetMinMax("ahk_exe Signal.exe") = -1)
                WinRestore "ahk_exe Signal.exe"
        }

        try WinShow "ahk_exe Signal.exe"
        try WinActivate "ahk_exe Signal.exe"
    } else {
        signalExe := ResolveSignalExe()

        if (signalExe = "" || !FileExist(signalExe))
            return false

        Run signalExe
        Sleep 700
    }

    Loop 28 {
        hwnd := 0

        try hwnd := WinGetID("ahk_exe Signal.exe")

        if hwnd {
            try {
                if (WinGetMinMax("ahk_id " hwnd) = -1)
                    WinRestore "ahk_id " hwnd
            }

            try WinShow "ahk_id " hwnd
            try WinActivate "ahk_id " hwnd
            try DllCall("SetForegroundWindow", "ptr", hwnd)
            try DllCall("BringWindowToTop", "ptr", hwnd)

            if WinWaitActive("ahk_id " hwnd,, 0.35)
                return true
        }

        Sleep 120
    }

    return false
}

FocusSignalInput() {
    hwnd := WinGetID("ahk_exe Signal.exe")

    if !hwnd
        return false

    WinActivate "ahk_id " hwnd
    WinWaitActive "ahk_id " hwnd,, 1

    WinGetClientPos &cx, &cy, &cw, &ch, "ahk_id " hwnd

    px := Floor(cw * 0.58)
    leftSafe := Max(180, Floor(cw * 0.22))
    rightSafe := cw - Max(160, Floor(cw * 0.16))

    if (px < leftSafe)
        px := leftSafe

    if (px > rightSafe)
        px := rightSafe

    if (px < 80)
        px := Min(cw - 80, 80)

    py := ch - Max(32, Floor(ch * 0.038))

    if (px < 20 || py < 20)
        return false

    CoordMode "Mouse", "Screen"
    MouseGetPos &oldX, &oldY

    try {
        ControlClick "x" px " y" py, "ahk_id " hwnd, , "Left", 1, "NA"
        Sleep 110
        CoordMode "Mouse", "Client"
        return true
    }
    catch {
        CoordMode "Mouse", "Client"
        Click px, py, 1
        Sleep 80
        CoordMode "Mouse", "Screen"
        MouseMove oldX, oldY, 0
        CoordMode "Mouse", "Client"
        return true
    }
}

newCycleTime := EnsureCycleTimeFromScreenshot()
detectTime := newCycleTime

if (detectTime = "")
    detectTime := GetDetectTime()

if !ActivateSignal()
    ExitApp

if !FocusSignalInput()
    ExitApp

if ShouldPasteScreenshot() {
    Send "^v"
    Sleep 450
}

if (newCycleTime != "" && ShouldPasteTimeText(detectTime, GetCycleId())) {
    templateText := BuildTimeFixText(detectTime, ReadCallsign())
    FocusSignalInput()
    TypeTextDirect(templateText)
}

ExitApp