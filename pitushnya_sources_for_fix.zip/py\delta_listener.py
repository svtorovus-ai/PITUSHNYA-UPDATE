import json
import re
import math
import time
import requests
import mgrs
import shapefile
from pathlib import Path
from datetime import datetime
from shapely.geometry import Point, shape

SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR = SCRIPT_DIR if (SCRIPT_DIR / "config.json").exists() or (SCRIPT_DIR / "data").exists() else SCRIPT_DIR.parent
DATA_DIR = BASE_DIR / "data"
GIS_DIR = BASE_DIR / "gis" / "ukraine"
CONFIG_FILE = BASE_DIR / "config.json"
CALLSIGN_FILE = DATA_DIR / "callsign.txt"
TEMPLATE_COORDS_FILE = DATA_DIR / "message_template_coords.txt"
RUNTIME_PROFILE_FILE = DATA_DIR / "runtime_profile.json"
TARGET_META_FILE = DATA_DIR / "delta_ready_meta.json"
LISTENER_HEARTBEAT_FILE = DATA_DIR / "listener_heartbeat.txt"

STATE_FILE = DATA_DIR / "delta_state.ini"
READY_FILE = DATA_DIR / "delta_ready.txt"
DEBUG_FILE = DATA_DIR / "delta_debug.txt"
CACHE_FILE = DATA_DIR / "delta_place_cache.json"
EVENT_LOG_FILE = DATA_DIR / "pitusharnya_events.log"
RAW_EVENTS_FILE = DATA_DIR / "signal_raw_events.jsonl"

POLYGONS_FILE = GIS_DIR / "gis_osm_places_a_free_1.shp"
POINTS_FILE = GIS_DIR / "gis_osm_places_free_1.shp"

EVENTS_URL = "http://127.0.0.1:7583/api/v1/events"
CACHE_VERSION = "v3"

DEFAULT_CONFIG = {
    "title": "PITUSHNYA MCC",
    "signal_number": "",
    "screenshots_path": r"%USERPROFILE%\Documents\ShareX\Screenshots",
    "font_size": 11,
    "theme": "dark",
    "log_position": "right",
    "accept_groups": False,
    "source_mode": "all_personal",
    "personal_mode": "all_personal",
    "group_mode": "specific_groups",
    "allowed_senders": [],
    "allowed_groups": [],
    "receiver_enabled": True,
    "capture_mode": "signal",
    "target_prompt_allow_same_coords": False,
    "signal_http": "127.0.0.1:7583",
    "receiver_ignore_own_account": True,
    "receiver_ignore_last_generated_message": True,
    "coord_output_system": "MGRS",
    "coord_input_systems": [
        "MGRS",
        "GEO decimal",
        "GEO deg-min",
        "GEO DMS",
        "СК-42 lat/lon",
        "СК-42 deg-min",
        "СК-42 DMS",
        "UTM",
        "USNG",
    ],
    "coord_output_systems": [
        "MGRS",
        "GEO decimal",
        "GEO deg-min",
        "GEO DMS",
        "СК-42 lat/lon",
        "СК-42 deg-min",
        "СК-42 DMS",
        "UTM",
        "USNG",
    ],
}

POLYGON_ALLOWED_FCLASS = {"city", "town", "village", "hamlet", "suburb"}
POINT_ALLOWED_FCLASS = {"city", "town", "village", "hamlet"}

PLACE_PRIORITY = {
    "city": 1,
    "town": 2,
    "village": 3,
    "hamlet": 4,
    "suburb": 20
}

POINT_CLASS_BONUS = {
    "city": 1.20,
    "town": 0.70,
    "village": 0.00,
    "hamlet": 0.20
}

POLYGON_CLASS_BONUS = {
    "city": 8.00,
    "town": 4.00,
    "village": 0.40,
    "hamlet": 0.60,
    "suburb": 50.00
}

m = mgrs.MGRS()

mgrs_pattern = re.compile(
    r"\b\d{1,2}\s*[C-HJ-NP-X]\s*[A-HJ-NP-Z]{2}(?:\s*\d{2,10}\s*\d{2,10}|\d{4,15})\b",
    re.IGNORECASE
)

utm_pattern = re.compile(
    r"\b(?P<zone>[1-5]?\d|60)\s*(?P<band>[C-HJ-NP-XNS])\s+(?P<easting>\d{3,7}(?:[.,]\d+)?)\s+(?P<northing>\d{4,8}(?:[.,]\d+)?)\b",
    re.IGNORECASE
)

GROUP_CONTAINER_KEYS = {
    "group",
    "groupv2",
    "groupv2info",
    "groupinfo",
    "groupcontext",
    "groupcontextv2",
    "groupchange",
}

GROUP_ID_KEYS = {
    "groupid",
    "masterkey",
    "groupmasterkey",
}

GROUP_NAME_KEYS = {
    "grouptitle",
    "groupname",
}

GROUP_CONTEXT_ID_KEYS = GROUP_ID_KEYS | {"id", "uuid"}
GROUP_CONTEXT_NAME_KEYS = GROUP_NAME_KEYS | {"name", "title"}
GROUP_META_KEYS = GROUP_CONTAINER_KEYS | GROUP_ID_KEYS | GROUP_NAME_KEYS

group_marker_re = re.compile(
    r'(?:["\\]+)(group|groupV2|groupV2Info|groupInfo|groupId|groupContext|groupContextV2|groupChange|groupTitle|groupName|masterKey|groupMasterKey)(?:["\\]+)\s*:',
    re.IGNORECASE
)

polygon_items = []
point_items = []
nearest_cache = {}

last_processed_signature = ""
last_processed_time = 0.0
recent_signatures = {}
LISTENER_STARTED_AT_MS = int(time.time() * 1000)
TIMESTAMP_KEYS = (
    "timestamp",
    "serverReceivedTimestamp",
    "serverDeliveredTimestamp",
    "serverTimestamp",
    "receivedTimestamp",
    "sentTimestamp",
)

DATA_DIR.mkdir(parents=True, exist_ok=True)
for p in [STATE_FILE, READY_FILE, DEBUG_FILE, EVENT_LOG_FILE, RAW_EVENTS_FILE, LISTENER_HEARTBEAT_FILE]:
    if not p.exists():
        p.write_text("", encoding="utf-8")


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return bool(default)
    if isinstance(value, (int, float)):
        return value != 0
    text = str(value).strip().casefold()
    if text in {"1", "true", "yes", "y", "on", "так", "увімкнено", "включено", "enable", "enabled"}:
        return True
    if text in {"0", "false", "no", "n", "off", "ні", "нi", "вимкнено", "выключено", "disable", "disabled"}:
        return False
    return bool(default)


def config_text(value):
    return maybe_fix_mojibake(value).strip().casefold()


def normalize_capture_mode(value):
    text = config_text(value)
    if "буфер" in text or "buffer" in text or "clipboard" in text:
        if "signal" in text:
            return "signal"
        return "буфер"
    return "signal"


def is_specific_mode(value):
    text = config_text(value)
    return any(token in text for token in ("вибран", "тільки", "specific", "selected", "only"))


def load_config():
    cfg = DEFAULT_CONFIG.copy()
    try:
        if CONFIG_FILE.exists():
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            cfg.update(data)
            cfg["accept_groups"] = as_bool(data.get("receiver_accept_groups", cfg.get("accept_groups", False)), False)
            cfg["allowed_groups"] = data.get("receiver_allowed_groups", data.get("allowed_groups", cfg["allowed_groups"])) or []
            cfg["allowed_senders"] = data.get("receiver_allowed_senders", data.get("allowed_senders", cfg["allowed_senders"])) or []
            cfg["receiver_enabled"] = as_bool(data.get("receiver_enabled", cfg.get("receiver_enabled", True)), True)
            cfg["capture_mode"] = normalize_capture_mode(data.get("receiver_capture_mode", data.get("capture_mode", "signal")))
            cfg["signal_http"] = str(data.get("signal_cli_http", data.get("signal_http", cfg["signal_http"])) or cfg["signal_http"]).strip()
            cfg["target_prompt_allow_same_coords"] = as_bool(data.get("target_prompt_allow_same_coords", False), False)
            cfg["receiver_ignore_own_account"] = as_bool(data.get("receiver_ignore_own_account", cfg.get("receiver_ignore_own_account", True)), True)
            cfg["coord_output_system"] = str(data.get("coord_output_system", cfg.get("coord_output_system", "MGRS")) or "MGRS").strip()
            cfg["coord_input_systems"] = data.get("coord_input_systems", cfg.get("coord_input_systems", [])) or []
            cfg["coord_output_systems"] = data.get("coord_output_systems", cfg.get("coord_output_systems", [])) or []
            cfg["receiver_ignore_last_generated_message"] = as_bool(data.get("receiver_ignore_last_generated_message", cfg.get("receiver_ignore_last_generated_message", True)), True)

            personal_raw = data.get("receiver_personal_mode", data.get("receiver_source_mode", data.get("source_mode", cfg["personal_mode"])))
            cfg["personal_mode"] = "specific_senders" if is_specific_mode(personal_raw) else "all_personal"
            cfg["source_mode"] = cfg["personal_mode"]

            group_raw = data.get("receiver_group_mode", data.get("group_mode", cfg["group_mode"]))
            cfg["group_mode"] = "specific_groups" if is_specific_mode(group_raw) else "all_groups"
    except Exception:
        pass
    return cfg


def events_url_from_config(cfg):
    raw = str(cfg.get("signal_http", "127.0.0.1:7583") or "127.0.0.1:7583").strip()
    if raw.startswith("http://") or raw.startswith("https://"):
        base = raw.rstrip("/")
    else:
        base = "http://" + raw.strip("/")
    if base.endswith("/api/v1/events"):
        return base
    return base + "/api/v1/events"


def write_event(level, message):
    t = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(EVENT_LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"{t}|{level}|{message}\n")


def log_debug(data):
    try:
        if isinstance(data, str):
            DEBUG_FILE.write_text(data, encoding="utf-8")
        else:
            DEBUG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def println(*args):
    print(*args, flush=True)


def touch_heartbeat():
    try:
        LISTENER_HEARTBEAT_FILE.write_text(datetime.now().isoformat(timespec="seconds"), encoding="utf-8")
    except Exception:
        pass


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0088
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return r * c


def load_cache():
    global nearest_cache
    try:
        if CACHE_FILE.exists():
            nearest_cache = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        else:
            nearest_cache = {}
    except Exception:
        nearest_cache = {}


def save_cache():
    try:
        CACHE_FILE.write_text(json.dumps(nearest_cache, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def extract_fclass(attr):
    for key in ("fclass", "FCLASS", "place", "PLACE", "type", "TYPE"):
        if key in attr and attr[key]:
            return str(attr[key]).strip().lower()
    return ""


def extract_name(attr):
    for key in ("name", "NAME", "Name", "name_uk", "NAME_UK"):
        if key in attr and attr[key]:
            return str(attr[key]).strip()
    return ""


def polygon_area_km2(geom):
    minx, miny, maxx, maxy = geom.bounds
    lat_mid = (miny + maxy) / 2.0
    width_km = haversine_km(lat_mid, minx, lat_mid, maxx)
    height_km = haversine_km(miny, minx, maxy, minx)
    return max(width_km * height_km, 0.0001)


def load_polygon_places():
    global polygon_items
    sf = shapefile.Reader(str(POLYGONS_FILE))
    fields = [f[0] for f in sf.fields[1:]]
    result = []

    for sr in sf.shapeRecords():
        attr = dict(zip(fields, sr.record))
        fclass = extract_fclass(attr)

        if fclass not in POLYGON_ALLOWED_FCLASS:
            continue

        name = extract_name(attr)
        if not name:
            continue

        try:
            geom = shape(sr.shape.__geo_interface__)
        except Exception:
            continue

        if geom.is_empty:
            continue

        if geom.geom_type not in ("Polygon", "MultiPolygon"):
            continue

        try:
            centroid = geom.representative_point()
        except Exception:
            centroid = geom.centroid

        result.append({
            "name": name,
            "fclass": fclass,
            "priority": PLACE_PRIORITY.get(fclass, 999),
            "geom": geom,
            "area": geom.area,
            "centroid_lat": centroid.y,
            "centroid_lon": centroid.x,
            "bbox_km2": polygon_area_km2(geom)
        })

    if not result:
        raise RuntimeError("Не вдалося завантажити полігони")
    polygon_items = result


def load_point_places():
    global point_items
    sf = shapefile.Reader(str(POINTS_FILE))
    fields = [f[0] for f in sf.fields[1:]]
    result = []

    for sr in sf.shapeRecords():
        attr = dict(zip(fields, sr.record))
        fclass = extract_fclass(attr)

        if fclass not in POINT_ALLOWED_FCLASS:
            continue

        name = extract_name(attr)
        if not name:
            continue

        try:
            geom = shape(sr.shape.__geo_interface__)
        except Exception:
            continue

        if geom.is_empty:
            continue

        if geom.geom_type != "Point":
            continue

        result.append({
            "name": name,
            "fclass": fclass,
            "priority": PLACE_PRIORITY.get(fclass, 999),
            "lat": geom.y,
            "lon": geom.x
        })

    if not result:
        raise RuntimeError("Не вдалося завантажити point-шар")
    point_items = result


def load_places():
    if not POLYGONS_FILE.exists():
        raise RuntimeError(f"Нема полігонів: {POLYGONS_FILE}")
    if not POINTS_FILE.exists():
        raise RuntimeError(f"Нема point-шару: {POINTS_FILE}")

    load_polygon_places()
    load_point_places()
    load_cache()
    println(f"POLYGONS: {len(polygon_items)}")
    println(f"POINTS: {len(point_items)}")
    write_event("INFO", f"ГІС піднявся: polygons={len(polygon_items)}, points={len(point_items)}")


def read_detect_time():
    if not STATE_FILE.exists():
        return None
    text = STATE_FILE.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r"time=(\d{2}:\d{2})", text)
    return match.group(1) if match else None


def normalize_mgrs(text: str) -> str:
    spaced = re.sub(r"\s+", " ", text.upper()).strip()
    spaced_match = re.match(r"^(\d{1,2})([C-HJ-NP-X])\s*([A-HJ-NP-Z]{2})\s*(\d{2,10})(?:\s+|\b)(\d{2,10})$", spaced)
    if spaced_match:
        zone, band, square = spaced_match.group(1), spaced_match.group(2), spaced_match.group(3)
        easting, northing = spaced_match.group(4), spaced_match.group(5)
    else:
        raw = re.sub(r"\s+", "", text.upper())
        mobj = re.match(r"^(\d{1,2})([C-HJ-NP-X])([A-HJ-NP-Z]{2})(\d+)$", raw)
        if not mobj:
            return raw
        zone = mobj.group(1)
        band = mobj.group(2)
        square = mobj.group(3)
        digits = mobj.group(4)
        half = len(digits) // 2
        easting = digits[:half]
        northing = digits[half:]
    precision = min(5, max(2, len(easting), len(northing), 5))
    easting = easting[:precision].ljust(precision, "0")
    northing = northing[:precision].ljust(precision, "0")
    return f"{zone}{band} {square} {easting} {northing}"


def mgrs_to_latlon(mgrs_text: str):
    compact = re.sub(r"\s+", "", mgrs_text.upper())
    return m.toLatLon(compact)

def mgrs_compact(mgrs_text: str) -> str:
    return re.sub(r"\s+", "", str(mgrs_text or "").upper())


def mgrs_band_to_hemisphere(value: str) -> str:
    band = str(value or "").strip().upper()[:1]
    if not band:
        return "N"
    if band in {"N", "P", "Q", "R", "S", "T", "U", "V", "W", "X"}:
        return "N"
    return "S"


def utm_to_mgrs(zone, band_or_hemisphere, easting, northing):
    try:
        zone = int(zone)
        band_or_hemisphere = str(band_or_hemisphere or "N").strip().upper()[:1]
        hemisphere = mgrs_band_to_hemisphere(band_or_hemisphere)
        easting = float(str(easting).replace(",", "."))
        northing = float(str(northing).replace(",", "."))
        value = m.UTMToMGRS(zone, hemisphere, easting, northing, MGRSPrecision=5)
        return normalize_mgrs(value)
    except Exception:
        return None


def extract_utm(text: str):
    raw = str(text or "")
    match = utm_pattern.search(raw)
    if not match:
        return None

    return utm_to_mgrs(
        match.group("zone"),
        match.group("band"),
        match.group("easting"),
        match.group("northing"),
    )


def format_mgrs_as_usng(mgrs_text: str) -> str:
    return normalize_mgrs(mgrs_text)


def format_mgrs_as_utm(mgrs_text: str) -> str:
    try:
        zone, hemisphere, easting, northing = m.MGRSToUTM(mgrs_compact(mgrs_text))
        return f"{int(zone)}{hemisphere} {int(round(float(easting)))} {int(round(float(northing)))}"
    except Exception:
        return str(mgrs_text or "")

def load_callsign(cfg=None):
    try:
        if CALLSIGN_FILE.exists():
            value = CALLSIGN_FILE.read_text(encoding="utf-8", errors="ignore").strip()
            if value:
                return value
    except Exception:
        pass

    try:
        cfg = cfg or load_config()
        value = str(cfg.get("callsign", "")).strip()
        if value:
            return value
    except Exception:
        pass

    return "екіпаж"


def load_runtime_profile():
    try:
        if RUNTIME_PROFILE_FILE.exists():
            return json.loads(RUNTIME_PROFILE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def load_coords_template(cfg=None):
    try:
        if TEMPLATE_COORDS_FILE.exists():
            value = TEMPLATE_COORDS_FILE.read_text(encoding="utf-8", errors="ignore").strip()
            if value:
                return value, f"file:{TEMPLATE_COORDS_FILE.name}"
    except Exception:
        pass

    try:
        profile = load_runtime_profile()
        value = str(profile.get("message_template_coords", "")).strip()
        if value:
            return value, f"file:{RUNTIME_PROFILE_FILE.name}"
    except Exception:
        pass

    try:
        cfg = cfg or load_config()
        value = str(cfg.get("message_template_coords", "")).strip()
        if value:
            return value, "config.json"
    except Exception:
        pass

    return "{time} {callsign}, {targets}, за корами ({mgrs}) н.п. ({place}), рух на {direction}", "default"


def transform_latlon(lat, lon, src_epsg, dst_epsg):
    try:
        from pyproj import Transformer
        transformer = Transformer.from_crs(src_epsg, dst_epsg, always_xy=True)
        out_lon, out_lat = transformer.transform(float(lon), float(lat))
        return float(out_lat), float(out_lon)
    except Exception:
        return float(lat), float(lon)


def format_output_coords(mgrs_text, cfg=None):
    system = str((cfg or {}).get("coord_output_system", "MGRS") or "MGRS").strip()
    system_key = system.casefold()

    if not mgrs_text:
        return ""

    if system_key == "mgrs":
        return str(mgrs_text or "")

    if system_key == "usng":
        return format_mgrs_as_usng(mgrs_text)

    if system_key == "utm":
        return format_mgrs_as_utm(mgrs_text)

    try:
        lat, lon = mgrs_to_latlon(mgrs_text)
    except Exception:
        return str(mgrs_text or "")

    lat = float(lat)
    lon = float(lon)

    is_sk42 = system_key.startswith("ск-42") or system_key.startswith("ск42")

    if is_sk42:
        lat, lon = transform_latlon(lat, lon, 4326, 4284)

    hemi_ns = "N" if lat >= 0 else "S"
    hemi_ew = "E" if lon >= 0 else "W"
    alat, alon = abs(lat), abs(lon)

    if system in {"GEO decimal", "СК-42 lat/lon"}:
        return f"{lat:.6f}, {lon:.6f}"

    if system in {"GEO deg-min", "СК-42 deg-min"}:
        lat_deg = int(alat)
        lon_deg = int(alon)
        lat_min = (alat - lat_deg) * 60.0
        lon_min = (alon - lon_deg) * 60.0
        return f"{lat_deg}° {lat_min:.4f}' {hemi_ns}, {lon_deg}° {lon_min:.4f}' {hemi_ew}"

    if system in {"GEO DMS", "СК-42 DMS"}:
        lat_deg = int(alat)
        lon_deg = int(alon)
        lat_min_full = (alat - lat_deg) * 60.0
        lon_min_full = (alon - lon_deg) * 60.0
        lat_min = int(lat_min_full)
        lon_min = int(lon_min_full)
        lat_sec = (lat_min_full - lat_min) * 60.0
        lon_sec = (lon_min_full - lon_min) * 60.0
        return f"{lat_deg}°{lat_min:02d}'{lat_sec:05.2f}\" {hemi_ns}, {lon_deg}°{lon_min:02d}'{lon_sec:05.2f}\" {hemi_ew}"

    return str(mgrs_text or "")
def build_text(detect_time, callsign, mgrs_text, place, cfg=None, targets="", direction=""):
    template, template_source = load_coords_template(cfg)

    targets_text = str(targets or "ТУТ ТИП ЦІЛІ").strip()
    direction_text = str(direction or "ТУТ НАПРЯМОК РУХУ").strip()

    result = str(template)
    result = result.replace("{time}", str(detect_time or ""))
    result = result.replace("{callsign}", str(callsign or ""))
    result = result.replace("{mgrs}", str(format_output_coords(mgrs_text, cfg) or ""))
    result = result.replace("{place}", str(place or ""))
    result = result.replace("{targets}", targets_text)
    result = result.replace("{target}", targets_text)
    result = result.replace("{direction}", direction_text)

    result = result.replace("ТУТ ТИП ЦІЛІ", targets_text)
    result = result.replace("ТУТ НАПРЯМОК РУХУ", direction_text)

    return result, template_source, template


def dms_to_decimal(deg, minutes=0.0, seconds=0.0, hemi=""):
    value = abs(float(deg)) + abs(float(minutes)) / 60.0 + abs(float(seconds)) / 3600.0
    hemi = str(hemi or "").strip().upper()
    if hemi in {"S", "W"} or float(deg) < 0:
        value *= -1
    return value


def extract_latlon(text: str):
    raw = str(text or "").replace(",", ".")
    m = re.search(r'(?P<a>[+-]?\d{1,2}\.\d+)\D+(?P<b>[+-]?\d{1,3}\.\d+)', raw)
    if m:
        a = float(m.group('a'))
        b = float(m.group('b'))
        if abs(a) <= 90 and abs(b) <= 180:
            return a, b
    dm = re.search(r'(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2}\.\d+)\D*([NS])\D+(\d{1,3})[^0-9A-Za-z]{0,3}(\d{1,2}\.\d+)\D*([EW])', raw, re.I)
    if dm:
        return dms_to_decimal(dm.group(1), dm.group(2), 0, dm.group(3)), dms_to_decimal(dm.group(4), dm.group(5), 0, dm.group(6))
    dms = re.search(r'(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2}(?:\.\d+)?)\D*([NS])\D+(\d{1,3})[^0-9A-Za-z]{0,3}(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2}(?:\.\d+)?)\D*([EW])', raw, re.I)
    if dms:
        return dms_to_decimal(dms.group(1), dms.group(2), dms.group(3), dms.group(4)), dms_to_decimal(dms.group(5), dms.group(6), dms.group(7), dms.group(8))
    dm_plain = re.search(r'(?<!\d)(\d{1,2})\D+(\d{1,2}(?:\.\d+)?)\D+(\d{2,3})\D+(\d{1,2}(?:\.\d+)?)(?!\d)', raw)
    if dm_plain:
        return dms_to_decimal(dm_plain.group(1), dm_plain.group(2), 0, "N"), dms_to_decimal(dm_plain.group(3), dm_plain.group(4), 0, "E")
    dms_plain = re.search(r'(?<!\d)(\d{1,2})\D+(\d{1,2})\D+(\d{1,2}(?:\.\d+)?)\D+(\d{2,3})\D+(\d{1,2})\D+(\d{1,2}(?:\.\d+)?)(?!\d)', raw)
    if dms_plain:
        return dms_to_decimal(dms_plain.group(1), dms_plain.group(2), dms_plain.group(3), "N"), dms_to_decimal(dms_plain.group(4), dms_plain.group(5), dms_plain.group(6), "E")
    return None


def latlon_to_mgrs(lat, lon):
    try:
        raw = str(m.toMGRS(float(lat), float(lon))).strip().upper()
        return normalize_mgrs(raw)
    except Exception:
        return None


def coerce_timestamp_ms(value):
    try:
        if isinstance(value, str):
            value = value.strip()
            if not value.isdigit():
                return None
            value = int(value)
        elif isinstance(value, (int, float)):
            value = int(value)
        else:
            return None
    except Exception:
        return None
    if value < 10_000_000_000:
        value *= 1000
    now_ms = int((time.time() + 86400) * 1000)
    if 1_577_836_800_000 <= value <= now_ms:
        return value
    return None


def collect_timestamps(obj, found=None, depth=0):
    if found is None:
        found = []
    if depth > 5:
        return found
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in TIMESTAMP_KEYS:
                ts = coerce_timestamp_ms(value)
                if ts:
                    found.append((key, ts))
            if isinstance(value, (dict, list)):
                collect_timestamps(value, found, depth + 1)
    elif isinstance(obj, list):
        for item in obj[:40]:
            if isinstance(item, (dict, list)):
                collect_timestamps(item, found, depth + 1)
    return found


def extract_event_timestamp_ms(obj):
    found = collect_timestamps(obj, [])
    if not found:
        return None
    for key in TIMESTAMP_KEYS:
        values = [ts for found_key, ts in found if found_key == key]
        if values:
            return min(values)
    return min(ts for _key, ts in found)


def find_mgrs(*texts):
    for text in texts:
        if not text:
            continue

        match = mgrs_pattern.search(str(text))
        if match:
            return normalize_mgrs(match.group(0))

    for text in texts:
        if not text:
            continue

        utm_value = extract_utm(str(text))
        if utm_value:
            return utm_value

    for text in texts:
        if not text:
            continue

        latlon = extract_latlon(text)

        if latlon:
            lat, lon = float(latlon[0]), float(latlon[1])
            low = str(text).lower()

            if "ск-42" in low or "ск42" in low:
                lat, lon = transform_latlon(lat, lon, 4284, 4326)

            mgrs_value = latlon_to_mgrs(lat, lon)

            if mgrs_value:
                return mgrs_value

    return None

def unwrap_envelope(obj):
    if not isinstance(obj, dict) or not obj:
        return {}, "empty"

    envelope_markers = (
        "dataMessage",
        "data_message",
        "syncMessage",
        "sync_message",
        "typingMessage",
        "typing_message",
        "receiptMessage",
        "receipt_message",
        "callMessage",
        "call_message",
        "source",
        "sourceNumber",
        "source_number",
        "sourceName",
        "source_name",
    )
    if any(key in obj for key in envelope_markers):
        return obj, "top.message"

    if "envelope" in obj and isinstance(obj["envelope"], dict):
        return obj["envelope"], "top.envelope"

    params = obj.get("params", {})
    if isinstance(params, dict):
        if "envelope" in params and isinstance(params["envelope"], dict):
            return params["envelope"], "params.envelope"
        result = params.get("result", {})
        if isinstance(result, dict) and "envelope" in result and isinstance(result["envelope"], dict):
            return result["envelope"], "params.result.envelope"

    result = obj.get("result", {})
    if isinstance(result, dict) and "envelope" in result and isinstance(result["envelope"], dict):
        return result["envelope"], "result.envelope"

    return {}, "no-envelope"

def payload_has_group_markers(payload):
    text = str(payload or "")

    if not text:
        return False

    if group_marker_re.search(text):
        return True

    repaired = text.replace('\\"', '"').replace("\\\\", "\\")

    return bool(group_marker_re.search(repaired))

def maybe_fix_mojibake(value):
    text = str(value or "").strip()

    if not text:
        return ""

    candidates = [text]

    for enc in ("latin1", "cp1251"):
        try:
            fixed = text.encode(enc, errors="ignore").decode("utf-8", errors="ignore").strip()
            if fixed and fixed not in candidates:
                candidates.append(fixed)
        except Exception:
            pass

    def score(s):
        cyr = sum(1 for ch in s if ("А" <= ch <= "я") or ch in "іїєґІЇЄҐ")
        bad = sum(s.count(x) for x in ("Ð", "Ñ", " ", "Рџ", "Р°", "Рё", "Рі", "С€", "СЏ", "С–", "С—"))
        return cyr * 3 - bad * 10 + len(s) * 0.01

    return max(candidates, key=score).strip()

def normalize_phone(value):
    return re.sub(r"\D+", "", str(value or ""))


def normalize_match_value(value):
    return maybe_fix_mojibake(value).casefold()


MESSAGE_TEXT_KEYS = {"message", "text", "body", "content", "caption"}


def first_value(obj, *keys, default=None):
    if not isinstance(obj, dict):
        return default
    for key in keys:
        if key in obj and obj[key] not in (None, ""):
            return obj[key]
    return default

def deep_first_value(obj, *keys, default=None, max_depth=8):
    if max_depth < 0:
        return default

    if isinstance(obj, dict):
        for key in keys:
            if key in obj and obj[key] not in (None, ""):
                return obj[key]

        for value in obj.values():
            found = deep_first_value(value, *keys, default=default, max_depth=max_depth - 1)
            if found not in (None, ""):
                return found

    elif isinstance(obj, list):
        for item in obj:
            found = deep_first_value(item, *keys, default=default, max_depth=max_depth - 1)
            if found not in (None, ""):
                return found

    return default


def _compact_key(value):
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _has_payload_value(value):
    return value not in (None, "", {}, [])


def event_has_group_context(obj, max_depth=12):
    if max_depth < 0:
        return False
    if isinstance(obj, dict):
        for key, value in obj.items():
            lk = _compact_key(key)
            if lk in GROUP_META_KEYS and _has_payload_value(value):
                return True
            if isinstance(value, (dict, list)) and event_has_group_context(value, max_depth - 1):
                return True
    elif isinstance(obj, list):
        for item in obj:
            if event_has_group_context(item, max_depth - 1):
                return True
    return False


def clean_source_value(value):
    text = maybe_fix_mojibake(value).strip()

    if text in {"", "_", "-", "—", "null", "None", "none"}:
        return ""

    return text


def source_display_value(source_name, source):
    name = clean_source_value(source_name)
    number = clean_source_value(source)

    if name and number and normalize_phone(name) != normalize_phone(number) and name != number:
        return f"{name} ({number})"

    return name or number or "невідомий відправник"


def extract_phone_digits(value):
    text = str(value or "")
    matches = re.findall(r"\+?\d[\d\s().-]{7,}\d", text)

    for item in reversed(matches):
        digits = normalize_phone(item)
        if len(digits) >= 9:
            return digits

    digits = normalize_phone(text)

    if len(digits) >= 9 and not re.search(r"\d+\.\d+", text):
        return digits

    return ""


def source_identity_key(source, source_name):
    number = extract_phone_digits(source) or extract_phone_digits(source_name)

    if number:
        return number

    return clean_source_value(source) or clean_source_value(source_name) or "unknown"


def read_signal_number_from_accounts_file(accounts_file):
    try:
        if not accounts_file.exists():
            return ""

        payload = json.loads(accounts_file.read_text(encoding="utf-8", errors="ignore"))

        if isinstance(payload, dict):
            accounts = payload.get("accounts", [])
        elif isinstance(payload, list):
            accounts = payload
        else:
            accounts = []

        if isinstance(accounts, dict):
            accounts = [accounts]

        if isinstance(accounts, list):
            for account in accounts:
                if not isinstance(account, dict):
                    continue

                for key in ("number", "username", "account", "phoneNumber", "phone_number"):
                    number = clean_source_value(account.get(key))

                    if number and extract_phone_digits(number):
                        return number
    except Exception:
        pass

    return ""


def get_signal_profile_dirs(cfg=None):
    cfg = cfg or {}
    profile = load_runtime_profile()
    dirs = []

    for value in (
        profile.get("signal_profile_dir"),
        cfg.get("signal_profile_dir"),
        "data\\signal-profile",
        "%LOCALAPPDATA%\\PITUSHNYA MCC\\signal-cli",
    ):
        value = str(value or "").strip()

        if not value:
            continue

        expanded = Path(str(Path(value).expanduser()))
        expanded = Path(str(expanded).replace("%LOCALAPPDATA%", str(Path.home() / "AppData" / "Local")))

        if not expanded.is_absolute():
            expanded = BASE_DIR / expanded

        if expanded not in dirs:
            dirs.append(expanded)

    return dirs


def get_effective_signal_number(cfg=None):
    cfg = cfg or {}
    profile = load_runtime_profile()

    for value in (
        profile.get("signal_number"),
        cfg.get("signal_number"),
    ):
        number = clean_source_value(value)

        if number and extract_phone_digits(number):
            return number

    for profile_dir in get_signal_profile_dirs(cfg):
        candidates = [
            profile_dir / "data" / "accounts.json",
            profile_dir / "accounts.json",
        ]

        for accounts_file in candidates:
            number = read_signal_number_from_accounts_file(accounts_file)

            if number:
                return number

    return ""


def is_own_sender(source, source_name, own_number):
    own = extract_phone_digits(own_number)

    if not own:
        return False

    candidates = [
        extract_phone_digits(source),
        extract_phone_digits(source_name),
    ]

    for candidate in candidates:
        if not candidate:
            continue

        if candidate == own:
            return True

        if len(candidate) >= 9 and len(own) >= 9 and candidate[-9:] == own[-9:]:
            return True

    return False


def normalize_text_for_loop_guard(value):
    text = maybe_fix_mojibake(value)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n+", "\n", text)
    return text.strip().casefold()


def is_last_generated_pitushnya_text(text):
    incoming = normalize_text_for_loop_guard(text)

    if not incoming:
        return False

    try:
        if READY_FILE.exists():
            ready_text = normalize_text_for_loop_guard(READY_FILE.read_text(encoding="utf-8", errors="ignore"))

            if ready_text and incoming == ready_text:
                return True
    except Exception:
        pass

    try:
        if TARGET_META_FILE.exists():
            meta = json.loads(TARGET_META_FILE.read_text(encoding="utf-8", errors="ignore") or "{}")

            mgrs_value = normalize_text_for_loop_guard(meta.get("mgrs", ""))
            place_value = normalize_text_for_loop_guard(meta.get("place", ""))
            source_value = normalize_text_for_loop_guard(meta.get("source", ""))

            if mgrs_value and mgrs_value in incoming and place_value and place_value in incoming:
                if source_value:
                    return True
    except Exception:
        pass

    return False

def collect_message_texts(obj, found=None, depth=0):
    if found is None:
        found = []
    if depth > 6:
        return found
    if isinstance(obj, dict):
        for key, value in obj.items():
            lk = str(key or "").lower()
            if isinstance(value, str) and lk in MESSAGE_TEXT_KEYS:
                text = maybe_fix_mojibake(value)
                if text and text not in found:
                    found.append(text)
            elif isinstance(value, (dict, list)):
                collect_message_texts(value, found, depth + 1)
    elif isinstance(obj, list):
        for item in obj:
            collect_message_texts(item, found, depth + 1)
    return found


def walk_group_meta(obj, found=None, in_group_context=False):
    if found is None:
        found = {"ids": set(), "names": set()}
    if isinstance(obj, dict):
        for key, value in obj.items():
            lk = _compact_key(key)
            if lk in GROUP_CONTAINER_KEYS:
                if isinstance(value, dict):
                    walk_group_meta(value, found, True)
                elif isinstance(value, list):
                    walk_group_meta(value, found, True)
                elif _has_payload_value(value):
                    found["ids"].add(str(value).strip())
            elif lk in GROUP_ID_KEYS or (in_group_context and lk in GROUP_CONTEXT_ID_KEYS):
                if _has_payload_value(value):
                    found["ids"].add(str(value).strip())
            elif lk in GROUP_NAME_KEYS or (in_group_context and lk in GROUP_CONTEXT_NAME_KEYS):
                if _has_payload_value(value):
                    found["names"].add(str(value).strip())
            elif isinstance(value, (dict, list)):
                walk_group_meta(value, found, False)
    elif isinstance(obj, list):
        for item in obj:
            walk_group_meta(item, found, in_group_context)
    return found


def extract_group_meta(envelope, raw_obj=None):
    found = walk_group_meta(envelope)
    # raw_obj часто містить службові "group/groups" поля не від самого повідомлення.
    # Груповість визначаємо тільки за envelope/dataMessage, щоб особисті не блокувались як групи.
    ids = [x for x in found["ids"] if x]
    names = [x for x in found["names"] if x]
    group_value = ids[0] if ids else ""
    group_name = names[0] if names else ""
    return group_value, group_name


def detect_group(envelope, raw_text):
    if not isinstance(envelope, dict):
        return False

    def has_direct_group_identity(item):
        if not isinstance(item, dict):
            return False
        for key, value in item.items():
            lk = _compact_key(key)
            if lk in GROUP_META_KEYS and _has_payload_value(value):
                return True
        return False

    data_message = first_value(envelope, "dataMessage", "data_message", default={}) or {}
    sync_message = first_value(envelope, "syncMessage", "sync_message", default={}) or {}
    sent_message = first_value(sync_message, "sentMessage", "sent_message", default={}) or {}
    typing_message = first_value(envelope, "typingMessage", "typing_message", default={}) or {}
    receipt_message = first_value(envelope, "receiptMessage", "receipt_message", default={}) or {}
    call_message = first_value(envelope, "callMessage", "call_message", default={}) or {}

    candidates = [
        data_message,
        sent_message,
        typing_message,
        receipt_message,
        call_message,
    ]

    if has_direct_group_identity(envelope):
        return True

    for item in candidates:
        if not isinstance(item, dict):
            continue

        if has_direct_group_identity(item):
            return True

        meta = walk_group_meta(item)

        if meta["ids"] or meta["names"]:
            return True

    return False


def extract_group_value(envelope, raw_obj=None):
    group_value, _group_name = extract_group_meta(envelope, raw_obj)
    return group_value

def parse_event_obj(obj, own_number=""):
    envelope, origin = unwrap_envelope(obj)

    if not envelope:
        return None

    if first_value(envelope, "syncMessage", "sync_message", default=None):
        return None

    if first_value(envelope, "typingMessage", "typing_message", default=None):
        return None

    if first_value(envelope, "receiptMessage", "receipt_message", default=None):
        return None

    if first_value(envelope, "callMessage", "call_message", default=None):
        return None

    data_message = first_value(envelope, "dataMessage", "data_message", default=None)

    if not isinstance(data_message, dict):
        return None

    data_text = maybe_fix_mojibake(data_message.get("message", "") or "").strip()

    if not data_text:
        return None

    source = clean_source_value(
        first_value(envelope, "sourceNumber", "source_number", "source", default="")
        or deep_first_value(obj, "sourceNumber", "source_number", "source", default="")
    )

    source_name = clean_source_value(
        first_value(envelope, "sourceName", "source_name", default="")
        or deep_first_value(obj, "sourceName", "source_name", default="")
        or source
    )

    if source_name and not source:
        source = source_name

    if source and not source_name:
        source_name = source

    quote_obj = first_value(data_message, "quote", "quotedMessage", "quoted_message", default={}) or {}
    data_quote = ""
    raw_text = json.dumps(obj, ensure_ascii=False)

    if isinstance(quote_obj, dict):
        data_quote = maybe_fix_mojibake(quote_obj.get("text", "") or "").strip()

    group_value, group_name = extract_group_meta(envelope, obj)
    group_name = maybe_fix_mojibake(group_name)

    is_group = bool(group_value or group_name) or detect_group(envelope, raw_text)

    if not group_name and source_name and is_group:
        group_name = source_name

    mgrs_text = find_mgrs(data_text, data_quote)

    if not mgrs_text:
        return None

    event_timestamp_ms = extract_event_timestamp_ms(obj)

    return {
        "origin": origin,
        "source": source,
        "source_name": source_name,
        "data_text": data_text,
        "data_quote": data_quote,
        "sent_text": "",
        "sent_quote": "",
        "mgrs_text": mgrs_text,
        "is_group": is_group,
        "group_value": group_value,
        "group_name": group_name,
        "event_timestamp_ms": event_timestamp_ms,
        "raw": obj
    }

def nearest_point_candidate(lat, lon):
    best = None
    for item in point_items:
        dist = haversine_km(lat, lon, item["lat"], item["lon"])
        score = dist + POINT_CLASS_BONUS.get(item["fclass"], 0.0)
        cand = {
            "name": item["name"],
            "fclass": item["fclass"],
            "dist": dist,
            "score": score
        }
        if best is None or cand["score"] < best["score"] or (cand["score"] == best["score"] and cand["dist"] < best["dist"]):
            best = cand
    return best


def containing_polygon_candidates(lat, lon):
    point = Point(lon, lat)
    result = []

    for item in polygon_items:
        try:
            if not (item["geom"].contains(point) or item["geom"].touches(point)):
                continue
        except Exception:
            continue

        centroid_dist = haversine_km(lat, lon, item["centroid_lat"], item["centroid_lon"])
        area_penalty = 0.0

        if item["fclass"] in ("city", "town"):
            area_penalty += min(item["bbox_km2"] / 40.0, 30.0)
        elif item["fclass"] == "suburb":
            area_penalty += 60.0
        else:
            area_penalty += min(item["bbox_km2"] / 150.0, 3.0)

        score = centroid_dist + POLYGON_CLASS_BONUS.get(item["fclass"], 0.0) + area_penalty

        result.append({
            "name": item["name"],
            "fclass": item["fclass"],
            "dist": centroid_dist,
            "score": score,
            "bbox_km2": item["bbox_km2"]
        })

    result.sort(key=lambda x: (x["score"], x["dist"]))
    return result


def nearest_place_local(lat, lon):
    cache_key = f"{CACHE_VERSION}:{round(lat, 5)},{round(lon, 5)}"
    if cache_key in nearest_cache:
        return nearest_cache[cache_key]

    best_point = nearest_point_candidate(lat, lon)
    containing = containing_polygon_candidates(lat, lon)

    if best_point:
        if containing:
            best_poly = containing[0]

            if best_poly["fclass"] in ("village", "hamlet") and best_poly["dist"] <= 8:
                result = best_poly["name"]
                nearest_cache[cache_key] = result
                save_cache()
                return result

            if best_poly["fclass"] == "town" and best_point["dist"] > 6 and best_poly["dist"] <= 8:
                result = best_poly["name"]
                nearest_cache[cache_key] = result
                save_cache()
                return result

            if best_poly["fclass"] == "city":
                if best_point["fclass"] in ("village", "hamlet", "town") and best_point["dist"] <= 15:
                    result = best_point["name"]
                    nearest_cache[cache_key] = result
                    save_cache()
                    return result

                if best_point["fclass"] == "city" and best_point["dist"] <= 12:
                    result = best_point["name"]
                    nearest_cache[cache_key] = result
                    save_cache()
                    return result

                if best_poly["dist"] <= 5 and best_poly["bbox_km2"] <= 120:
                    result = best_poly["name"]
                    nearest_cache[cache_key] = result
                    save_cache()
                    return result

            if best_poly["fclass"] == "suburb":
                result = best_point["name"]
                nearest_cache[cache_key] = result
                save_cache()
                return result

        result = best_point["name"]
        nearest_cache[cache_key] = result
        save_cache()
        return result

    if containing:
        result = containing[0]["name"]
        nearest_cache[cache_key] = result
        save_cache()
        return result

    best_poly_any = None
    for item in polygon_items:
        centroid_dist = haversine_km(lat, lon, item["centroid_lat"], item["centroid_lon"])
        area_penalty = 0.0
        if item["fclass"] in ("city", "town"):
            area_penalty += min(item["bbox_km2"] / 40.0, 30.0)
        elif item["fclass"] == "suburb":
            area_penalty += 60.0
        else:
            area_penalty += min(item["bbox_km2"] / 150.0, 3.0)

        score = centroid_dist + POLYGON_CLASS_BONUS.get(item["fclass"], 0.0) + area_penalty
        cand = {
            "name": item["name"],
            "score": score,
            "dist": centroid_dist
        }
        if best_poly_any is None or cand["score"] < best_poly_any["score"] or (cand["score"] == best_poly_any["score"] and cand["dist"] < best_poly_any["dist"]):
            best_poly_any = cand

    if best_poly_any:
        result = best_poly_any["name"]
        nearest_cache[cache_key] = result
        save_cache()
        return result

    return ""


def nearest_place_online(lat, lon):
    headers = {"User-Agent": "pitusharnya/1.0"}
    try:
        url = "https://nominatim.openstreetmap.org/reverse"
        params = {
            "lat": lat,
            "lon": lon,
            "format": "jsonv2",
            "accept-language": "uk",
            "zoom": 18,
            "addressdetails": 1
        }
        r = requests.get(url, params=params, headers=headers, timeout=6)
        r.raise_for_status()
        data = r.json()

        addr = data.get("address", {})
        for key in ("city", "town", "village", "hamlet"):
            value = addr.get(key)
            if value:
                return str(value).strip()

        # Reverse geocoder often returns only a громада/municipality in fields.
        # Ask OSM for nearby place objects before falling back to administrative names.
        for radius in (18000, 45000):
            query = f"""
            [out:json][timeout:9];
            (
              node(around:{radius},{float(lat)},{float(lon)})["place"~"^(city|town|village|hamlet|locality)$"]["name"];
              way(around:{radius},{float(lat)},{float(lon)})["place"~"^(city|town|village|hamlet|locality)$"]["name"];
              relation(around:{radius},{float(lat)},{float(lon)})["place"~"^(city|town|village|hamlet|locality)$"]["name"];
            );
            out tags center 80;
            """
            for overpass_url in ("https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"):
                try:
                    rr = requests.post(overpass_url, data={"data": query}, headers=headers, timeout=6)
                    rr.raise_for_status()
                    payload = rr.json()
                    best = None
                    for el in payload.get("elements", []) if isinstance(payload, dict) else []:
                        tags = el.get("tags", {}) or {}
                        name = str(tags.get("name:uk") or tags.get("name") or "").strip()
                        if not name:
                            continue
                        center = el.get("center", {}) or {}
                        plat = float(el.get("lat", center.get("lat")))
                        plon = float(el.get("lon", center.get("lon")))
                        dist = haversine_km(float(lat), float(lon), plat, plon)
                        place_type = str(tags.get("place") or "")
                        bonus = {"city": 6.0, "town": 2.0, "village": 0.0, "hamlet": 0.3, "locality": 1.2}.get(place_type, 0.0)
                        score = dist + bonus
                        if best is None or score < best["score"]:
                            best = {"name": name, "score": score}
                    if best:
                        return best["name"]
                except Exception:
                    continue

        for key in ("suburb", "municipality"):
            value = addr.get(key)
            if value:
                return str(value).strip()

        display_name = data.get("display_name", "")
        if display_name:
            return str(display_name).split(",")[0].strip()
    except Exception:
        pass

    return ""



UNKNOWN_SENDER_KEYS = {
    "",
    "unknown",
    "unknownsender",
    "unknownsource",
    "невідомий",
    "невідомийвідправник",
    "невідомеджерело",
    "неизвестный",
    "неизвестныйотправитель",
    "null",
    "none",
}


def unknown_sender_key(value):
    text = maybe_fix_mojibake(value).strip().casefold()
    return re.sub(r"[\s_\-—–:;.,'\"()\[\]{}]+", "", text)


def is_unknown_sender_value(value):
    return unknown_sender_key(value) in UNKNOWN_SENDER_KEYS


def has_reliable_personal_origin(info):
    source = clean_source_value(info.get("source"))
    source_name = clean_source_value(info.get("source_name"))
    if extract_phone_digits(source) or extract_phone_digits(source_name):
        return True
    if not is_unknown_sender_value(source):
        return True
    if not is_unknown_sender_value(source_name):
        return True
    return False


def allowed_by_config(info, cfg):
    if info.get("is_group"):
        if not cfg.get("accept_groups", False):
            return False

        mode = cfg.get("group_mode", "all_groups")
        allowed_groups = {
            normalize_match_value(x)
            for x in cfg.get("allowed_groups", [])
            if str(x).strip()
        }

        if mode != "specific_groups":
            return True

        if not allowed_groups:
            return False

        candidates = {
            normalize_match_value(info.get("group_value")),
            normalize_match_value(info.get("group_name")),
            normalize_match_value(info.get("source_name")),
            normalize_match_value(info.get("source")),
            normalize_match_value((info.get("data_text") or "").split("\n", 1)[0]),
            normalize_match_value((info.get("sent_text") or "").split("\n", 1)[0]),
        }
        candidates.discard("")
        return bool(candidates & allowed_groups)

    mode = cfg.get("personal_mode", cfg.get("source_mode", "all_personal"))
    allowed = {
        normalize_match_value(x)
        for x in cfg.get("allowed_senders", [])
        if str(x).strip()
    }

    if mode == "specific_senders":
        if not allowed:
            return False

        source = normalize_match_value(info.get("source"))
        source_name = normalize_match_value(info.get("source_name"))
        source_phone = source_identity_key(info.get("source"), info.get("source_name"))
        allowed_phones = {extract_phone_digits(x) for x in cfg.get("allowed_senders", []) if extract_phone_digits(x)}

        return source in allowed or source_name in allowed or source_phone in allowed_phones

    return True


def event_log_has_recent_signature(signature: str, window_sec: int = 3600) -> bool:
    try:
        if not EVENT_LOG_FILE.exists():
            return False

        now = time.time()
        lines = EVENT_LOG_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()[-120:]

        for line in reversed(lines):
            mobj = re.match(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\|READY\|Отримав кори від \"([^\"]+)\".*?:\s*(.*?)\s*->", line)

            if not mobj:
                continue

            ts = datetime.strptime(mobj.group(1), "%Y-%m-%d %H:%M:%S").timestamp()

            if now - ts > window_sec:
                return False

            log_source = mobj.group(2).strip()
            log_source_key = source_identity_key(log_source, log_source)
            mgrs_text = re.sub(r"\s+", " ", mobj.group(3).strip().upper())

            if signature == f"{log_source_key}|{mgrs_text}" or signature.startswith(f"{log_source_key}|{mgrs_text}|"):
                return True

            if signature == f"{log_source}|{mgrs_text}" or signature.startswith(f"{log_source}|{mgrs_text}|"):
                return True
    except Exception:
        return False

    return False


def should_skip_duplicate(signature: str, allow_same_coords: bool = False) -> bool:
    global last_processed_signature, last_processed_time, recent_signatures
    if allow_same_coords:
        return False
    now = time.time()
    recent_signatures = {k: v for k, v in recent_signatures.items() if (now - v) < 3600}
    if signature == last_processed_signature and (now - last_processed_time) < 3600:
        return True
    if signature in recent_signatures and (now - recent_signatures[signature]) < 3600:
        return True
    if event_log_has_recent_signature(signature):
        return True
    last_processed_signature = signature
    last_processed_time = now
    recent_signatures[signature] = now
    return False


def dump_raw_payload(payload):
    try:
        with open(RAW_EVENTS_FILE, "a", encoding="utf-8") as f:
            f.write(payload.strip().replace("\r\n", "\n") + "\n")
    except Exception:
        pass


def process_event_obj(obj, cfg):
    if not bool(cfg.get("receiver_enabled", True)):
        log_debug({"skipped_by_receiver_enabled": True})
        return

    if str(cfg.get("capture_mode", "signal") or "signal").strip().casefold() == "буфер":
        log_debug({"skipped_by_capture_mode": True, "capture_mode": cfg.get("capture_mode")})
        return

    own_number = get_effective_signal_number(cfg)
    info = parse_event_obj(obj, own_number)

    if not info:
        return

    if not bool(cfg.get("accept_groups", False)) and info.get("is_group"):
        log_debug({
            "skipped_group_message": True,
            "accept_groups": cfg.get("accept_groups"),
            "source": info.get("source"),
            "source_name": info.get("source_name"),
            "group_value": info.get("group_value"),
            "group_name": info.get("group_name"),
            "mgrs": info.get("mgrs_text"),
        })
        return

    event_timestamp_ms = int(info.get("event_timestamp_ms") or 0)

    if event_timestamp_ms and event_timestamp_ms < (LISTENER_STARTED_AT_MS - 2000):
        log_debug({
            "skipped_stale_event": True,
            "event_timestamp_ms": event_timestamp_ms,
            "listener_started_at_ms": LISTENER_STARTED_AT_MS,
            "source_name": info.get("source_name") or info.get("source"),
        })
        return

    if bool(cfg.get("receiver_ignore_own_account", True)) and is_own_sender(info.get("source"), info.get("source_name"), own_number):
        log_debug({
            "skipped_own_signal_message": True,
            "own_number": own_number,
            "source": info.get("source"),
            "source_name": info.get("source_name"),
            "mgrs": info.get("mgrs_text"),
            "preview": str(info.get("data_text") or "")[:500],
        })
        return

    if bool(cfg.get("receiver_ignore_last_generated_message", True)) and is_last_generated_pitushnya_text(info.get("data_text")):
        log_debug({
            "skipped_last_generated_pitushnya_text": True,
            "source": info.get("source"),
            "source_name": info.get("source_name"),
            "mgrs": info.get("mgrs_text"),
            "preview": str(info.get("data_text") or "")[:500],
        })
        return

    if not allowed_by_config(info, cfg):
        log_debug({"skipped_by_config": True, "info": info, "cfg": {"accept_groups": cfg.get("accept_groups"), "personal_mode": cfg.get("personal_mode"), "group_mode": cfg.get("group_mode"), "allowed_senders": cfg.get("allowed_senders"), "allowed_groups": cfg.get("allowed_groups")}})
        return

    if not info["mgrs_text"]:
        return

    src_name = source_display_value(info.get("source_name"), info.get("source"))
    source_key = source_identity_key(info.get("source"), info.get("source_name"))
    source_group = str(info.get("group_name") or info.get("group_value") or "")
    signature = f'{source_key}|{info["mgrs_text"]}|{source_group}'.strip()

    if should_skip_duplicate(signature, bool(cfg.get("target_prompt_allow_same_coords", False))):
        log_debug({"skipped_duplicate": True, "signature": signature, "time": datetime.now().isoformat()})
        return

    try:
        detect_time = read_detect_time()

        if not detect_time:
            detect_time = datetime.now().strftime("%H:%M")

        lat, lon = mgrs_to_latlon(info["mgrs_text"])
        place = nearest_place_local(lat, lon)

        if not place:
            place = nearest_place_online(lat, lon)

        if not place:
            write_event("ERROR", f'Не зміг обробити кори від "{src_name}". Причина: не знайшов н.п. для {info["mgrs_text"]}')
            return

        callsign = load_callsign(cfg)
        output_coords = format_output_coords(info["mgrs_text"], cfg)
        final_text, template_source, template_raw = build_text(detect_time, callsign, info["mgrs_text"], place, cfg)
        READY_FILE.write_text(final_text, encoding="utf-8")

        TARGET_META_FILE.write_text(json.dumps({
            "time": detect_time,
            "callsign": callsign,
            "mgrs": info["mgrs_text"],
            "output_coords": output_coords,
            "coord_output_system": str(cfg.get("coord_output_system", "MGRS") or "MGRS"),
            "place": place,
            "source": src_name,
            "source_id": source_key,
            "source_name": clean_source_value(info.get("source_name")),
            "signature": f"{source_key.casefold()}|{info['mgrs_text'].upper()}|{str(place).casefold()}",
        }, ensure_ascii=False, indent=2), encoding="utf-8")

        touch_heartbeat()
        grp_note = f' [чат: {info.get("group_name")}]' if info.get("is_group") and info.get("group_name") else ''
        write_event("READY", f'Отримав кори від "{src_name}"{grp_note}: {info["mgrs_text"]} -> {place}')

        log_debug({
            "template_source": template_source,
            "template_raw": template_raw,
            "final_text": final_text,
            "callsign": callsign,
            "mgrs": info["mgrs_text"],
            "place": place,
            "source": src_name,
            "source_id": source_key,
            "source_name": clean_source_value(info.get("source_name")),
            "own_number": own_number,
        })

        println("SOURCE:", src_name)
        println("MGRS:", info["mgrs_text"])
        println("PLACE:", place)
        println("TEMPLATE_SOURCE:", template_source)
        println("READY:", final_text)
        println("-" * 40)

    except Exception as e:
        write_event("ERROR", f'Не зміг обробити кори від "{src_name}". Причина: {e}')
        log_debug({"stage_error": str(e), "info": info})

def _clean_payload_text(payload):
    text = str(payload or "").strip()

    while text.startswith("data:"):
        text = text[5:].strip()

    return text.lstrip("\ufeff").strip()


def _repair_signal_json_text(payload):
    text = _clean_payload_text(payload)

    if not text:
        return ""

    if text.startswith('"') and text.endswith('"'):
        try:
            decoded = json.loads(text)
            if isinstance(decoded, str):
                text = decoded.strip()
        except Exception:
            text = text[1:-1].strip()

    variants = [text]

    repaired = text

    for _ in range(3):
        new_value = repaired
        new_value = new_value.replace("\\{", "{")
        new_value = new_value.replace("\\}", "}")
        new_value = new_value.replace("\\[", "[")
        new_value = new_value.replace("\\]", "]")
        new_value = new_value.replace('\\"', '"')
        new_value = new_value.replace("\\/", "/")

        if new_value == repaired:
            break

        repaired = new_value

    variants.append(repaired)

    first_obj = repaired.find("{")
    first_arr = repaired.find("[")
    starts = [x for x in (first_obj, first_arr) if x >= 0]

    if starts:
        trimmed = repaired[min(starts):].strip()
        variants.append(trimmed)

    for item in variants:
        item = _clean_payload_text(item)
        if item:
            return item

    return text


def _raw_decode_many(text):
    decoder = json.JSONDecoder()
    values = []
    pos = 0
    length = len(text)

    while pos < length:
        while pos < length and text[pos].isspace():
            pos += 1

        if pos >= length:
            break

        obj, end = decoder.raw_decode(text, pos)
        values.append(obj)
        pos = end

    return values


def _json_load_flexible(payload):
    text = _clean_payload_text(payload)

    if not text:
        raise ValueError("empty payload")

    candidates = []

    def add_candidate(value):
        value = _clean_payload_text(value)
        if value and value not in candidates:
            candidates.append(value)

    add_candidate(text)

    try:
        decoded = json.loads(text)
        if isinstance(decoded, str):
            add_candidate(decoded)
            add_candidate(_repair_signal_json_text(decoded))
        else:
            return decoded
    except Exception:
        pass

    add_candidate(_repair_signal_json_text(text))

    if '\\"' in text:
        add_candidate(text.replace('\\"', '"').replace("\\/", "/"))
        add_candidate(_repair_signal_json_text(text.replace('\\"', '"').replace("\\/", "/")))

    last_error = None

    for candidate in candidates:
        try:
            obj = json.loads(candidate)
        except Exception as exc:
            last_error = exc
            try:
                values = _raw_decode_many(candidate)
                if len(values) == 1:
                    obj = values[0]
                elif len(values) > 1:
                    obj = values
                else:
                    continue
            except Exception as exc2:
                last_error = exc2
                continue

        for _ in range(6):
            if not isinstance(obj, str):
                return obj

            inner = _clean_payload_text(obj)

            if not inner or inner == obj:
                return obj

            try:
                obj = json.loads(inner)
                continue
            except Exception:
                repaired_inner = _repair_signal_json_text(inner)

                if repaired_inner == inner:
                    return obj

                try:
                    obj = json.loads(repaired_inner)
                    continue
                except Exception as exc:
                    last_error = exc
                    return obj

        return obj

    if last_error:
        raise last_error

    raise ValueError("could not parse payload")


def _iter_event_objects(obj):
    if isinstance(obj, dict):
        yield obj
        return

    if isinstance(obj, list):
        for item in obj:
            yield from _iter_event_objects(item)
        return

    if isinstance(obj, str):
        try:
            decoded = _json_load_flexible(obj)
        except Exception:
            return

        if decoded == obj:
            return

        yield from _iter_event_objects(decoded)


def _decode_malformed_value(value):
    value = str(value or "")

    try:
        return json.loads('"' + value + '"')
    except Exception:
        pass

    value = value.replace('\\"', '"')
    value = value.replace("\\/", "/")
    value = value.replace("\\n", "\n")
    value = value.replace("\\r", "\r")
    value = value.replace("\\t", "\t")
    value = value.replace("\\\\", "\\")
    return maybe_fix_mojibake(value)

def _extract_malformed_field(payload, key):
    text = str(payload or "")

    patterns = [
        r'\\"' + re.escape(key) + r'\\"\s*:\s*\\"(.*?)\\"',
        r'"' + re.escape(key) + r'"\s*:\s*"((?:\\.|[^"\\])*)"',
        r'\b' + re.escape(key) + r'\b\s*:\s*\\"(.*?)\\"',
        r'\b' + re.escape(key) + r'\b\s*:\s*"((?:\\.|[^"\\])*)"',
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.DOTALL)

        if match:
            return _decode_malformed_value(match.group(1))

    return ""

def _extract_malformed_timestamp(payload):
    text = str(payload or "")

    patterns = [
        r'\\"timestamp\\"\s*:\s*(\d+)',
        r'"timestamp"\s*:\s*(\d+)',
        r'\\"serverReceivedTimestamp\\"\s*:\s*(\d+)',
        r'"serverReceivedTimestamp"\s*:\s*(\d+)',
    ]

    for pattern in patterns:
        match = re.search(pattern, text)

        if match:
            return coerce_timestamp_ms(match.group(1)) or 0

    return 0

def _synthetic_event_from_malformed_payload(payload):
    text = str(payload or "")

    source = clean_source_value(
        _extract_malformed_field(text, "sourceNumber")
        or _extract_malformed_field(text, "source_number")
        or _extract_malformed_field(text, "source")
    )

    source_name = clean_source_value(
        _extract_malformed_field(text, "sourceName")
        or _extract_malformed_field(text, "source_name")
        or source
    )

    message = (
        _extract_malformed_field(text, "message")
        or _extract_malformed_field(text, "text")
        or _extract_malformed_field(text, "body")
        or _extract_malformed_field(text, "content")
    )

    if not message:
        return None

    timestamp = _extract_malformed_timestamp(text)
    group_value = clean_source_value(
        _extract_malformed_field(text, "groupId")
        or _extract_malformed_field(text, "group_id")
        or _extract_malformed_field(text, "masterKey")
        or _extract_malformed_field(text, "master_key")
        or _extract_malformed_field(text, "groupMasterKey")
    )
    group_name = clean_source_value(
        _extract_malformed_field(text, "groupName")
        or _extract_malformed_field(text, "group_name")
        or _extract_malformed_field(text, "groupTitle")
        or _extract_malformed_field(text, "group_title")
    )
    data_message = {
        "message": message
    }
    if group_value or group_name:
        data_message["groupInfo"] = {
            "groupId": group_value,
            "groupName": group_name,
        }

    envelope = {
        "source": source,
        "sourceNumber": source,
        "sourceName": source_name,
        "timestamp": timestamp,
        "dataMessage": data_message
    }

    return {
        "envelope": envelope
    }

def process_payload(payload):
    cfg = load_config()
    raw_preview = str(payload or "")[:3000]

    try:
        dump_raw_payload(str(payload or ""))
    except Exception:
        pass

    try:
        obj = _json_load_flexible(payload)
    except Exception as exc:
        handled_any = False

        for line in str(payload or "").splitlines():
            line = _clean_payload_text(line)

            if not line or line in {"{}", "[]"}:
                continue

            try:
                line_obj = _json_load_flexible(line)
            except Exception:
                synthetic_line_obj = _synthetic_event_from_malformed_payload(line)

                if synthetic_line_obj:
                    handled_any = True
                    process_event_obj(synthetic_line_obj, cfg)

                continue

            for event_obj in _iter_event_objects(line_obj):
                handled_any = True
                process_event_obj(event_obj, cfg)

        if handled_any:
            return

        synthetic_obj = _synthetic_event_from_malformed_payload(payload)

        if synthetic_obj:
            process_event_obj(synthetic_obj, cfg)
            return

        log_debug({
            "ignored_bad_json_payload": True,
            "error": str(exc),
            "preview": raw_preview,
        })
        return

    handled_any = False

    for event_obj in _iter_event_objects(obj):
        handled_any = True
        process_event_obj(event_obj, cfg)

    if not handled_any:
        synthetic_obj = _synthetic_event_from_malformed_payload(payload)

        if synthetic_obj:
            process_event_obj(synthetic_obj, cfg)
            return

        log_debug({
            "ignored_signal_payload": True,
            "payload_type": type(obj).__name__,
            "preview": raw_preview,
        })

def stream_loop():
    session = requests.Session()
    last_hb = 0.0

    while True:
        try:
            touch_heartbeat()
            write_event("INFO", "Підключаюсь до signal-cli...")
            cfg = load_config()
            events_url = events_url_from_config(cfg)

            with session.get(events_url, stream=True, timeout=(5, 30)) as r:
                r.raise_for_status()
                write_event("OK", "Signal-cli на зв'язку")

                buffer = []

                for raw_line in r.iter_lines(decode_unicode=True, chunk_size=1):
                    if time.time() - last_hb > 5:
                        touch_heartbeat()
                        last_hb = time.time()

                    if raw_line is None:
                        continue

                    line = raw_line.strip()

                    if line == "":
                        if not buffer:
                            continue

                        data_lines = []

                        for item in buffer:
                            if item.startswith("data:"):
                                data_lines.append(item[5:].strip())
                            else:
                                data_lines.append(item.strip())

                        buffer = []

                        payload = "\n".join(x for x in data_lines if x).strip()

                        if not payload or payload == "{}":
                            continue

                        process_payload(payload)
                        continue

                    if line.startswith("{") or line.startswith("["):
                        if buffer:
                            buffer.append(line)
                        else:
                            process_payload(line)
                        continue

                    buffer.append(line)

                write_event("WARN", "Стрім закрився, перепідключаюсь...")
                time.sleep(1)

        except KeyboardInterrupt:
            write_event("WARN", "Listener зупинено руками")
            return

        except requests.exceptions.ReadTimeout:
            write_event("WARN", "ReadTimeout на стрімі, перепідключаюсь...")
            time.sleep(1)

        except Exception as e:
            log_debug({"stream_error": str(e), "time": datetime.now().isoformat()})
            write_event("ERROR", f"Signal стрім обісрався: {e}")
            time.sleep(2)

def main():
    try:
        write_event("INFO", "Піднімаю ГІС...")
        try:
            load_places()
        except Exception as e:
            write_event("WARN", f"ГІС не піднявся ({e}). Listener працює через онлайн-пошук н.п.")
        write_event("OK", "Listener готовий")
        stream_loop()
    except KeyboardInterrupt:
        write_event("WARN", "Listener стоп")
    except Exception as e:
        log_debug({"fatal_error": str(e), "time": datetime.now().isoformat()})
        write_event("ERROR", f"Фатальна пізда: {e}")
        time.sleep(5)


if __name__ == "__main__":
    main()
