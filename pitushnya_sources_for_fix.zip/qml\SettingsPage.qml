import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "components"

Item {
    id: root
    property var themeObj
    property real uiScale: 1.0
    property int baseFontSize: 14
    property string fontFamilyName: "Segoe UI"
    property int leftPanelWidth: 380
    property string currentSection: "Прийом вхідних даних"
    property bool previewAppearanceActive: false
    property real pendingUiScale: backend.uiScale
    property int pendingBaseFontSize: backend.baseFontSize
    property int pendingLeftPanelWidth: backend.leftPanelWidth
    property real pendingTargetPromptScale: Number(backend.getConfig("target_prompt_ui_scale") || 0.7)
    property int pendingTargetPromptFontSize: Number(backend.getConfig("target_prompt_font_size") || 14)
    property int selectedTargetTypeIndex: -1
    property bool targetTypeListHovered: false
    property int uninstallDeleteDodgeStep: 0

    Timer { id: uiScaleDebounce; interval: 90; repeat: false; onTriggered: backend.setUiScale(Math.round(root.pendingUiScale * 100) / 100) }
    Timer { id: fontDebounce; interval: 90; repeat: false; onTriggered: backend.setBaseFontSize(Math.round(root.pendingBaseFontSize)) }
    Timer { id: widthDebounce; interval: 90; repeat: false; onTriggered: backend.setLeftPanelWidth(Math.round(root.pendingLeftPanelWidth)) }
    Timer { id: targetPromptScaleDebounce; interval: 90; repeat: false; onTriggered: backend.setConfigFloat("target_prompt_ui_scale", Math.round(root.pendingTargetPromptScale * 100) / 100) }
    Timer { id: targetPromptFontDebounce; interval: 90; repeat: false; onTriggered: backend.setConfigInt("target_prompt_font_size", Math.round(root.pendingTargetPromptFontSize)) }

    function px(v) { return Math.max(1, Math.round(v * uiScale)); }
    function fs(mult) { return Math.max(10, Math.round(baseFontSize * mult * uiScale)); }
    function isHelloKitty() { return themeObj && themeObj.name === "Hello Kitty"; }
    function panelFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.90, 0.96, 0.54) : fallback; }
    function panelAltFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.84, 0.92, 0.48) : fallback; }
    function panelSoftFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.78, 0.88, 0.44) : fallback; }
    function inputFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.94, 0.98, 0.60) : fallback; }
    function isCurrent(sectionName) { return currentSection === sectionName; }
    function coordInputChecked(name) {
        var items = backend.configMap["coord_input_systems"] || []
        return items.indexOf(name) >= 0
    }
    function setCoordInputChecked(name, enabled) {
        var items = (backend.configMap["coord_input_systems"] || []).slice(0)
        var idx = items.indexOf(name)
        if (enabled && idx < 0)
            items.push(name)
        else if (!enabled && idx >= 0)
            items.splice(idx, 1)
        backend.setConfigListFromText("coord_input_systems", items.join("\n"))
    }

    readonly property var sectionsModel: [
        "Прийом вхідних даних",
        "Базове і шаблони",
        "Майстер цілі",
        "Лог і статистика",
        "Шляхи",
        "Вигляд",
        "Оновлення"
    ]

    component FieldLabel: Text {
        color: root.themeObj.textMuted
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(0.78)
        font.bold: true
        wrapMode: Text.WordWrap
        Layout.fillWidth: true
    }

    component SectionHeader: Text {
        color: root.themeObj.text
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(1.02)
        font.bold: true
        wrapMode: Text.WordWrap
        Layout.fillWidth: true
    }

    component DividerLine: Rectangle {
        Layout.fillWidth: true
        Layout.preferredHeight: 1
        color: root.themeObj.cardBorder
        opacity: 0.9
    }

    component HoverTip: HoverHandler { }

    component InputField: TextField {
        id: inputField
        property string hint: ""
        Layout.fillWidth: true
        selectByMouse: true
        color: root.themeObj.text
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(0.8)
        font.bold: true
        padding: root.px(10)
        background: Rectangle {
            radius: root.px(8)
            color: root.inputFill(root.themeObj.input)
            border.color: root.themeObj.inputBorder
            border.width: 1
        }
        HoverHandler { id: hh }
        HintToolTip {
            visible: inputField.hint.length > 0 && hh.hovered
            text: inputField.hint
            themeObj: root.themeObj
            uiScale: root.uiScale
            fontFamilyName: root.fontFamilyName
        }
    }

    component ConfigField: InputField {
        id: control
        property string configKey: ""
        property bool saveAsInt: false
        property bool saveAsFloat: false
        property bool saveAsAux: false
        property bool _ready: false
        Component.onCompleted: _ready = true
        Timer {
            id: saveTimer
            interval: 350
            repeat: false
            onTriggered: {
                if (!control.configKey)
                    return
                if (control.saveAsInt)
                    backend.setConfigInt(control.configKey, Number(control.text))
                else if (control.saveAsFloat)
                    backend.setConfigFloat(control.configKey, Number(control.text))
                else
                    backend.setConfigValue(control.configKey, control.text)
                if (control.saveAsAux)
                    backend.saveAuxFiles()
            }
        }
        onTextChanged: if (_ready) saveTimer.restart()
    }

    component InputArea: TextArea {
        id: area
        property string hint: ""
        Layout.fillWidth: true
        Layout.preferredHeight: root.px(120)
        selectByMouse: true
        wrapMode: TextEdit.Wrap
        color: root.themeObj.text
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(0.78)
        font.bold: true
        padding: root.px(10)
        background: Rectangle {
            radius: root.px(8)
            color: root.inputFill(root.themeObj.input)
            border.color: root.themeObj.inputBorder
            border.width: 1
        }
        HoverHandler { id: hh }
        HintToolTip {
            visible: area.hint.length > 0 && hh.hovered
            text: area.hint
            themeObj: root.themeObj
            uiScale: root.uiScale
            fontFamilyName: root.fontFamilyName
        }
    }

    component ConfigArea: InputArea {
        id: areaControl
        property string configKey: ""
        property bool listMode: false
        property bool saveAsAux: false
        property bool _ready: false
        Component.onCompleted: _ready = true
        Timer {
            id: areaSaveTimer
            interval: 450
            repeat: false
            onTriggered: {
                if (!areaControl.configKey)
                    return
                if (areaControl.listMode)
                    backend.setConfigListFromText(areaControl.configKey, areaControl.text)
                else
                    backend.setConfigValue(areaControl.configKey, areaControl.text)
                if (areaControl.saveAsAux)
                    backend.saveAuxFiles()
            }
        }
        onTextChanged: if (_ready) areaSaveTimer.restart()
    }

    component ToggleRow: Item {
        id: toggleRoot
        property string text: ""
        property string hint: ""
        property bool checked: false
        signal toggled(bool checked)
        Layout.fillWidth: true
        implicitHeight: root.px(34)

        RowLayout {
            anchors.fill: parent
            spacing: root.px(10)
            Rectangle {
                Layout.preferredWidth: root.px(46)
                Layout.preferredHeight: root.px(24)
                radius: height / 2
                color: toggleRoot.checked ? root.themeObj.accent : root.inputFill(root.themeObj.input)
                border.color: toggleRoot.checked ? Qt.darker(root.themeObj.accent, 1.08) : root.themeObj.inputBorder
                border.width: 1
                Rectangle {
                    width: root.px(18)
                    height: root.px(18)
                    radius: width / 2
                    y: root.px(3)
                    x: toggleRoot.checked ? parent.width - width - root.px(3) : root.px(3)
                    color: "#ffffff"
                    border.color: root.themeObj.inputBorder
                    border.width: 1
                }
            }
            Text {
                Layout.fillWidth: true
                text: toggleRoot.text
                color: root.themeObj.text
                font.family: root.fontFamilyName
                font.pixelSize: root.fs(0.8)
                font.bold: true
                wrapMode: Text.WordWrap
            }
        }
        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                toggleRoot.checked = !toggleRoot.checked
                toggleRoot.toggled(toggleRoot.checked)
            }
        }
        HoverHandler { id: hover }
        HintToolTip {
            visible: hover.hovered && toggleRoot.hint.length > 0
            text: toggleRoot.hint
            themeObj: root.themeObj
            uiScale: root.uiScale
            fontFamilyName: root.fontFamilyName
        }
    }

    component ConfigToggle: ToggleRow {
        property string configKey: ""
        property bool saveAsAux: false
        property bool _ready: false
        Component.onCompleted: _ready = true
        onToggled: function(value) {
            if (!_ready || !configKey)
                return
            backend.setConfigBool(configKey, value)
            if (saveAsAux)
                backend.saveAuxFiles()
        }
    }

    component StyledCombo: ComboBox {
        id: comboRoot
        property string hint: ""
        Layout.fillWidth: true
        implicitHeight: root.px(42)
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(0.8)
        font.bold: true
        background: Rectangle {
            radius: root.px(8)
            color: root.panelSoftFill(root.themeObj.panelSoft)
            border.color: root.themeObj.accent2
            border.width: 1
        }
        contentItem: Text {
            leftPadding: root.px(12)
            rightPadding: root.px(28)
            text: comboRoot.displayText
            color: root.themeObj.text
            font.family: root.fontFamilyName
            font.pixelSize: root.fs(0.8)
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }
        indicator: Canvas {
            x: parent.width - width - root.px(10)
            y: parent.height / 2 - height / 2
            width: root.px(12)
            height: root.px(8)
            contextType: "2d"
            onPaint: {
                context.reset()
                context.moveTo(0, 0)
                context.lineTo(width, 0)
                context.lineTo(width / 2, height)
                context.closePath()
                context.fillStyle = root.themeObj.accent2
                context.fill()
            }
        }
        delegate: ItemDelegate {
            width: ListView.view ? ListView.view.width : comboRoot.width
            height: root.px(38)
            contentItem: Text {
                text: modelData
                color: root.themeObj.text
                font.family: root.fontFamilyName
                font.pixelSize: root.fs(0.8)
                font.bold: true
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }
            background: Rectangle {
                radius: root.px(6)
                color: highlighted ? root.themeObj.accent2 : root.panelSoftFill(root.themeObj.panelSoft)
                border.color: highlighted ? Qt.lighter(root.themeObj.accent2, 1.08) : root.themeObj.inputBorder
                border.width: 1
            }
        }
        popup: Popup {
            parent: Overlay.overlay
            x: comboRoot.mapToItem(Overlay.overlay, 0, 0).x
            y: comboRoot.mapToItem(Overlay.overlay, 0, comboRoot.height + root.px(6)).y
            width: comboRoot.width
            implicitHeight: Math.min(contentItem.implicitHeight + root.px(2), root.px(240))
            padding: 1
            z: 10000
            closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
            onOpened: {
                var p = comboRoot.mapToItem(Overlay.overlay, 0, comboRoot.height + root.px(6))
                x = p.x
                y = p.y
            }
            background: Rectangle {
                radius: root.px(8)
                color: root.inputFill(root.themeObj.input)
                border.color: root.themeObj.accent2
                border.width: 2
            }
            contentItem: ListView {
                clip: true
                implicitHeight: contentHeight
                model: comboRoot.popup.visible ? comboRoot.delegateModel : null
                currentIndex: comboRoot.highlightedIndex
                ScrollBar.vertical: AppScrollBar {
    themeObj: root.themeObj
    uiScale: root.uiScale
}
            }
        }
        HoverHandler { id: hover }
        HintToolTip {
            visible: comboRoot.hint.length > 0 && hover.hovered
            text: comboRoot.hint
            themeObj: root.themeObj
            uiScale: root.uiScale
            fontFamilyName: root.fontFamilyName
        }
    }

    component ConfigCombo: StyledCombo {
        property string configKey: ""
        property bool saveAsAux: false
        onActivated: {
            if (!configKey)
                return
            backend.setConfigValue(configKey, currentText)
            if (saveAsAux)
                backend.saveAuxFiles()
        }
    }

    component ValueSlider: Slider {
        id: slider
        property string hint: ""
        Layout.fillWidth: true
        live: true
        HoverHandler { id: hover }
        HintToolTip {
            visible: slider.hint.length > 0 && hover.hovered
            text: slider.hint
            themeObj: root.themeObj
            uiScale: root.uiScale
            fontFamilyName: root.fontFamilyName
        }
    }

    component InfoTextBlock: Text {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: root.themeObj.textMuted
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(0.82)
        font.bold: true
    }

    Popup {
        id: uninstallConfirmFirst
        modal: true
        dim: true
        focus: true
        closePolicy: Popup.CloseOnEscape
        width: Math.min(root.px(470), root.width - root.px(48))
        x: Math.round((root.width - width) / 2)
        y: Math.round((root.height - height) / 2)
        padding: root.px(14)
        Overlay.modal: Rectangle { color: Qt.rgba(0, 0, 0, 0.58) }
        background: Rectangle {
            radius: root.px(10)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.danger || "#ef4444"
            border.width: 1
        }
        contentItem: ColumnLayout {
            spacing: root.px(14)
            Text {
                Layout.fillWidth: true
                text: "Точно впевнений?"
                color: root.themeObj.text
                font.family: root.fontFamilyName
                font.pixelSize: root.fs(1.15)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: root.px(10)
                ActionButton {
                    Layout.fillWidth: true
                    label: "НЕ видалити"
                    fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                    hoverColor: root.themeObj.hoverFill
                    textColor: root.themeObj.text
                    themeObj: root.themeObj
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName
                    fontSize: root.baseFontSize - 1
                    onClicked: uninstallConfirmFirst.close()
                }
                ActionButton {
                    Layout.fillWidth: true
                    label: "Видалити"
                    fillColor: "#ef4444"
                    hoverColor: "#dc2626"
                    textColor: "#ffffff"
                    themeObj: root.themeObj
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName
                    fontSize: root.baseFontSize - 1
                    onClicked: {
                        uninstallConfirmFirst.close()
                        root.uninstallDeleteDodgeStep = 0
                        uninstallConfirmSecond.open()
                    }
                }
            }
        }
    }

    Popup {
        id: uninstallConfirmSecond
        modal: true
        dim: true
        focus: true
        closePolicy: Popup.CloseOnEscape
        width: Math.min(root.px(560), root.width - root.px(48))
        x: Math.round((root.width - width) / 2)
        y: Math.round((root.height - height) / 2)
        padding: root.px(14)
        Overlay.modal: Rectangle { color: Qt.rgba(0, 0, 0, 0.62) }
        background: Rectangle {
            radius: root.px(10)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.danger || "#ef4444"
            border.width: 1
        }
        contentItem: ColumnLayout {
            spacing: root.px(14)
            Text {
                Layout.fillWidth: true
                text: "Може б ти ще подумав трохи?"
                color: root.themeObj.text
                font.family: root.fontFamilyName
                font.pixelSize: root.fs(1.12)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
            }
            Item {
                Layout.fillWidth: true
                Layout.preferredHeight: root.px(46)
                property real gap: root.px(10)
                property real deleteWidth: Math.min(root.px(190), Math.max(root.px(150), width * 0.40))
                property real cancelWidth: Math.max(root.px(190), width - deleteWidth - gap)

                ActionButton {
                    id: finalDeleteButton
                    width: parent.deleteWidth
                    height: parent.height
                    x: root.uninstallDeleteDodgeStep === 1 ? parent.width - width : 0
                    label: "ТАК ВИДАЛИТИ!"
                    fillColor: "#ef4444"
                    hoverColor: "#dc2626"
                    textColor: "#ffffff"
                    themeObj: root.themeObj
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName
                    fontSize: root.baseFontSize - 1
                    onClicked: {
                        uninstallConfirmSecond.close()
                        backend.runForceUninstall()
                    }
                    Behavior on x {
                        NumberAnimation { duration: 160; easing.type: Easing.OutCubic }
                    }
                    HoverHandler {
                        onHoveredChanged: {
                            if (hovered && root.uninstallDeleteDodgeStep < 2)
                                root.uninstallDeleteDodgeStep += 1
                        }
                    }
                }

                ActionButton {
                    width: parent.cancelWidth
                    height: parent.height
                    x: root.uninstallDeleteDodgeStep === 1 ? 0 : finalDeleteButton.width + parent.gap
                    label: "НЕ видаляти"
                    fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                    hoverColor: root.themeObj.hoverFill
                    textColor: root.themeObj.text
                    themeObj: root.themeObj
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName
                    fontSize: root.baseFontSize - 1
                    wrap: true
                    onClicked: uninstallConfirmSecond.close()
                    Behavior on x {
                        NumberAnimation { duration: 160; easing.type: Easing.OutCubic }
                    }
                }
            }
        }
    }

    RowLayout {
        anchors.fill: parent
        spacing: root.px(8)

        Rectangle {
            Layout.preferredWidth: Math.max(root.px(230), Math.min(root.px(280), root.leftPanelWidth * 0.70))
            Layout.fillHeight: true
            radius: root.px(10)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.cardBorder
            border.width: 1

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: root.px(8)
                spacing: root.px(8)
                Repeater {
                    model: root.sectionsModel
                    delegate: Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: root.px(40)
                        radius: root.px(9)
                        color: root.currentSection === modelData ? root.themeObj.accent : root.panelSoftFill(root.themeObj.panelSoft)
                        border.color: root.currentSection === modelData ? Qt.darker(root.themeObj.accent, 1.08) : root.themeObj.cardBorder
                        border.width: 1
                        Text {
                            anchors.centerIn: parent
                            width: parent.width - root.px(18)
                            text: modelData
                            color: root.currentSection === modelData ? "#ffffff" : root.themeObj.text
                            font.family: root.fontFamilyName
                            font.pixelSize: root.fs(0.78)
                            font.bold: true
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                        }
                        MouseArea {
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                root.currentSection = modelData
                                backend.logUiAction("settings_section", String(modelData))
                            }
                        }
                        HoverHandler { id: sectionHover }
                        HintToolTip {
                            visible: sectionHover.hovered
                            text: "Відкрити розділ «" + modelData + "»"
                            themeObj: root.themeObj
                            uiScale: root.uiScale
                            fontFamilyName: root.fontFamilyName
                        }
                    }
                }
                ActionButton {
                    Layout.fillWidth: true
                    Layout.preferredHeight: root.px(42)
                    label: "Видалити додаток"
                    hint: "Запускає force_uninstall_pitushnya.cmd з папки встановленої PITUSHNYA MCC. Спершу ще двічі перепитаю, бо кнопка не для випадкового тицяння."
                    fillColor: "#ef4444"
                    hoverColor: "#dc2626"
                    textColor: "#ffffff"
                    themeObj: root.themeObj
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName
                    fontSize: root.baseFontSize - 2
                    wrap: true
                    onClicked: {
                        backend.logUiAction("open_force_uninstall_confirm", "")
                        root.uninstallDeleteDodgeStep = 0
                        uninstallConfirmFirst.open()
                    }
                }
                Item { Layout.fillHeight: true }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: root.px(10)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.cardBorder
            border.width: 1
            clip: true

            Flickable {
                id: contentFlick
                anchors.fill: parent
                anchors.margins: root.px(10)
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                contentWidth: width
                contentHeight: contentColumn.implicitHeight
                interactive: !root.targetTypeListHovered

                ColumnLayout {
                    id: contentColumn
                    width: contentFlick.width
                    spacing: root.px(10)

                    RowLayout {
                        Layout.fillWidth: true
                        Text {
                            text: root.currentSection
                            color: root.themeObj.text
                            font.family: root.fontFamilyName
                            font.pixelSize: root.fs(1.18)
                            font.bold: true
                        }
                        Item { Layout.fillWidth: true }
                        ActionButton {
                            visible: true
                            Layout.preferredWidth: root.px(180)
                            label: "Зберегти зараз"
                            hint: "Кнопка для спокою душі. Усі зміни і так застосовуються одразу."
                            fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                            hoverColor: root.themeObj.hoverFill
                            textColor: root.themeObj.text
                            fontSize: root.baseFontSize - 2
                            uiScale: root.uiScale
                            fontFamilyName: root.fontFamilyName
                            onClicked: backend.saveNow()
                        }
                    }

                    CardPanel {
                        visible: root.isCurrent("Прийом вхідних даних")
                        Layout.fillWidth: true
                        title: "Прийом вхідних даних"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        ConfigToggle { text: "Прийом корів увімкнений"; hint: "Головний рубильник обробки координат. Якщо вимкнути, ні Signal, ні буфер не повинні запускати нову ціль."; configKey: "receiver_enabled"; checked: backend.getConfigBool("receiver_enabled") }
                        ConfigToggle { text: "Дозволити групи/чати"; hint: "Вмикає обробку групових повідомлень Signal. Якщо вимкнено, групові події ігноруються навіть коли listener їх бачить."; configKey: "receiver_accept_groups"; checked: backend.getConfigBool("receiver_accept_groups") }
                        FieldLabel { text: "Режим особистих" }
                        ConfigCombo { configKey: "receiver_personal_mode"; hint: "Всі особисті повідомлення або лише список дозволених контактів."; model: backend.receiverPersonalModes; currentIndex: Math.max(0, backend.receiverPersonalModes.indexOf(backend.getConfigString("receiver_personal_mode"))) }
                        FieldLabel { text: "Режим груп/чатів" }
                        ConfigCombo { configKey: "receiver_group_mode"; hint: "Всі групи або тільки перелік дозволених груп."; model: backend.receiverGroupModes; currentIndex: Math.max(0, backend.receiverGroupModes.indexOf(backend.getConfigString("receiver_group_mode"))) }
                        FieldLabel { text: "Джерело корів" }
                        ConfigCombo { configKey: "receiver_capture_mode"; hint: "Вибирає одне джерело корів: або Signal, або буфер. Комбінований режим прибрано, щоб координати не дублювались і не змішували різні цикли."; model: backend.receiverCaptureModes; currentIndex: Math.max(0, backend.receiverCaptureModes.indexOf(backend.getConfigString("receiver_capture_mode"))) }
                        InfoTextBlock { text: "У режимі «signal» додаток повністю ігнорує буфер. У режимі «буфер» Signal-події повністю ігноруються. Буфер реагує тільки на новий текст після запуску програми або після перемикання режиму, тому старі координати не мають самі відкривати майстер." }
                        DividerLine { }
                        SectionHeader { text: "Координати" }
                        FieldLabel { text: "Вихідна система координат" }
                        ConfigCombo { configKey: "coord_output_system"; hint: "Формат, який піде у фінальне повідомлення. Вхід може бути будь-яким підтриманим, але на виході буде саме цей варіант."; model: backend.coordOutputOptions; currentIndex: Math.max(0, backend.coordOutputOptions.indexOf(backend.getConfigString("coord_output_system"))) }
                        FieldLabel { text: "Вхідні координати" }
                        InfoTextBlock { text: "Вхід працює автоматично: MGRS, GEO decimal, GEO градуси-хвилини, GEO DMS і варіанти СК-42 розпізнаються без окремих галочок. Усередині все приводиться до MGRS для пошуку н.п., а у фінальний текст вставляється формат з поля «Вихідна система координат»." }
                        FieldLabel { text: "Дозволені абоненти. Один у рядок" }
                        ConfigArea { configKey: "receiver_allowed_senders"; hint: "Список номерів або імен для особистих чатів. Один запис на рядок."; listMode: true; text: backend.getConfigListText("receiver_allowed_senders") }
                        FieldLabel { text: "Дозволені чати/групи. Один у рядок" }
                        ConfigArea { configKey: "receiver_allowed_groups"; hint: "Список назв або ID груп. Один запис на рядок."; listMode: true; text: backend.getConfigListText("receiver_allowed_groups") }
                    }

                    CardPanel {
                        visible: root.isCurrent("Базове і шаблони")
                        Layout.fillWidth: true
                        title: "Базове"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        FieldLabel { text: "Позивний" }
                        ConfigField { configKey: "callsign"; hint: "Позивний екіпажу. Потрапляє в шаблони, логіку listener і службові файли."; saveAsAux: true; text: backend.configMap["callsign"] || "" }
                        InfoTextBlock { text: "Прив'язаний акаунт Signal: " + (backend.getConfigString("signal_number") || "ще не підтягнувся після QR") }
                        ConfigToggle { text: "Автостарт при запуску"; hint: "Після запуску програми одразу тисне старт модулів. Вмикай тільки якщо вже все перевірив."; configKey: "auto_start_on_launch"; checked: backend.getConfigBool("auto_start_on_launch") }
                        ConfigToggle {
                            text: "Згортати в трей при запуску"
                            hint: "Після відкриття PITUSHNYA MCC сховається в трей. Модулі можуть працювати у фоні, а ти не дивишся на вікно як на ікону страждання."
                            configKey: "minimize_to_tray_on_launch"
                            checked: backend.getConfigBool("minimize_to_tray_on_launch")
                        }

                        ConfigToggle {
                            text: "Показувати інструкцію після готовності"
                            hint: "Коли всі модулі запустились і система реально готова, відкриває коротке вікно з алгоритмом роботи."
                            configKey: "show_instruction_on_ready"
                            checked: backend.getConfigBool("show_instruction_on_ready")
                        }
                        DividerLine { }
                        SectionHeader { text: "Шаблони і гарячі клавіші" }
                        FieldLabel { text: "Шаблон: фіксація часу" }

                        ConfigArea {
                            id: timeTemplateArea
                            configKey: "message_template_time_fix"
                            hint: "Текст, який вставляється при першому скріні нового циклу. Обов'язкова змінна: {time}. Можна також використати {callsign}."
                            saveAsAux: true
                            text: backend.getConfigString("message_template_time_fix")
                        }

                        FieldLabel { text: "Шаблон: коли прилетіли кори" }

                        ConfigArea {
                            id: coordsTemplateArea
                            configKey: "message_template_coords"
                            hint: "Фінальний шаблон повідомлення після майстра цілі. Доступні змінні: {time}, {callsign}, {targets}, {mgrs}, {place}, {direction}. Їх можна переставляти як хочеш."
                            saveAsAux: true
                            text: backend.getConfigString("message_template_coords")
                        }

                        InfoTextBlock {
                            text: "Доступні змінні: {time} - час, {callsign} - позивний, {targets} - типи й кількість цілей, {mgrs} - координати у вибраному вихідному форматі, {place} - населений пункт, {direction} - напрямок руху. Саме цей шаблон формує фінальний текст після майстра цілі."
                        }

                        ActionButton {
                            Layout.fillWidth: true
                            label: "Відновити дефолтні текстові шаблони"
                            hint: "Повертає початковий шаблон фіксації часу і фінального повідомлення, якщо ти випадково зробив із шаблону фарш."
                            fillColor: root.themeObj.warning
                            hoverColor: Qt.lighter(root.themeObj.warning, 1.05)
                            textColor: "#ffffff"
                            hoverTextColor: "#ffffff"
                            fontSize: root.baseFontSize - 2
                            uiScale: root.uiScale
                            fontFamilyName: root.fontFamilyName
                            onClicked: {
                                if (backend.restoreDefaultMessageTemplates()) {
                                    timeTemplateArea.text = backend.getConfigString("message_template_time_fix")
                                    coordsTemplateArea.text = backend.getConfigString("message_template_coords")
                                }
                            }
                        }

                        FieldLabel { text: "Гарячі клавіші" }
                        ConfigArea { configKey: "hotkeys_description"; hint: "Опис гарячих клавіш. Показується на головній вкладці."; saveAsAux: true; text: backend.getConfigString("hotkeys_description") }
                    }

                    CardPanel {
                        visible: root.isCurrent("Майстер цілі")
                        Layout.fillWidth: true
                        title: "Майстер цілі"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        SectionHeader { text: "Майстер цілі" }
                        ConfigToggle { text: "Увімкнути майстер цілі"; hint: "Після обробки корів відкриває окреме вікно вибору типу, кількості й напрямку."; configKey: "target_prompt_enabled"; checked: backend.getConfigBool("target_prompt_enabled") }
                        FieldLabel { text: "Режим майстра" }
                        ConfigCombo { configKey: "target_prompt_mode"; hint: "Послідовний режим по кроках або все в одному невеликому вікні."; model: backend.targetPromptModes; currentIndex: Math.max(0, backend.targetPromptModes.indexOf(backend.getConfigString("target_prompt_mode"))) }
                        FieldLabel { text: "Розмір шрифту майстра: " + String(Math.round(root.pendingTargetPromptFontSize)) }
                        ValueSlider { hint: "Окремий розмір тексту у вікні майстра цілі. Рухаєш бігунок - нові вікна майстра відкриватимуться з цим розміром."; from: 11; to: 24; stepSize: 1; value: root.pendingTargetPromptFontSize; onMoved: { root.pendingTargetPromptFontSize = value; targetPromptFontDebounce.restart(); } onPressedChanged: if (!pressed) backend.setConfigInt("target_prompt_font_size", Math.round(value)) }
                        FieldLabel { text: "Масштаб інтерфейсу майстра: " + Number(root.pendingTargetPromptScale).toFixed(2) }
                        ValueSlider { hint: "Окремий масштаб майстра цілі. Впливає на ширину списків, кнопки, поля кількості, відступи й мінімальний розмір вікна."; from: 0.70; to: 1.30; stepSize: 0.01; value: root.pendingTargetPromptScale; onMoved: { root.pendingTargetPromptScale = value; targetPromptScaleDebounce.restart(); } onPressedChanged: if (!pressed) backend.setConfigFloat("target_prompt_ui_scale", Math.round(value * 100) / 100) }
                        ConfigToggle { text: "Підлаштовувати під поточну тему?"; hint: "Коли увімкнено, майстер бере кольори з теми основного інтерфейсу. Коли вимкнено, лишається стабільна темна схема, щоб майстер завжди виглядав однаково."; configKey: "target_prompt_follow_theme"; checked: backend.getConfigBool("target_prompt_follow_theme") }
                        ConfigToggle { text: "Запускати майстер цілей з однакових координат"; hint: "Якщо увімкнено, однакові кори можуть знову відкривати майстер. Корисно, коли по тих самих координатах треба подати іншу ціль. Якщо вимкнено, дублікати гасяться."; configKey: "target_prompt_allow_same_coords"; checked: backend.getConfigBool("target_prompt_allow_same_coords") }
                        InfoTextBlock { text: "Майстер відкривається після готових координат. Якщо закрити його хрестиком, цикл вважається завершеним: наступний перший скрін почне нову ціль і зафіксує новий час." }
                        FieldLabel { text: "Типи цілей" }
                        Rectangle {
                            Layout.fillWidth: true
                            Layout.preferredHeight: root.px(500)
                            radius: root.px(10)
                            color: root.inputFill(root.themeObj.input)
                            border.color: root.themeObj.inputBorder
                            border.width: 1
                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: root.px(10)
                                spacing: root.px(10)
                                ListView {
                                    id: targetTypeList
                                    Layout.fillWidth: true
                                    Layout.preferredWidth: root.px(420)
                                    Layout.fillHeight: true
                                    clip: true
                                    spacing: root.px(6)
                                    boundsBehavior: Flickable.StopAtBounds
                                    flickDeceleration: 1800
                                    ScrollBar.vertical: AppScrollBar {
    themeObj: root.themeObj
    uiScale: root.uiScale
}
                                    model: backend.targetTypeItems
                                    currentIndex: root.selectedTargetTypeIndex
                                    HoverHandler { onHoveredChanged: root.targetTypeListHovered = hovered }
                                    delegate: Rectangle {
                                        width: ListView.view.width
                                        height: root.px(42)
                                        radius: root.px(8)
                                        color: index === root.selectedTargetTypeIndex ? root.themeObj.accent2 : root.panelSoftFill(root.themeObj.panelSoft)
                                        border.color: index === root.selectedTargetTypeIndex ? Qt.darker(root.themeObj.accent2, 1.08) : root.themeObj.cardBorder
                                        border.width: 1
                                        Text {
                                            anchors.verticalCenter: parent.verticalCenter
                                            anchors.left: parent.left
                                            anchors.leftMargin: root.px(12)
                                            anchors.right: parent.right
                                            anchors.rightMargin: root.px(36)
                                            text: "↕  " + String(modelData)
                                            color: index === root.selectedTargetTypeIndex ? "#ffffff" : root.themeObj.text
                                            font.family: root.fontFamilyName
                                            font.pixelSize: root.fs(0.82)
                                            font.bold: true
                                            elide: Text.ElideRight
                                        }
                                        MouseArea {
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            cursorShape: Qt.PointingHandCursor
                                            onClicked: {
                                                root.selectedTargetTypeIndex = index
                                                newTargetTypeField.text = String(modelData)
                                            }
                                        }
                                    }
                                }
                                ColumnLayout {
                                    Layout.preferredWidth: root.px(210)
                                    Layout.fillHeight: true
                                    spacing: root.px(8)
                                    TextField {
                                        id: newTargetTypeField
                                        Layout.fillWidth: true
                                        placeholderText: "Новий або нова назва"
                                        color: root.themeObj.text
                                        font.family: root.fontFamilyName
                                        font.pixelSize: root.fs(0.8)
                                        font.bold: true
                                        padding: root.px(10)
                                        background: Rectangle { radius: root.px(8); color: root.inputFill(root.themeObj.input); border.color: root.themeObj.inputBorder; border.width: 1 }
                                    }
                                    ActionButton { Layout.fillWidth: true; label: "Додати"; fillColor: root.themeObj.accent2; hoverColor: Qt.lighter(root.themeObj.accent2, 1.05); fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: { backend.addTargetType(newTargetTypeField.text); newTargetTypeField.text = ""; root.selectedTargetTypeIndex = backend.targetTypeItems.length - 1 } }
                                    ActionButton { Layout.fillWidth: true; label: "Перейменувати"; fillColor: root.panelSoftFill(root.themeObj.panelSoft); hoverColor: root.themeObj.hoverFill; textColor: root.themeObj.text; fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: if (root.selectedTargetTypeIndex >= 0) backend.renameTargetType(root.selectedTargetTypeIndex, newTargetTypeField.text) }
                                    ActionButton { Layout.fillWidth: true; label: "Вгору"; fillColor: root.panelSoftFill(root.themeObj.panelSoft); hoverColor: root.themeObj.hoverFill; textColor: root.themeObj.text; fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: if (root.selectedTargetTypeIndex > 0) { backend.moveTargetType(root.selectedTargetTypeIndex, -1); root.selectedTargetTypeIndex -= 1 } }
                                    ActionButton { Layout.fillWidth: true; label: "Вниз"; fillColor: root.panelSoftFill(root.themeObj.panelSoft); hoverColor: root.themeObj.hoverFill; textColor: root.themeObj.text; fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: if (root.selectedTargetTypeIndex >= 0 && root.selectedTargetTypeIndex < backend.targetTypeItems.length - 1) { backend.moveTargetType(root.selectedTargetTypeIndex, 1); root.selectedTargetTypeIndex += 1 } }
                                    ActionButton { Layout.fillWidth: true; label: "Видалити"; fillColor: root.themeObj.danger; hoverColor: Qt.lighter(root.themeObj.danger, 1.05); fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: if (root.selectedTargetTypeIndex >= 0) { backend.removeTargetType(root.selectedTargetTypeIndex); root.selectedTargetTypeIndex = -1; newTargetTypeField.text = "" } }
                                    ActionButton { Layout.fillWidth: true; label: "Скинути"; fillColor: root.themeObj.warning; hoverColor: Qt.lighter(root.themeObj.warning, 1.05); textColor: "#ffffff"; fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: { backend.resetTargetTypes(); root.selectedTargetTypeIndex = -1; newTargetTypeField.text = "" } }
                                    Item { Layout.fillHeight: true }
                                    Text { Layout.fillWidth: true; text: "Порядок у списку = порядок у майстрі цілі. У майстрі також можна перетягувати типи мишею, і порядок одразу збережеться тут."; color: root.themeObj.textMuted; wrapMode: Text.WordWrap; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.74); font.bold: true }
                                }
                            }
                        }
                    }

                    CardPanel {
                        visible: root.isCurrent("Лог і статистика")
                        Layout.fillWidth: true
                        title: "Лог і статистика"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        FieldLabel { text: "Режим статистики" }
                        ConfigCombo { configKey: "stats_mode"; hint: "Показувати лічильники за весь час або тільки за поточний запуск."; model: backend.statsModes; currentIndex: Math.max(0, backend.statsModes.indexOf(backend.getConfigString("stats_mode"))) }
                        FieldLabel { text: "Оновлення статусу (мс)" }
                        ConfigField { configKey: "status_poll_ms"; hint: "Як часто перевіряти модулі зверху. Менше число = більше навантаження."; saveAsInt: true; text: backend.getConfigString("status_poll_ms") }
                        FieldLabel { text: "Оновлення логу (мс)" }
                        ConfigField { configKey: "log_poll_ms"; hint: "Як часто підтягувати нові рядки логу. Не став занадто мало, якщо не хочеш фризи."; saveAsInt: true; text: backend.getConfigString("log_poll_ms") }
                        FieldLabel { text: "Максимум рядків логу" }
                        ConfigField { configKey: "max_log_lines"; hint: "Скільки останніх рядків тримати у вікні. Більше = важче дихає інтерфейс."; saveAsInt: true; text: backend.getConfigString("max_log_lines") }
                        ConfigToggle { text: "Автопрокрутка логу"; hint: "Автоматично прокручує лог донизу, коли з'являються нові записи."; configKey: "auto_scroll_log"; checked: backend.getConfigBool("auto_scroll_log") }

                    }

                    CardPanel {
                        visible: root.isCurrent("Шляхи")
                        Layout.fillWidth: true
                        title: "Шляхи"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        FieldLabel { text: "Папка зі скрінами" }
                        ConfigField { configKey: "screenshots_path"; hint: "Папка, з якої реально рахуються скріни. По дефолту має бути C:\\Users\\User\\Documents\\ShareX\\Screenshots."; text: backend.getConfigString("screenshots_path") }
                        FieldLabel { text: "Шлях до Signal.exe" }
                        ConfigField { configKey: "signal_exe"; hint: "Повний шлях до Signal Desktop."; text: backend.getConfigString("signal_exe") }
                        FieldLabel { text: "Шлях до signal-cli.bat" }
                        ConfigField { configKey: "signal_cli_bat"; hint: "Батник запуску signal-cli."; text: backend.getConfigString("signal_cli_bat") }
                        FieldLabel { text: "HTTP signal-cli" }
                        ConfigField { configKey: "signal_cli_http"; hint: "Адреса HTTP API signal-cli. Зазвичай 127.0.0.1:7583."; text: backend.getConfigString("signal_cli_http") }
                        FieldLabel { text: "ShareX.exe" }
                        ConfigField { configKey: "sharex_exe"; hint: "Шлях до ShareX.exe."; text: backend.getConfigString("sharex_exe") }
                        FieldLabel { text: "Шлях до AutoHotkey" }
                        ConfigField { configKey: "ahk_exe"; hint: "Шлях до AutoHotkey64.exe."; text: backend.getConfigString("ahk_exe") }
                        FieldLabel { text: "Скрипт AHK" }
                        ConfigField { configKey: "ahk_script"; hint: "Основний AHK-скрипт автоматизації."; text: backend.getConfigString("ahk_script") }
                        FieldLabel { text: "Listener" }
                        ConfigField { configKey: "listener_script"; hint: "Python-скрипт listener, який читає кори і пише READY-файл."; text: backend.getConfigString("listener_script") }
                        FieldLabel { text: "Python" }
                        ConfigField { configKey: "python_exe"; hint: "Інтерпретатор Python для listener. Якщо є папка python всередині проєкту, вона підхопиться автоматично."; text: backend.getConfigString("python_exe") }
                    }

                    CardPanel {
                        visible: root.isCurrent("Вигляд")
                        Layout.fillWidth: true
                        title: "Вигляд"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        FieldLabel { text: "Тема" }
                        ConfigCombo { configKey: "theme"; hint: "Колірна схема інтерфейсу."; model: backend.themeNames; currentIndex: Math.max(0, backend.themeNames.indexOf(backend.getConfigString("theme"))) }
                        FieldLabel { text: "Шрифт" }
                        StyledCombo { hint: "Базовий шрифт інтерфейсу."; model: backend.fontNames; currentIndex: Math.max(0, backend.fontNames.indexOf(backend.fontFamily)); onActivated: backend.setFontFamily(currentText) }
                        FieldLabel { text: "Масштаб інтерфейсу: " + Number(backend.uiScale).toFixed(2) }
                        ValueSlider { hint: "Збільшує або зменшує весь інтерфейс."; from: 0.80; to: 1.30; stepSize: 0.01; value: backend.uiScale; onMoved: { root.pendingUiScale = value; uiScaleDebounce.restart(); } onPressedChanged: { root.previewAppearanceActive = pressed; if (pressed) backend.beginAppearancePreview(); else { backend.setUiScale(Math.round(value * 100) / 100); backend.endAppearancePreview(); } } }
                        FieldLabel { text: "Базовий розмір шрифту: " + String(backend.baseFontSize) }
                        ValueSlider { hint: "Змінює розмір основного тексту."; from: 12; to: 20; stepSize: 1; value: backend.baseFontSize; onMoved: { root.pendingBaseFontSize = value; fontDebounce.restart(); } onPressedChanged: { root.previewAppearanceActive = pressed; if (pressed) backend.beginAppearancePreview(); else { backend.setBaseFontSize(Math.round(value)); backend.endAppearancePreview(); } } }
                        FieldLabel { text: "Ширина лівої панелі: " + String(backend.leftPanelWidth) }
                        ValueSlider { hint: "Робить ліву колонку вужчою або ширшою."; from: 340; to: 620; stepSize: 1; value: backend.leftPanelWidth; onMoved: { root.pendingLeftPanelWidth = value; widthDebounce.restart(); } onPressedChanged: { root.previewAppearanceActive = pressed; if (pressed) backend.beginAppearancePreview(); else { backend.setLeftPanelWidth(Math.round(value)); backend.endAppearancePreview(); } } }
                        DividerLine { }
                        SectionHeader { text: "Блоки головної сторінки" }
                        ConfigToggle { text: "Показувати блок статистики"; hint: "Лічильники цілей, скрінів, помилок і рестартів на головній."; configKey: "show_stats_block"; checked: backend.getConfigBool("show_stats_block") }
                        ConfigToggle { text: "Показувати блок керування"; hint: "Кнопки запуску, рестарту і зупинки на головній."; configKey: "show_quick_actions_block"; checked: backend.getConfigBool("show_quick_actions_block") }
                        ConfigToggle { text: "Показувати блок останньої цілі"; hint: "Останні оброблені кори і населений пункт."; configKey: "show_last_target_block"; checked: backend.getConfigBool("show_last_target_block") }
                        ConfigToggle { text: "Показувати блок прийому корів"; hint: "Стан режимів прийому і швидкий перемикач."; configKey: "show_receiver_block"; checked: backend.getConfigBool("show_receiver_block") }
                        ConfigToggle { text: "Показувати блок системних перевірок"; hint: "Розгорнуті перевірки файлів і модулів на головній."; configKey: "show_system_check_block"; checked: backend.getConfigBool("show_system_check_block") }
                        DividerLine { }
                        ConfigToggle { text: "Запам'ятовувати вкладку"; hint: "Після перезапуску відкрити ту ж вкладку, на якій ти був."; configKey: "tab_memory_enabled"; checked: backend.getConfigBool("tab_memory_enabled") }
                        ConfigToggle { text: "Запам'ятовувати розмір і позицію"; hint: "Зберігати розмір і позицію вікна між запусками."; configKey: "remember_window"; checked: backend.getConfigBool("remember_window") }
                    }

                    CardPanel {
                        visible: root.isCurrent("Оновлення")
                        Layout.fillWidth: true
                        title: "Оновлення"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        FieldLabel { text: "Поточна версія" }
                        InputField { text: backend.versionText; readOnly: true; hint: "Версія поточної збірки." }
                        FieldLabel { text: "Канал оновлень" }
                        ConfigCombo { configKey: "update_channel"; hint: "Який канал перевіряти: stable або beta."; model: backend.updateChannels; currentIndex: Math.max(0, backend.updateChannels.indexOf(backend.getConfigString("update_channel"))) }
                        ConfigToggle { text: "Автоперевірка оновлень"; hint: "Автоматично перевіряти наявність оновлень через заданий інтервал."; configKey: "auto_check_updates"; checked: backend.getConfigBool("auto_check_updates") }
                        FieldLabel { text: "Інтервал перевірки (хв)" }
                        ConfigField { configKey: "update_check_interval_minutes"; hint: "Раз на скільки хвилин перевіряти маніфест оновлень."; saveAsInt: true; text: backend.getConfigString("update_check_interval_minutes") }
                        FieldLabel { text: "Остання перевірка" }
                        InputField { text: backend.getConfigString("last_update_check") || "ще не перевірялось"; readOnly: true; hint: "Останній результат перевірки оновлень." }
                        FieldLabel { text: "Доступна версія" }
                        InputField { text: backend.getConfigString("update_available_version") || "не знайдено"; readOnly: true; hint: "Версія, знайдена в маніфесті, якщо вона новіша за поточну." }
                        FieldLabel { text: "Нотатки оновлення" }
                        InputArea { Layout.preferredHeight: root.px(120); text: backend.getConfigString("update_notes") || "порожньо"; readOnly: true; hint: "Короткі нотатки до знайденого оновлення." }
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: root.px(8)
                            ActionButton { enabled: backend.updateAllowed && !backend.updateBusy; Layout.preferredWidth: root.px(170); label: backend.updateBusy ? "Перевіряю..." : "Перевірити зараз"; hint: backend.updateAllowed ? "Зараз же смикнути маніфест оновлень." : "Оновлення доступні після QR-прив'язки і завершення першого запуску."; fillColor: root.themeObj.accent2; hoverColor: Qt.lighter(root.themeObj.accent2, 1.05); fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: backend.checkForUpdates(true) }
                            ActionButton { enabled: backend.updateAllowed; Layout.preferredWidth: root.px(138); label: "Відкрити завантаження"; hint: backend.updateAllowed ? "Відкрити URL релізу, якщо він прийшов з маніфесту." : "Посилання оновлення відкриється після першого налаштування."; fillColor: root.panelSoftFill(root.themeObj.panelSoft); hoverColor: root.themeObj.hoverFill; textColor: root.themeObj.text; fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: backend.openUpdateDownloadUrl() }
                            ActionButton { enabled: backend.updateAllowed; Layout.preferredWidth: root.px(170); label: "Запустити updater"; hint: backend.updateAllowed ? "Запустити окремий updater.exe, якщо він є в збірці." : "Updater заблоковано до QR-прив'язки і завершення першого запуску."; fillColor: root.panelSoftFill(root.themeObj.panelSoft); hoverColor: root.themeObj.hoverFill; textColor: root.themeObj.text; fontSize: root.baseFontSize - 2; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: backend.runUpdater() }
                        }
                    }

                    Item { Layout.preferredHeight: root.px(20) }
                }
            }
        }
    }
}
