from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_BUILD_ROOT = Path(r"C:\NOVA PITUSHNYA rZBIRKA")
BUILD_ROOT = ROOT if (ROOT / "release").exists() else DEFAULT_BUILD_ROOT
ISS_ROOT = BUILD_ROOT if (BUILD_ROOT / "build_installer.iss").exists() else ROOT
RELEASE_DIR = BUILD_ROOT / "release"
INSTALLER_DIR = BUILD_ROOT / "installer"


def info(msg: str) -> None:
    print(msg, flush=True)


def fail(msg: str, code: int = 1) -> None:
    print(f"\n[ПОМИЛКА] {msg}", flush=True)
    raise SystemExit(code)


def find_iscc() -> str:
    candidates = [
        shutil.which("ISCC.exe"),
        r"C:\Program Files\Inno Setup 7\ISCC.exe",
        r"C:\Program Files (x86)\Inno Setup 7\ISCC.exe",
        r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe",
        r"C:\Program Files\Inno Setup 6\ISCC.exe",
    ]

    for path in candidates:
        if path and Path(path).exists():
            return str(path)

    fail("Не знайдено ISCC.exe. Встанови Inno Setup 6 або 7.")


def detect_app_version() -> str:
    candidates = [
        RELEASE_DIR / "app" / "config.json",
        ROOT / "config.json",
    ]

    for path in candidates:
        if not path.exists():
            continue

        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            return str(data.get("app_version") or "1.1.8")
        except Exception:
            continue

    return "1.1.8"


def main() -> None:
    iss_file = ISS_ROOT / "build_installer.iss"

    if not iss_file.exists():
        fail(f"Не знайдено файл інсталятора: {iss_file}")

    if not RELEASE_DIR.exists():
        fail(f"Не знайдено release-папку: {RELEASE_DIR}\nСпочатку запусти build_release.py")

    app_exe = RELEASE_DIR / "app" / "PITUSHNYA MCC.exe"
    updater_exe = RELEASE_DIR / "updater" / "pitushnya_updater.exe"

    if not app_exe.exists():
        fail(f"Не знайдено основний exe у релізі: {app_exe}")

    if not updater_exe.exists():
        fail(f"Не знайдено updater у релізі: {updater_exe}")

    INSTALLER_DIR.mkdir(parents=True, exist_ok=True)

    iscc = find_iscc()
    version = detect_app_version()

    cmd = [
        iscc,
        "/Qp",
        f"/DSourceDir={RELEASE_DIR}",
        f"/DOutputDir={INSTALLER_DIR}",
        "/DOutputBase=PITUSHNYA_MCC_Setup",
        f"/DAppVersion={version}",
        str(iss_file),
    ]

    info("[CMD] " + " ".join(f'"{x}"' if " " in x else x for x in cmd))

    result = subprocess.run(cmd, cwd=str(ISS_ROOT))

    if result.returncode != 0:
        fail(f"ISCC завершився з кодом {result.returncode}", result.returncode)

    info("\nГотово.")
    info(f"Інсталятор лежить тут: {INSTALLER_DIR}")


if __name__ == "__main__":
    main()