pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "components"

Item {
    id: root
    property var themeObj
    property real uiScale: 1.0
    property int baseFontSize: 14
    property string fontFamilyName: "Segoe UI"
    property string currentInfoTab: "overview"
    property var infoTabs: [
        { "key": "overview", "title": "Опис", "hint": "Що це за додаток, для чого він потрібен і де саме економить час." },
        { "key": "workflow", "title": "Як це працює", "hint": "Повна покрокова логіка роботи системи при нормальному циклі." },
        { "key": "settings", "title": "Налаштування", "hint": "Що означає кожен перемикач і як він впливає на поведінку програми." },
        { "key": "feedback", "title": "Зворотний зв'язок", "hint": "Куди писати і як сформулювати нормальний репорт про збій." }
    ]

    function px(v) { return Math.max(1, Math.round(v * uiScale)); }
    function fs(mult) { return Math.max(10, Math.round(baseFontSize * mult * uiScale)); }
    function isHelloKitty() { return themeObj && themeObj.name === "Hello Kitty"; }
    function panelFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.90, 0.96, 0.54) : fallback; }
    function panelSoftFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.78, 0.88, 0.44) : fallback; }
    function inputFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.94, 0.98, 0.60) : fallback; }
    function tabText(key) {
        if (key === "workflow")
            return backend.infoWorkflowText
        if (key === "settings")
            return backend.infoSettingsText
        if (key === "feedback")
            return backend.infoFeedbackText
        return backend.infoOverviewText
    }
    Popup {
        id: copyToast
        property string message: "Скопійовано"
        width: Math.min(root.width - root.px(48), root.px(360))
        height: root.px(74)
        x: Math.round((root.width - width) / 2)
        y: root.px(18)
        modal: false
        focus: false
        closePolicy: Popup.NoAutoClose

        background: Rectangle {
            radius: root.px(12)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.accent2
            border.width: 1
        }

        contentItem: Text {
            anchors.fill: parent
            anchors.margins: root.px(10)
            text: copyToast.message
            color: root.themeObj.text
            font.family: root.fontFamilyName
            font.pixelSize: root.fs(0.88)
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            wrapMode: Text.WordWrap
        }

        Timer {
            id: copyToastTimer
            interval: 1500
            repeat: false
            onTriggered: copyToast.close()
        }

        function showMessage(text) {
            copyToast.message = text
            copyToast.open()
            copyToastTimer.restart()
        }
    }
    component InfoTextBlock: Text {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: root.themeObj.textMuted
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(0.82)
        font.bold: true
    }

    component ReadOnlyValue: Rectangle {
        property string valueText: ""
        property string copyMessage: "Скопійовано"
        property bool copyOnClick: false

        Layout.fillWidth: true
        implicitHeight: root.px(46)
        radius: root.px(8)
        color: root.inputFill(root.themeObj.input)
        border.color: copyOnClick && mouse.containsMouse ? root.themeObj.accent2 : root.themeObj.inputBorder
        border.width: 1

        Text {
            anchors.fill: parent
            anchors.margins: root.px(10)
            text: parent.valueText
            color: root.themeObj.text
            font.family: root.fontFamilyName
            font.pixelSize: root.fs(0.82)
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }

        MouseArea {
            id: mouse
            anchors.fill: parent
            hoverEnabled: parent.copyOnClick
            enabled: parent.copyOnClick
            cursorShape: parent.copyOnClick ? Qt.PointingHandCursor : Qt.ArrowCursor
            onClicked: {
                backend.copyText(parent.valueText)
                backend.logUiAction("copy_feedback_contact", parent.valueText)
                copyToast.showMessage(parent.copyMessage)
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        radius: root.px(10)
        color: root.panelFill(root.themeObj.panel)
        border.color: root.themeObj.cardBorder
        border.width: 1
        clip: true

        Flickable {
            anchors.fill: parent
            anchors.margins: root.px(10)
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            contentWidth: width
            contentHeight: contentColumn.implicitHeight

            ColumnLayout {
                id: contentColumn
                width: parent.width
                spacing: root.px(10)

                Text {
                    text: "Інфо"
                    color: root.themeObj.text
                    font.family: root.fontFamilyName
                    font.pixelSize: root.fs(1.18)
                    font.bold: true
                }

                CardPanel {
                    Layout.fillWidth: true
                    title: "Довідка"
                    themeObj: root.themeObj
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName

                    Flow {
                        Layout.fillWidth: true
                        width: parent.width
                        spacing: root.px(8)

                        Repeater {
                            model: root.infoTabs
                            delegate: ActionButton {
                                required property var modelData
                                width: root.px(210)
                                label: modelData.title
                                hint: modelData.hint
                                themeObj: root.themeObj
                                fillColor: root.currentInfoTab === modelData.key ? root.themeObj.accent2 : root.panelSoftFill(root.themeObj.panelSoft)
                                hoverColor: root.currentInfoTab === modelData.key ? Qt.lighter(root.themeObj.accent2, 1.05) : root.themeObj.hoverFill
                                textColor: root.currentInfoTab === modelData.key ? "#ffffff" : root.themeObj.text
                                hoverTextColor: root.currentInfoTab === modelData.key ? "#ffffff" : root.themeObj.hoverText
                                fontSize: root.baseFontSize - 2
                                uiScale: root.uiScale
                                fontFamilyName: root.fontFamilyName
                                onClicked: root.currentInfoTab = modelData.key
                            }
                        }
                    }

                    InfoTextBlock {
                        visible: root.currentInfoTab !== "feedback"
                        text: root.tabText(root.currentInfoTab)
                    }

                    ColumnLayout {
                        visible: root.currentInfoTab === "feedback"
                        Layout.fillWidth: true
                        spacing: root.px(8)

                        InfoTextBlock { text: root.tabText("feedback") }

                        Flow {
                            Layout.fillWidth: true
                            spacing: root.px(8)

                            ActionButton {
                                width: root.px(250)
                                label: "Написати розробнику в Signal"
                                hint: "Відкрити пряме посилання на чат у Signal."
                                themeObj: root.themeObj
                                fillColor: root.themeObj.accent2
                                hoverColor: Qt.lighter(root.themeObj.accent2, 1.05)
                                fontSize: root.baseFontSize - 2
                                uiScale: root.uiScale
                                fontFamilyName: root.fontFamilyName
                                onClicked: backend.openUrl("https://signal.me/#eu/gKLxpKCRB7DV-kqIHYXZSzQ1QH6uq4JtFml50fBuP5fl9NCQKCdEjb0j2_OkjoBM")
                            }
                            ActionButton {
                                width: root.px(170)
                                label: "Telegram"
                                hint: "Відкрити Telegram за номером."
                                themeObj: root.themeObj
                                fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                                hoverColor: root.themeObj.hoverFill
                                textColor: root.themeObj.text
                                fontSize: root.baseFontSize - 2
                                uiScale: root.uiScale
                                fontFamilyName: root.fontFamilyName
                                onClicked: backend.openUrl("tg://resolve?phone=380509189797")
                            }
                            ActionButton {
                                width: root.px(170)
                                label: "WhatsApp"
                                hint: "Відкрити чат у WhatsApp."
                                themeObj: root.themeObj
                                fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                                hoverColor: root.themeObj.hoverFill
                                textColor: root.themeObj.text
                                fontSize: root.baseFontSize - 2
                                uiScale: root.uiScale
                                fontFamilyName: root.fontFamilyName
                                onClicked: backend.openUrl("https://wa.me/380509189797")
                            }
                            ActionButton {
                                width: root.px(170)
                                label: "Email"
                                hint: "Написати на пошту розробника."
                                themeObj: root.themeObj
                                fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                                hoverColor: root.themeObj.hoverFill
                                textColor: root.themeObj.text
                                fontSize: root.baseFontSize - 2
                                uiScale: root.uiScale
                                fontFamilyName: root.fontFamilyName
                                onClicked: backend.openUrl("mailto:s.v.torovus@gmail.com")
                            }
                        }

                        ReadOnlyValue {
                            valueText: "+380 50 918 97 97"
                            copyOnClick: true
                            copyMessage: "Номер телефону скопійовано"
                        }

                        ReadOnlyValue {
                            valueText: "s.v.torovus@gmail.com"
                            copyOnClick: true
                            copyMessage: "Пошту скопійовано"
                        }
                    }
                }

                Item { Layout.preferredHeight: root.px(20) }
            }
        }
    }
}
