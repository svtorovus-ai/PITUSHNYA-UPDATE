@echo off
setlocal

set "APPDIR=%~dp0"
set "JAVA_HOME=%APPDIR%java"
set "PATH=%JAVA_HOME%\bin;%PATH%"

set "PITUSHNYA_USERDATA=%LOCALAPPDATA%\PITUSHNYA MCC"
set "SIGNAL_CLI_CONFIG=%PITUSHNYA_USERDATA%\signal-cli"

if not exist "%PITUSHNYA_USERDATA%" mkdir "%PITUSHNYA_USERDATA%"
if not exist "%SIGNAL_CLI_CONFIG%" mkdir "%SIGNAL_CLI_CONFIG%"

call "%APPDIR%signal-cli\bin\signal-cli.bat" --config "%SIGNAL_CLI_CONFIG%" %*