﻿from __future__ import annotations

import json
import sys
from pathlib import Path

from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

REQUEST = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("data/target_prompt_request.json")
RESULT = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("data/target_prompt_result.json")
WINDOW_STATE = REQUEST.parent / "target_prompt_window.json"

DEFAULT_THEME = {
    "window": "#020913",
    "panel": "#06111b",
    "panelAlt": "#0a1825",
    "panelSoft": "#10253a",
    "cardBorder": "#1f4f72",
    "text": "#f1f7ff",
    "muted": "#b6c6d8",
    "accent": "#3f9cff",
    "accent2": "#53ea74",
    "warning": "#d39a1d",
    "danger": "#ff8a63",
    "input": "#020913",
    "inputBorder": "#2d5c82",
    "hover": "#1c3d5a",
    "selected": "#1b4f7a",
}

DIRECTIONS = [
    ("↖\nпн-зх", 0, 0, "пн_зх"),
    ("↑\nпн", 0, 1, "пн"),
    ("↗\nпн-сх", 0, 2, "пн_сх"),
    ("←\nзх", 1, 0, "зх"),
    ("●\nбез руху", 1, 1, ""),
    ("→\nсх", 1, 2, "сх"),
    ("↙\nпд-зх", 2, 0, "пд_зх"),
    ("↓\nпд", 2, 1, "пд"),
    ("↘\nпд-сх", 2, 2, "пд_сх"),
]


def load_payload() -> dict:
    try:
        data = json.loads(REQUEST.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {"context": {}, "items": [], "callsign": "ЕКІПАЖ", "mode": "все в одному вікні"}


def load_window_state() -> dict:
    try:
        data = json.loads(WINDOW_STATE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_window_state(data: dict) -> None:
    try:
        WINDOW_STATE.parent.mkdir(parents=True, exist_ok=True)
        WINDOW_STATE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def clean_text(value: object, fallback: str = "") -> str:
    text = str(value if value is not None else "").strip()
    return text if text else fallback


class TargetPromptWindow(QMainWindow):
    def __init__(self, payload: dict) -> None:
        super().__init__()

        self.payload = payload or {}
        self.context = self.payload.get("context", {}) or {}
        self.types = [str(x).strip() for x in (self.payload.get("items", []) or []) if str(x).strip()]
        self.mode = clean_text(self.payload.get("mode"), "все в одному вікні")
        self.callsign = clean_text(self.payload.get("callsign") or self.context.get("callsign"), "ЕКІПАЖ")

        self.theme = dict(DEFAULT_THEME)
        if bool(self.payload.get("follow_theme", True)) and isinstance(self.payload.get("theme"), dict):
            self.theme.update({k: str(v) for k, v in self.payload.get("theme", {}).items() if v})

        self.ui_scale = max(0.70, min(1.35, float(self.payload.get("ui_scale", 0.80) or 0.80)))
        self.font_size = max(11, min(24, int(float(self.payload.get("font_size", 15) or 15))))
        self.theme_name = clean_text(self.payload.get("theme_name"))
        raw_wallpaper = clean_text(self.payload.get("wallpaper"))
        self.wallpaper = raw_wallpaper if self.theme_name == "Hello Kitty" and raw_wallpaper and Path(raw_wallpaper).exists() else ""

        self.qty_rows: dict[str, QSpinBox] = {}
        self.direction_buttons: dict[str, QPushButton] = {}
        self.selected_direction = ""
        self._closing_with_result = False
        self._list_updating = False
        self._finish_locked = False

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._save_geometry)

        self.setWindowTitle("Майстер цілі")
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        window_state = load_window_state()
        mode_key = "compact" if self.mode == "все в одному вікні" else "sequential"
        state = dict(window_state.get("modes", {}).get(mode_key, {}))
        compact = self.mode == "все в одному вікні"

        min_w, min_h = (780, 520) if compact else (460, 390)
        default_w, default_h = (980, 590) if compact else (540, 440)

        saved_w = int(state.get("w", default_w) or default_w)
        saved_h = int(state.get("h", default_h) or default_h)

        if not compact:
            saved_w = min(saved_w, self.s(620))
            saved_h = min(saved_h, self.s(540))

        self.setMinimumSize(self.s(min_w), self.s(min_h))
        self.setGeometry(
            int(state.get("x", 220) or 220),
            int(state.get("y", 120) or 120),
            max(self.s(min_w), saved_w),
            max(self.s(min_h), saved_h),
        )
        self.setStyleSheet(self._stylesheet())

        central = QWidget(self)
        central.setObjectName("RootWidget")
        self.setCentralWidget(central)

        root = QVBoxLayout(central)
        self._root_layout = root
        root.setContentsMargins(self.s(14), self.s(12), self.s(14), self.s(12))
        root.setSpacing(self.s(9))

        self.header_title = QLabel("Майстер цілі")
        self.header_title.setObjectName("HeaderTitle")
        root.addWidget(self.header_title)

        ctx_text = (
            f"Час: {clean_text(self.context.get('time'), '—')}   Екіпаж: {self.callsign}\n"
            f"Координати: {clean_text(self.context.get('mgrs'), '—')}\n"
            f"Н.п.: {clean_text(self.context.get('place'), '—')}"
        )
        self.header_info = QLabel(ctx_text)
        self.header_info.setObjectName("HeaderInfo")
        self.header_info.setWordWrap(True)
        root.addWidget(self.header_info)

        if compact:
            self.main_widget = self._build_compact_page()
            root.addWidget(self.main_widget, 1)
        else:
            self.stack = QStackedWidget()
            root.addWidget(self.stack, 1)

            self.step_types = self._build_types_page()
            self.step_qty = self._build_qty_page()
            self.step_dir = self._build_direction_page()

            self.stack.addWidget(self.step_types)
            self.stack.addWidget(self.step_qty)
            self.stack.addWidget(self.step_dir)
            self.show_step(0)

        self._setup_shortcuts()
        QTimer.singleShot(80, self._raise_front)
        QTimer.singleShot(180, self._raise_front)

    def s(self, value: int | float) -> int:
        return max(1, int(round(float(value) * self.ui_scale)))

    def _setup_shortcuts(self) -> None:
        esc = QShortcut(QKeySequence(Qt.Key_Escape), self)
        esc.activated.connect(self.close)

        enter = QShortcut(QKeySequence(Qt.Key_Return), self)
        enter.activated.connect(lambda: self.finish(self.selected_direction))

        enter2 = QShortcut(QKeySequence(Qt.Key_Enter), self)
        enter2.activated.connect(lambda: self.finish(self.selected_direction))

    def _stylesheet(self) -> str:
        t = self.theme
        base = self.font_size
        small = max(11, base - 1)
        header = base + 7
        section = base + 2

        if self.wallpaper:
            wallpaper = Path(self.wallpaper).resolve().as_posix()
            root_background = f"background-color: rgba(255, 232, 244, 210); background-image: url('{wallpaper}'); background-repeat: repeat;"
            widget_background = "background: transparent;"
            card_background = "rgba(255, 210, 232, 205)"
            input_background = "rgba(255, 238, 248, 188)"
            item_background = "rgba(255, 205, 229, 176)"
            scrollbar_background = "rgba(255, 236, 246, 150)"
            scrollbar_handle = "rgba(244, 91, 166, 210)"
            scrollbar_handle_hover = "rgba(255, 71, 156, 235)"
        else:
            root_background = f"background: {t['window']};"
            widget_background = f"background: {t['window']};"
            card_background = t["panelAlt"]
            input_background = t["input"]
            item_background = t["panelSoft"]
            scrollbar_background = t["input"]
            scrollbar_handle = t["cardBorder"]
            scrollbar_handle_hover = t["accent"]

        return f"""
        QMainWindow {{
            background: {t['window']};
            color: {t['text']};
            font-family: 'Segoe UI';
            font-size: {base}px;
        }}

        QWidget {{
            {widget_background}
            color: {t['text']};
            font-family: 'Segoe UI';
            font-size: {base}px;
        }}

        QWidget#RootWidget {{
            {root_background}
        }}

        QLabel {{
            background: transparent;
        }}

        #HeaderTitle {{
            font-size: {header}px;
            font-weight: 800;
            color: {t['text']};
        }}

        #HeaderInfo {{
            font-size: {small}px;
            font-weight: 600;
            color: {t['muted']};
            line-height: 1.25;
        }}

        #Card {{
            background: {card_background};
            border: 1px solid {t['cardBorder']};
            border-radius: 10px;
        }}

        QLabel[section='true'] {{
            font-size: {section}px;
            font-weight: 800;
            color: {t['text']};
        }}

        QPushButton {{
            background: {t['panelSoft']};
            border: 1px solid {t['cardBorder']};
            border-radius: 9px;
            color: {t['text']};
            padding: 7px 12px;
            font-size: {base}px;
            font-weight: 750;
            min-height: {self.s(30)}px;
        }}

        QPushButton:hover {{
            background: {t['hover']};
            border-color: {t['accent']};
        }}

        QPushButton:pressed {{
            background: {t['selected']};
        }}

        QPushButton:disabled {{
            background: {t['input']};
            color: {t['muted']};
            border-color: {t['inputBorder']};
        }}

        QPushButton[role='primary'] {{
            background: {t['accent']};
            border-color: {t['accent']};
            color: #ffffff;
        }}

        QPushButton[role='ok'] {{
            background: {t['accent2']};
            border-color: {t['accent2']};
            color: #062411;
        }}

        QPushButton[role='warn'] {{
            background: {t['warning']};
            border-color: {t['warning']};
            color: #201200;
        }}

        QPushButton[dirSelected='true'] {{
            background: {t['accent2']};
            border-color: {t['accent2']};
            color: #062411;
        }}

        QPushButton#CounterButton {{
            background: {t['panelSoft']};
            border-color: {t['cardBorder']};
            color: {t['text']};
            padding: 0px;
            font-size: {base + 5}px;
            font-weight: 900;
        }}

        QPushButton#CounterButton:hover {{
            background: {t['accent']};
            border-color: {t['accent']};
            color: #ffffff;
        }}

        QLineEdit, QSpinBox {{
            background: {input_background};
            border: 1px solid {t['inputBorder']};
            border-radius: 9px;
            padding: 5px 8px;
            color: {t['text']};
            font-size: {base}px;
            font-weight: 700;
            min-height: {self.s(25)}px;
            selection-background-color: {t['accent']};
        }}

        QListWidget {{
            background: {input_background};
            border: 1px solid {t['inputBorder']};
            border-radius: 10px;
            padding: 5px;
            outline: none;
        }}

        QListWidget::item {{
            background: {item_background};
            color: {t['text']};
            border: 1px solid {t['cardBorder']};
            border-radius: 8px;
            margin: 3px;
            padding: 8px 10px;
            font-weight: 750;
        }}

        QListWidget::item:hover {{
            background: {t['hover']};
            border-color: {t['accent']};
        }}

        QListWidget::item:selected, QListWidget::item:checked {{
            background: {t['selected']};
            border-color: {t['accent']};
            color: #ffffff;
        }}

        QListWidget::indicator {{
            width: {self.s(18)}px;
            height: {self.s(18)}px;
        }}

        QListWidget::indicator:unchecked {{
            border: 1px solid {t['inputBorder']};
            border-radius: 5px;
            background: {input_background};
        }}

        QListWidget::indicator:checked {{
            border: 1px solid {t['accent2']};
            border-radius: 5px;
            background: {t['accent2']};
        }}

        QSplitter::handle {{
            background: {t['cardBorder']};
            border-radius: 3px;
        }}

        QSplitter::handle:hover {{
            background: {t['accent']};
        }}

        QScrollArea {{
            border: none;
            background: transparent;
        }}

        QScrollBar:vertical {{
            background: {scrollbar_background};
            width: 14px;
            margin: 0px;
            border-radius: 7px;
        }}

        QScrollBar::handle:vertical {{
            background: {scrollbar_handle};
            min-height: 42px;
            border-radius: 7px;
        }}

        QScrollBar::handle:vertical:hover {{
            background: {scrollbar_handle_hover};
        }}

        QScrollBar::add-line:vertical,
        QScrollBar::sub-line:vertical {{
            height: 0px;
            width: 0px;
        }}

        QScrollBar::add-page:vertical,
        QScrollBar::sub-page:vertical {{
            background: transparent;
        }}

        QScrollBar:horizontal {{
            background: {scrollbar_background};
            height: 12px;
            margin: 0px;
            border-radius: 6px;
        }}

        QScrollBar::handle:horizontal {{
            background: {scrollbar_handle};
            min-width: 42px;
            border-radius: 6px;
        }}

        QScrollBar::handle:horizontal:hover {{
            background: {scrollbar_handle_hover};
        }}

        QScrollBar::add-line:horizontal,
        QScrollBar::sub-line:horizontal {{
            height: 0px;
            width: 0px;
        }}

        QScrollBar::add-page:horizontal,
        QScrollBar::sub-page:horizontal {{
            background: transparent;
        }}
        """

    def _panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("Card")
        return panel

    def _footer(self, left_buttons: list[QPushButton], right_buttons: list[QPushButton]) -> QWidget:
        box = QWidget()
        row = QHBoxLayout(box)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(self.s(8))
        for btn in left_buttons:
            row.addWidget(btn)
        row.addStretch(1)
        for btn in right_buttons:
            row.addWidget(btn)
        return box

    def _make_type_item(self, name: str, checked: bool = False) -> QListWidgetItem:
        item = QListWidgetItem(name)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsDragEnabled | Qt.ItemIsDropEnabled)
        item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
        item.setSizeHint(QSize(0, self.s(44)))
        return item

    def _build_types_list(self) -> QListWidget:
        self.type_list = QListWidget()
        self.type_list.setDragDropMode(QAbstractItemView.InternalMove)
        self.type_list.setDefaultDropAction(Qt.MoveAction)
        self.type_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.type_list.setSpacing(self.s(2))
        self.type_list.setUniformItemSizes(False)
        self.type_list.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.type_list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        for name in self.types:
            self.type_list.addItem(self._make_type_item(name))

        self.type_list.itemChanged.connect(self._sync_types_state)
        self.type_list.model().rowsMoved.connect(lambda *args: QTimer.singleShot(0, self._sync_types_order))
        return self.type_list

    def _build_add_type_row(self) -> QWidget:
        host = QWidget()
        row = QHBoxLayout(host)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(self.s(8))

        self.new_type_edit = QLineEdit()
        self.new_type_edit.setPlaceholderText("Новий тип цілі")
        self.new_type_edit.returnPressed.connect(self._add_new_type)

        add_btn = QPushButton("Додати")
        add_btn.setProperty("role", "primary")
        add_btn.clicked.connect(self._add_new_type)

        row.addWidget(self.new_type_edit, 1)
        row.addWidget(add_btn)
        return host

    def _build_types_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(self.s(8))

        title = QLabel("Тип цілі")
        title.setProperty("section", True)
        layout.addWidget(title)
        layout.addWidget(self._build_types_list(), 1)
        layout.addWidget(self._build_add_type_row())

        self.types_next = QPushButton("Далі")
        self.types_next.setProperty("role", "primary")
        self.types_next.setEnabled(False)
        self.types_next.clicked.connect(lambda: self.show_step(1))

        layout.addWidget(self._footer([], [self.types_next]))
        return page

    def _build_qty_host(self) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        self.qty_container = QWidget()
        self.qty_layout = QVBoxLayout(self.qty_container)
        self.qty_layout.setContentsMargins(0, 0, 0, 0)
        self.qty_layout.setSpacing(self.s(7))

        scroll.setWidget(self.qty_container)
        return scroll

    def _build_qty_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(self.s(8))

        title = QLabel("Кількість")
        title.setProperty("section", True)
        layout.addWidget(title)
        layout.addWidget(self._build_qty_host(), 1)

        self.qty_back = QPushButton("Назад")
        self.qty_back.clicked.connect(lambda: self.show_step(0))

        self.qty_insert = QPushButton("Вставити без напрямку")
        self.qty_insert.setProperty("role", "warn")
        self.qty_insert.clicked.connect(lambda: self.finish(""))

        self.qty_next = QPushButton("Далі")
        self.qty_next.setProperty("role", "primary")
        self.qty_next.clicked.connect(lambda: self.show_step(2))

        layout.addWidget(self._footer([self.qty_back], [self.qty_insert, self.qty_next]))
        return page

    def _build_direction_grid(self) -> QWidget:
        grid_host = QWidget()
        grid = QGridLayout(grid_host)
        grid.setContentsMargins(self.s(10), self.s(10), self.s(10), self.s(10))
        grid.setHorizontalSpacing(self.s(9))
        grid.setVerticalSpacing(self.s(9))

        self.direction_buttons = {}
        for label, r, c, code in DIRECTIONS:
            btn = QPushButton(label)
            btn.setCheckable(True)
            btn.setMinimumHeight(self.s(52))
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            btn.setProperty("dirSelected", False)
            btn.clicked.connect(lambda checked=False, n=code: self.select_direction(n))
            self.direction_buttons[code] = btn
            grid.addWidget(btn, r, c)

        for col in range(3):
            grid.setColumnStretch(col, 1)
        for row in range(3):
            grid.setRowStretch(row, 1)

        return grid_host

    def _build_direction_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(self.s(8))

        title = QLabel("Напрямок руху")
        title.setProperty("section", True)
        layout.addWidget(title)
        layout.addWidget(self._build_direction_grid(), 1)

        self.dir_back = QPushButton("Назад")
        self.dir_back.clicked.connect(lambda: self.show_step(1))

        self.dir_insert = QPushButton("Вставити")
        self.dir_insert.setProperty("role", "ok")
        self.dir_insert.clicked.connect(lambda: self.finish(self.selected_direction))

        layout.addWidget(self._footer([self.dir_back], [self.dir_insert]))
        return page

    def _build_compact_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(self.s(8))

        host = QScrollArea()
        host.setWidgetResizable(True)
        host.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        host.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        host_box = QWidget()
        row = QVBoxLayout(host_box)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(self.s(8))

        left = self._panel()
        left.setMinimumWidth(self.s(190))
        left.setMaximumWidth(self.s(280))
        left_l = QVBoxLayout(left)
        left_l.setContentsMargins(self.s(10), self.s(10), self.s(10), self.s(10))
        left_l.setSpacing(self.s(7))

        labl = QLabel("Тип цілі")
        labl.setProperty("section", True)
        left_l.addWidget(labl)
        left_l.addWidget(self._build_types_list(), 1)
        left_l.addWidget(self._build_add_type_row())

        center = self._panel()
        center.setMinimumWidth(max(self.s(290), self.font_size * 16))
        center_l = QVBoxLayout(center)
        center_l.setContentsMargins(self.s(10), self.s(10), self.s(10), self.s(10))
        center_l.setSpacing(self.s(7))

        lab = QLabel("Кількість")
        lab.setProperty("section", True)
        center_l.addWidget(lab)
        center_l.addWidget(self._build_qty_host(), 1)

        right = self._panel()
        right.setMinimumWidth(max(self.s(310), self.font_size * 17))
        right_l = QVBoxLayout(right)
        right_l.setContentsMargins(self.s(10), self.s(10), self.s(10), self.s(10))
        right_l.setSpacing(self.s(7))

        lab2 = QLabel("Напрямок руху")
        lab2.setProperty("section", True)
        right_l.addWidget(lab2)
        right_l.addWidget(self._build_direction_grid(), 1)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(self.s(7))
        splitter.addWidget(left)
        splitter.addWidget(center)
        splitter.addWidget(right)
        splitter.setSizes([self.s(235), self.s(330), self.s(370)])

        row.addWidget(splitter)
        host.setWidget(host_box)

        layout.addWidget(host, 1)

        self.compact_insert = QPushButton("Вставити")
        self.compact_insert.setProperty("role", "ok")
        self.compact_insert.clicked.connect(lambda: self.finish(self.selected_direction))

        layout.addWidget(self._footer([], [self.compact_insert]))
        self._rebuild_qty_rows()
        return page

    def _selected_types(self) -> list[str]:
        if not hasattr(self, "type_list"):
            return []

        result = []
        for i in range(self.type_list.count()):
            item = self.type_list.item(i)
            if item.checkState() == Qt.Checked:
                result.append(item.text())
        return result

    def _current_type_order(self) -> list[str]:
        if not hasattr(self, "type_list"):
            return list(self.types)
        return [self.type_list.item(i).text() for i in range(self.type_list.count())]

    def _sync_types_state(self) -> None:
        if self._list_updating:
            return

        enabled = bool(self._selected_types())

        if hasattr(self, "types_next"):
            self.types_next.setEnabled(enabled)

        if hasattr(self, "compact_insert"):
            self.compact_insert.setEnabled(enabled)

        self._rebuild_qty_rows()

    def _sync_types_order(self) -> None:
        if self._list_updating:
            return

        self.types = self._current_type_order()
        self._emit_items_update()

    def _emit_items_update(self) -> None:
        if self._closing_with_result:
            return

        try:
            RESULT.parent.mkdir(parents=True, exist_ok=True)
            RESULT.write_text(json.dumps({"action": "items_update", "items": self.types}, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _add_new_type(self) -> None:
        text = clean_text(self.new_type_edit.text() if hasattr(self, "new_type_edit") else "")
        if not text:
            return

        existing = {x.casefold() for x in self.types}
        if text.casefold() in existing:
            return

        self.types.append(text)

        self._list_updating = True
        self.type_list.addItem(self._make_type_item(text, checked=True))
        self._list_updating = False

        self.new_type_edit.clear()
        self._emit_items_update()
        self._sync_types_state()

    def _rebuild_qty_rows(self) -> None:
        if not hasattr(self, "qty_layout"):
            return

        while self.qty_layout.count():
            item = self.qty_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        old = {k: v.value() for k, v in self.qty_rows.items()}
        self.qty_rows = {}

        for name in self._selected_types():
            row = self._panel()
            lay = QHBoxLayout(row)
            lay.setContentsMargins(self.s(10), self.s(7), self.s(10), self.s(7))
            lay.setSpacing(self.s(7))

            lab = QLabel(name)
            lab.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            lab.setStyleSheet(f"font-size: {self.font_size}px; font-weight: 750; background: transparent;")
            lay.addWidget(lab, 1)

            row.setMinimumHeight(max(self.s(50), self.font_size + self.s(28)))

            btn_size = max(self.s(38), self.font_size + self.s(16))

            minus = QPushButton("-")
            minus.setObjectName("CounterButton")
            minus.setFixedSize(btn_size, btn_size)

            spin = QSpinBox()
            spin.setRange(0, 99)
            spin.setValue(old.get(name, 0))
            spin.setButtonSymbols(QSpinBox.NoButtons)
            spin.setAlignment(Qt.AlignCenter)
            spin.setFixedWidth(max(self.s(76), self.font_size * 4 + self.s(10)))

            plus = QPushButton("+")
            plus.setObjectName("CounterButton")
            plus.setFixedSize(btn_size, btn_size)

            unit = QLabel("од.")
            unit.setStyleSheet(f"font-size: {max(11, self.font_size - 1)}px; font-weight: 700; background: transparent;")

            lay.addWidget(minus)
            lay.addWidget(spin)
            lay.addWidget(plus)
            lay.addWidget(unit)

            minus.clicked.connect(lambda checked=False, s=spin: s.setValue(max(0, s.value() - 1)))
            plus.clicked.connect(lambda checked=False, s=spin: s.setValue(s.value() + 1))

            self.qty_rows[name] = spin
            self.qty_layout.addWidget(row)

        self.qty_layout.addStretch(1)

    def select_direction(self, direction: str) -> None:
        self.selected_direction = direction

        for code, btn in self.direction_buttons.items():
            selected = code == direction
            btn.setChecked(selected)
            btn.setProperty("dirSelected", selected)
            btn.style().unpolish(btn)
            btn.style().polish(btn)
            btn.update()

    def show_step(self, index: int) -> None:
        if index == 1 and not self._selected_types():
            return

        if index == 1:
            self._rebuild_qty_rows()

        self.stack.setCurrentIndex(index)
        self.header_title.setText(["Тип цілі", "Кількість", "Напрямок руху"][index])
        self._raise_front()

    def finish(self, direction: str) -> None:
        if self._finish_locked:
            return

        items = []
        for name in self._selected_types():
            spin = self.qty_rows.get(name)
            qty = int(spin.value() if spin else 0)
            items.append({"type": name, "qty": max(0, qty)})

        if not items:
            return

        self._finish_locked = True
        self._closing_with_result = True

        try:
            if hasattr(self, "compact_insert"):
                self.compact_insert.setEnabled(False)
            if hasattr(self, "dir_insert"):
                self.dir_insert.setEnabled(False)
            if hasattr(self, "qty_insert"):
                self.qty_insert.setEnabled(False)
        except Exception:
            pass

        self.setWindowFlag(Qt.WindowStaysOnTopHint, False)
        self.hide()
        QApplication.processEvents()

        try:
            RESULT.parent.mkdir(parents=True, exist_ok=True)
            RESULT.write_text(
                json.dumps(
                    {
                        "action": "insert",
                        "items": items,
                        "all_items": self.types,
                        "direction": direction,
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        except Exception:
            pass

        self._save_geometry()
        self.close()

    def _raise_front(self) -> None:
        try:
            self.raise_()
            self.activateWindow()
        except Exception:
            pass

    def _schedule_save_geometry(self) -> None:
        self._save_timer.start(260)

    def _save_geometry(self) -> None:
        g = self.geometry()
        state = load_window_state()
        if not isinstance(state, dict):
            state = {}

        modes = dict(state.get("modes", {}))
        mode_key = "compact" if self.mode == "все в одному вікні" else "sequential"
        modes[mode_key] = {
            "x": g.x(),
            "y": g.y(),
            "w": g.width(),
            "h": g.height(),
        }
        state["modes"] = modes
        save_window_state(state)

    def moveEvent(self, event):
        super().moveEvent(event)
        self._schedule_save_geometry()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._schedule_save_geometry()

    def closeEvent(self, event):
        self._save_geometry()

        if not self._closing_with_result:
            try:
                RESULT.parent.mkdir(parents=True, exist_ok=True)
                RESULT.write_text(
                    json.dumps({"action": "cancel", "all_items": self.types}, ensure_ascii=False),
                    encoding="utf-8",
                )
            except Exception:
                pass

        super().closeEvent(event)


def main() -> int:
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(True)
    payload = load_payload()
    window = TargetPromptWindow(payload)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

