from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUILD_ROOT = Path(r"C:\NOVA PITUSHNYA rZBIRKA")
RELEASE_DIR = BUILD_ROOT / "release"
APP_DIR = RELEASE_DIR / "app"
UPDATER_DIR = RELEASE_DIR / "updater"

APP_VERSION_FALLBACK = "1.1.8"

DEFAULT_TIME_TEMPLATE = "Ціль- підар, виявлено: ({time})"
DEFAULT_COORDS_TEMPLATE = "{time} {callsign}, {targets}, за корами ({mgrs}) н.п. ({place}), рух на {direction}"

REQUIRED_FILES = [
    ROOT / "main.py",
    ROOT / "PITUSHNYA MCC.spec",
    ROOT / "pitushnya_updater.py",
    ROOT / "target_prompt.py",
    ROOT / "icons" / "PITUSHNYA.ico",
]

ROOT_FILES_TO_COPY = [
    "config.json",
    "signal-cli-local.bat",
    "README.md",
    "README.txt",
    "force_uninstall_pitushnya.cmd",
    "target_prompt.py",
]

POST_BUILD_FILES = [
    "build_installer.bat",
    "build_installer.cmd",
    "build_installer.py",
    "build_installer.iss",
]

FOLDERS_TO_COPY = [
    "ahk",
    "py",
    "icons",
    "qml",
    "assets",
    "gis",
    "java",
    "python",
    "sharex",
    "signal-cli",
    "sharex_data",
    "data",
]

RUNTIME_EMPTY_FILES = [
    "delta_debug.txt",
    "delta_ready.txt",
    "force_target_wizard.txt",
    "last_screenshot_paste.txt",
    "last_time_text_paste.txt",
    "listener_heartbeat.txt",
    "pitusharnya_events.log",
    "signal_raw_events.jsonl",
    "target_prompt_request.json",
    "target_prompt_result.json",
]

RUNTIME_JSON_DEFAULTS = {
    "delta_place_cache.json": {},
    "delta_ready_meta.json": {},
    "runtime_profile.json": {},
    "ui_stats.json": {
        "targets": 0,
        "screens": 0,
        "errors": 0,
        "restarts": 0,
        "manual_restarts": 0,
        "auto_restarts": 0,
    },
}

RUNTIME_TEXT_DEFAULTS = {
    "delta_state.ini": "[delta]\nstatus=idle\ntime=\ncycle_id=\n",
    "message_template_time_fix.txt": DEFAULT_TIME_TEMPLATE,
    "message_template_coords.txt": DEFAULT_COORDS_TEMPLATE,
}


def info(msg: str) -> None:
    print(msg, flush=True)


def fail(msg: str, code: int = 1) -> None:
    print(f"\n[ПОМИЛКА] {msg}", flush=True)
    raise SystemExit(code)


def load_config() -> dict:
    config_path = ROOT / "config.json"

    try:
        data = json.loads(config_path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def app_version() -> str:
    data = load_config()
    return str(data.get("app_version") or APP_VERSION_FALLBACK)


def write_version_info() -> Path:
    version = app_version()
    nums = [int(x) for x in re.findall(r"\d+", version)[:4]]

    while len(nums) < 4:
        nums.append(0)

    content = f"""VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=({nums[0]}, {nums[1]}, {nums[2]}, {nums[3]}),
    prodvers=({nums[0]}, {nums[1]}, {nums[2]}, {nums[3]}),
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
    ),
  kids=[
    StringFileInfo([
      StringTable(
        '040904B0',
        [
        StringStruct('CompanyName', 'Grey'),
        StringStruct('FileDescription', 'PITUSHNYA MCC'),
        StringStruct('FileVersion', '{version}'),
        StringStruct('InternalName', 'PITUSHNYA MCC'),
        StringStruct('OriginalFilename', 'PITUSHNYA MCC.exe'),
        StringStruct('ProductName', 'PITUSHNYA MCC'),
        StringStruct('ProductVersion', '{version}')
        ])
      ]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
"""

    out = ROOT / "version_info.txt"
    out.write_text(content, encoding="utf-8")
    return out


def remove_if_exists(path: Path) -> None:
    if not path.exists():
        return

    if path.is_dir():
        shutil.rmtree(path, ignore_errors=True)
    else:
        try:
            path.unlink()
        except Exception:
            pass


def copy_file(src: Path, dst_dir: Path) -> None:
    if not src.exists():
        return

    dst_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst_dir / src.name)


def copy_dir(src: Path, dst: Path) -> None:
    if dst.exists():
        shutil.rmtree(dst, ignore_errors=True)

    shutil.copytree(src, dst)


def run(cmd: list[str], cwd: Path | None = None) -> None:
    info("[CMD] " + " ".join(f'"{x}"' if " " in x else x for x in cmd))
    result = subprocess.run(cmd, cwd=str(cwd or ROOT))

    if result.returncode != 0:
        fail(f"Команда завершилась з кодом {result.returncode}: {' '.join(cmd)}", result.returncode)


def ensure_requirements() -> None:
    missing = [str(path) for path in REQUIRED_FILES if not path.exists()]

    if missing:
        fail("Не знайдено обов'язкові файли:\n- " + "\n- ".join(missing))

    try:
        import PyInstaller  # noqa: F401
    except Exception:
        fail(
            "У поточному Python нема PyInstaller.\n"
            f"Запусти:\n\n{sys.executable} -m pip install pyinstaller"
        )

    try:
        import PySide6  # noqa: F401
        import shiboken6  # noqa: F401
    except Exception as exc:
        fail(
            "У поточному Python нема PySide6/shiboken6.\n"
            f"Деталі: {exc}\n\n"
            f"Перевір саме цей Python:\n{sys.executable}\n\n"
            "І постав пакети командою:\n"
            f"{sys.executable} -m pip install PySide6 shiboken6"
        )


def clean_runtime_profile_defaults() -> dict:
    cfg = load_config()

    return {
        "callsign": "ЕКІПАЖ",
        "signal_number": "",
        "signal_http": str(cfg.get("signal_cli_http") or "127.0.0.1:7583"),
        "signal_exe": "",
        "receiver_enabled": bool(cfg.get("receiver_enabled", True)),
        "receiver_accept_groups": bool(cfg.get("receiver_accept_groups", False)),
        "receiver_personal_mode": str(cfg.get("receiver_personal_mode") or "усі особисті"),
        "receiver_group_mode": str(cfg.get("receiver_group_mode") or "тільки вибрані"),
        "receiver_allowed_senders": [],
        "receiver_allowed_groups": [],
        "receiver_capture_mode": str(cfg.get("receiver_capture_mode") or "signal"),
        "receiver_ignore_own_account": bool(cfg.get("receiver_ignore_own_account", True)),
        "receiver_ignore_last_generated_message": bool(cfg.get("receiver_ignore_last_generated_message", True)),
        "coord_output_system": str(cfg.get("coord_output_system") or "MGRS"),
        "message_template_time_fix": str(cfg.get("message_template_time_fix") or DEFAULT_TIME_TEMPLATE),
        "message_template_coords": str(cfg.get("message_template_coords") or DEFAULT_COORDS_TEMPLATE),
        "message_template_time_fix_default": str(cfg.get("message_template_time_fix_default") or DEFAULT_TIME_TEMPLATE),
        "message_template_coords_default": str(cfg.get("message_template_coords_default") or DEFAULT_COORDS_TEMPLATE),
        "hotkeys_description": str(cfg.get("hotkeys_description") or ""),
        "updated_at": "",
    }


def sanitize_runtime_data(data_dir: Path) -> None:
    data_dir.mkdir(parents=True, exist_ok=True)

    for name in RUNTIME_EMPTY_FILES:
        try:
            (data_dir / name).write_text("", encoding="utf-8")
        except Exception:
            pass

    for name, value in RUNTIME_JSON_DEFAULTS.items():
        try:
            clean_value = clean_runtime_profile_defaults() if name == "runtime_profile.json" else value
            (data_dir / name).write_text(json.dumps(clean_value, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    for name, value in RUNTIME_TEXT_DEFAULTS.items():
        try:
            (data_dir / name).write_text(value, encoding="utf-8")
        except Exception:
            pass


def sanitize_release_config(config_path: Path) -> None:
    if not config_path.exists():
        return

    try:
        data = json.loads(config_path.read_text(encoding="utf-8-sig"))
    except Exception:
        return

    data.update({
        "app_version": APP_VERSION_FALLBACK,
        "install_id": "",
        "signal_number": "",
        "signal_linked": False,
        "first_run_done": False,
        "telemetry_signal_name": "",
        "telemetry_funnel_app_first_launch_sent": False,
        "telemetry_funnel_callsign_sent": False,
        "telemetry_funnel_signal_link_sent": False,
        "telemetry_funnel_first_run_completed_sent": False,
        "callsign": "ЕКІПАЖ",
        "screenshots_path": "%USERPROFILE%\\Documents\\ShareX\\Screenshots",
        "signal_exe": "%LOCALAPPDATA%\\Programs\\signal-desktop\\Signal.exe",
        "last_update_check": "ще не перевірялось",
        "update_available_version": "",
        "update_notes": "",
        "message_template_time_fix": str(data.get("message_template_time_fix") or DEFAULT_TIME_TEMPLATE),
        "message_template_coords": str(data.get("message_template_coords") or DEFAULT_COORDS_TEMPLATE),
        "message_template_time_fix_default": str(data.get("message_template_time_fix_default") or DEFAULT_TIME_TEMPLATE),
        "message_template_coords_default": str(data.get("message_template_coords_default") or DEFAULT_COORDS_TEMPLATE),
        "minimize_to_tray_on_launch": bool(data.get("minimize_to_tray_on_launch", False)),
        "show_instruction_on_ready": bool(data.get("show_instruction_on_ready", True)),
        "start_maximized_after_install": bool(data.get("start_maximized_after_install", True)),
    })

    try:
        config_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def sanitize_sharex_payload(sharex_dir: Path) -> None:
    for rel in [
        "Screenshots",
        "Logs",
        "History.db",
        "ShareX\\Screenshots",
        "ShareX\\Logs",
        "ShareX\\History.db",
        "ShareX\\ShareX\\Screenshots",
        "ShareX\\ShareX\\Logs",
        "ShareX\\ShareX\\History.db",
    ]:
        path = sharex_dir / rel

        try:
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
                path.mkdir(parents=True, exist_ok=True)
            elif path.exists():
                path.unlink(missing_ok=True)
        except Exception:
            pass


def build_main() -> None:
    write_version_info()
    run([sys.executable, "-m", "PyInstaller", "--version"])
    run([sys.executable, "-m", "PyInstaller", "--clean", "--noconfirm", str(ROOT / "PITUSHNYA MCC.spec")])


def build_target_prompt() -> None:
    run(
        [
            sys.executable,
            "-m",
            "PyInstaller",
            "--noconfirm",
            "--clean",
            "--onefile",
            "--windowed",
            "--name",
            "target_prompt",
            "--icon",
            str(ROOT / "icons" / "PITUSHNYA.ico"),
            "--version-file",
            str(write_version_info()),
            str(ROOT / "target_prompt.py"),
        ]
    )


def build_updater() -> None:
    run(
        [
            sys.executable,
            "-m",
            "PyInstaller",
            "--noconfirm",
            "--clean",
            "--onefile",
            "--windowed",
            "--name",
            "pitushnya_updater",
            "--icon",
            str(ROOT / "icons" / "PITUSHNYA.ico"),
            "--version-file",
            str(write_version_info()),
            str(ROOT / "pitushnya_updater.py"),
        ]
    )


def copy_release() -> None:
    main_dist = ROOT / "dist" / "PITUSHNYA MCC"
    main_exe = main_dist / "PITUSHNYA MCC.exe"
    updater_exe = ROOT / "dist" / "pitushnya_updater.exe"
    prompt_exe = ROOT / "dist" / "target_prompt.exe"

    if not main_exe.exists():
        fail(f"Не знайдено основний exe після збірки: {main_exe}")

    if not updater_exe.exists():
        fail(f"Не знайдено updater exe після збірки: {updater_exe}")

    if not prompt_exe.exists():
        fail(f"Не знайдено target_prompt exe після збірки: {prompt_exe}")

    APP_DIR.mkdir(parents=True, exist_ok=True)
    UPDATER_DIR.mkdir(parents=True, exist_ok=True)

    try:
        shutil.copy2(main_exe, APP_DIR / "PITUSHNYA MCC.exe")
    except PermissionError:
        fail("Не можу перезаписати PITUSHNYA MCC.exe у release. Закрий запущену програму, updater і вікна Провідника з release-папкою, потім спробуй ще раз.")

    for item in main_dist.iterdir():
        if item.name == "PITUSHNYA MCC.exe":
            continue

        dst = APP_DIR / item.name

        try:
            if item.is_dir():
                copy_dir(item, dst)
            else:
                shutil.copy2(item, dst)
        except PermissionError:
            fail(f"Не можу скопіювати {item.name} у release. Ймовірно файл або папка зараз зайняті іншим процесом.")

    shutil.copy2(updater_exe, UPDATER_DIR / "pitushnya_updater.exe")
    shutil.copy2(updater_exe, BUILD_ROOT / "pitushnya_updater.exe")
    shutil.copy2(prompt_exe, APP_DIR / "target_prompt.exe")

    for name in ROOT_FILES_TO_COPY:
        copy_file(ROOT / name, APP_DIR)

    for name in FOLDERS_TO_COPY:
        src = ROOT / name
        dst = APP_DIR / name

        if src.exists():
            copy_dir(src, dst)

    sanitize_runtime_data(APP_DIR / "data")
    sanitize_runtime_data(APP_DIR / "sharex_data" / "data")
    sanitize_release_config(APP_DIR / "config.json")
    sanitize_sharex_payload(APP_DIR / "sharex_data")


def sync_post_build_files() -> None:
    BUILD_ROOT.mkdir(parents=True, exist_ok=True)

    for name in POST_BUILD_FILES:
        copy_file(ROOT / name, BUILD_ROOT)


def main() -> None:
    os.chdir(ROOT)
    ensure_requirements()

    info("=" * 44)
    info("PITUSHNYA MCC - ЗБІРКА RELEASE")
    info("=" * 44)
    info(f"Корінь проєкту: {ROOT}")
    info(f"Python: {sys.executable}")
    info(f"Версія: {app_version()}")
    info(f"Куди зберігаю: {RELEASE_DIR}")

    remove_if_exists(ROOT / "build")
    remove_if_exists(ROOT / "dist")
    remove_if_exists(RELEASE_DIR)
    remove_if_exists(BUILD_ROOT / "pitushnya_updater.exe")

    BUILD_ROOT.mkdir(parents=True, exist_ok=True)

    info("\n[1/4] Збираю основний exe...")
    build_main()

    info("\n[2/4] Збираю helper-вікно цілі...")
    build_target_prompt()

    info("\n[3/4] Збираю updater exe...")
    build_updater()

    info("\n[4/4] Копіюю release...")
    copy_release()
    sync_post_build_files()

    info("\nГотово.")
    info(f"Release лежить тут: {RELEASE_DIR}")
    info(f"Updater exe поруч із release: {BUILD_ROOT / 'pitushnya_updater.exe'}")
    info("Інсталятор збирай уже з пост-build папки, де лежить release.")


if __name__ == "__main__":
    main()