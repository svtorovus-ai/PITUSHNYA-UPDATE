@echo off
setlocal
cd /d "%~dp0"

set "PYEXE=%~dp0python\python.exe"
if exist "%PYEXE%" goto run

set "PYEXE=C:\Users\User\AppData\Local\Programs\Python\Python314\python.exe"
if exist "%PYEXE%" goto run

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 "%~dp0build_release.py"
    set "EC=%ERRORLEVEL%"
    if not "%EC%"=="0" pause
    exit /b %EC%
)

where python >nul 2>nul
if %errorlevel%==0 (
    python "%~dp0build_release.py"
    set "EC=%ERRORLEVEL%"
    if not "%EC%"=="0" pause
    exit /b %EC%
)

echo [ERROR] Python not found.
pause
exit /b 1

:run
"%PYEXE%" "%~dp0build_release.py"
set "EC=%ERRORLEVEL%"
if not "%EC%"=="0" pause
exit /b %EC%
