import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "components"

Item {
    id: root
    property var themeObj
    property int leftPanelWidth: 380
    property real uiScale: 1.0
    property int baseFontSize: 14
    property string fontFamilyName: "Segoe UI"
    property string selectedLogLevel: "Все разом"
    property bool previewMode: false

    function px(v) { return Math.max(1, Math.round(v * uiScale)); }
    function fs(mult) { return Math.max(10, Math.round(baseFontSize * mult * uiScale)); }
    function isHelloKitty() { return themeObj && themeObj.name === "Hello Kitty"; }
    function panelFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.90, 0.96, 0.54) : fallback; }
    function panelAltFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.84, 0.92, 0.48) : fallback; }
    function panelSoftFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.78, 0.88, 0.44) : fallback; }
    function inputFill(fallback) { return isHelloKitty() ? Qt.rgba(1.0, 0.94, 0.98, 0.60) : fallback; }
    function logFill(fallback) { return isHelloKitty() ? Qt.rgba(0.13, 0.03, 0.09, 0.92) : fallback; }

    component HomeCombo: ComboBox {
        id: comboRoot
        property string hint: ""
        implicitHeight: root.px(40)
        font.family: root.fontFamilyName
        font.pixelSize: root.fs(0.82)
        font.bold: true
        HoverHandler { id: hh }
        HintToolTip {
            visible: hh.hovered && comboRoot.hint.length > 0
            text: comboRoot.hint
            themeObj: root.themeObj
            uiScale: root.uiScale
            fontFamilyName: root.fontFamilyName
        }
        delegate: ItemDelegate {
            width: ListView.view ? ListView.view.width : comboRoot.width
            height: root.px(38)
            contentItem: Text { text: modelData; color: root.themeObj.text; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.82); font.bold: true; elide: Text.ElideRight; verticalAlignment: Text.AlignVCenter }
            background: Rectangle { radius: root.px(6); color: highlighted ? root.themeObj.accent2 : root.panelSoftFill(root.themeObj.panelSoft); border.color: highlighted ? Qt.lighter(root.themeObj.accent2, 1.08) : root.themeObj.inputBorder; border.width: 1 }
        }
        indicator: Canvas {
            x: parent.width - width - root.px(12); y: parent.height / 2 - height / 2; width: root.px(12); height: root.px(8)
            onPaint: { var c=getContext("2d"); c.reset(); c.fillStyle=root.themeObj.accent2; c.beginPath(); c.moveTo(0,0); c.lineTo(width,0); c.lineTo(width/2,height); c.closePath(); c.fill(); }
        }
        contentItem: Text { leftPadding: root.px(12); rightPadding: root.px(30); text: parent.displayText; color: root.themeObj.text; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.82); font.bold: true; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        background: Rectangle { radius: root.px(8); color: root.panelSoftFill(root.themeObj.panelSoft); border.color: root.themeObj.accent2; border.width: 1 }
        popup: Popup {
            parent: Overlay.overlay
            x: comboRoot.mapToItem(Overlay.overlay, 0, 0).x
            y: comboRoot.mapToItem(Overlay.overlay, 0, comboRoot.height + root.px(6)).y
            width: comboRoot.width
            implicitHeight: Math.min(contentItem.implicitHeight + root.px(2), root.px(220))
            padding: 1
            z: 10000
            closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
            onOpened: {
                var p = comboRoot.mapToItem(Overlay.overlay, 0, comboRoot.height + root.px(6))
                x = p.x
                y = p.y
            }
            background: Rectangle {
                radius: root.px(8)
                color: root.inputFill(root.themeObj.input)
                border.color: root.themeObj.accent2
                border.width: 2
            }
            contentItem: ListView {
                clip: true
                implicitHeight: contentHeight
                model: comboRoot.popup.visible ? comboRoot.delegateModel : null
                currentIndex: comboRoot.highlightedIndex
                ScrollBar.vertical: AppScrollBar {
    themeObj: root.themeObj
    uiScale: root.uiScale
}
            }
        }
    }

    Popup {
        id: donatePopup
        width: Math.min(root.width - root.px(32), root.px(580))
        height: Math.min(root.height - root.px(32), root.px(640))
        modal: true
        focus: true
        padding: root.px(14)
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

        background: Rectangle {
            radius: root.px(12)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.cardBorder
            border.width: 1
        }

        contentItem: Flickable {
            clip: true
            contentWidth: width
            contentHeight: donateColumn.implicitHeight
            boundsBehavior: Flickable.StopAtBounds

            ColumnLayout {
                id: donateColumn
                width: donatePopup.availableWidth
                spacing: root.px(10)

                Text {
                    Layout.fillWidth: true
                    text: "Донат розробнику"
                    color: root.themeObj.text
                    font.family: root.fontFamilyName
                    font.pixelSize: root.fs(1.02)
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Text {
                    Layout.fillWidth: true
                    text: "Якщо ця пітушня реально зекономила тобі час, було б не хуйово підкинути розробнику на віскарь, та оплату GPT))\n\nНижче QR для переказу грн, та продубльований номер карти"
                    color: root.themeObj.textMuted
                    wrapMode: Text.WordWrap
                    font.family: root.fontFamilyName
                    font.pixelSize: root.fs(0.8)
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Rectangle {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.preferredWidth: root.px(238)
                    Layout.preferredHeight: root.px(238)
                    radius: root.px(12)
                    color: "#ffffff"
                    border.color: root.themeObj.cardBorder
                    border.width: 1

                    Image {
                        anchors.fill: parent
                        anchors.margins: root.px(10)
                        fillMode: Image.PreserveAspectFit
                        source: backend.donateQrSource
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: root.px(42)
                    radius: root.px(10)
                    color: root.inputFill(root.themeObj.input)
                    border.color: root.themeObj.inputBorder
                    border.width: 1

                    Text {
                        anchors.centerIn: parent
                        text: backend.donateCardNumber
                        color: root.themeObj.text
                        font.family: root.fontFamilyName
                        font.pixelSize: root.fs(0.86)
                        font.bold: true
                    }
                }

                ActionButton {
                    Layout.fillWidth: true
                    label: "Скопіювати номер картки"
                    fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                    hoverColor: root.themeObj.hoverFill
                    textColor: root.themeObj.text
                    hoverTextColor: root.themeObj.hoverText
                    fontSize: root.baseFontSize - 2
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName
                    onClicked: backend.copyText(backend.donateCardNumber)
                }

                ActionButton {
                    Layout.fillWidth: true
                    label: "Закрити"
                    fillColor: root.themeObj.accent2
                    hoverColor: Qt.lighter(root.themeObj.accent2, 1.05)
                    textColor: "#ffffff"
                    hoverTextColor: "#ffffff"
                    fontSize: root.baseFontSize - 2
                    uiScale: root.uiScale
                    fontFamilyName: root.fontFamilyName
                    onClicked: donatePopup.close()
                }
            }

            ScrollBar.vertical: AppScrollBar {
                themeObj: root.themeObj
                uiScale: root.uiScale
            }
        }
    }

    Popup {
        id: roosterPopup
        width: root.px(500)
        height: root.px(190)
        modal: true
        focus: true
        padding: root.px(14)
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
        background: Rectangle {
            radius: root.px(12)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.cardBorder
            border.width: 1
        }
        contentItem: TextArea {
            readOnly: true
            wrapMode: TextEdit.Wrap
            text: String(backend.roosterClickMessage()).replace(/([.!?])\s+/g, "$1\n")
            color: root.themeObj.text
            font.family: root.fontFamilyName
            font.pixelSize: root.fs(0.86)
            font.bold: true
            background: null
        }
    }

    RowLayout {
        anchors.fill: parent
        spacing: root.px(8)

        Rectangle {
            Layout.preferredWidth: root.leftPanelWidth
            Layout.minimumWidth: 340
            Layout.maximumWidth: 640
            Layout.fillHeight: true
            radius: root.px(10)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.cardBorder
            border.width: 1
            clip: true

            Flickable {
                id: leftFlick
                anchors.fill: parent
                anchors.margins: root.px(8)
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                contentWidth: width
                contentHeight: leftColumn.implicitHeight

                ColumnLayout {
                    id: leftColumn
                    width: leftFlick.width
                    spacing: root.px(8)

                    CardPanel {
                        Layout.fillWidth: true
                        title: ""
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: root.px(10)
                            ColumnLayout {
                                Layout.fillWidth: true
                                Text {
                                    text: backend.titleText
                                    color: root.themeObj.text
                                    font.family: root.fontFamilyName
                                    font.pixelSize: root.fs(1.2)
                                    font.bold: true
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                }
                                Text {
                                    text: "Панель керування всією цією поїботою v " + backend.versionText
                                    color: root.themeObj.textMuted
                                    font.family: root.fontFamilyName
                                    font.pixelSize: root.fs(0.8)
                                    font.bold: true
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                }
                            }
                            Rectangle {
                                Layout.preferredWidth: root.px(72)
                                Layout.preferredHeight: root.px(72)
                                radius: root.px(10)
                                color: root.panelSoftFill(root.themeObj.panelSoft)
                                border.color: root.themeObj.cardBorder
                                border.width: 1
                                Image {
                                    anchors.fill: parent
                                    anchors.margins: root.px(4)
                                    source: backend.roosterSource
                                    fillMode: Image.PreserveAspectFit
                                }
                                MouseArea {
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: roosterPopup.open()
                                }
                                HoverHandler { id: roosterHover }
                                HintToolTip {
                                    visible: roosterHover.hovered
                                    text: "Натисни, якщо дуже хотів поговорити саме з півнем."
                                    themeObj: root.themeObj
                                    uiScale: root.uiScale
                                    fontFamilyName: root.fontFamilyName
                                }
                            }
                        }
                    }

                    CardPanel {
                        visible: Boolean(backend.configMap["show_stats_block"])
                        Layout.fillWidth: true
                        title: "Статистика"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: root.px(8)
                            Text {
                                text: "Режим статистики"
                                color: root.themeObj.textMuted
                                font.family: root.fontFamilyName
                                font.pixelSize: root.fs(0.78)
                                font.bold: true
                            }
                            HomeCombo {
                                id: statsModeCombo
                                Layout.preferredWidth: root.px(200)
                                hint: "Вибираєш, що бачити в статистиці на головній: весь накопичений рахунок або тільки поточний запуск."
                                model: backend.statsModes
                                currentIndex: Math.max(0, backend.statsModes.indexOf(String(backend.configMap["stats_mode"] || "за весь час")))
                                onActivated: backend.setConfigValue("stats_mode", currentText)
                            }
                        }
                        Connections {
                            target: backend
                            function onConfigMapChanged() {
                                const nextIndex = Math.max(0, backend.statsModes.indexOf(String(backend.configMap["stats_mode"] || "за весь час")))
                                if (statsModeCombo.currentIndex !== nextIndex)
                                    statsModeCombo.currentIndex = nextIndex
                            }
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: root.px(6)
                            StatTile { Layout.fillWidth: true; title: "Цілей"; value: String(backend.statsMap.targets || 0); themeObj: root.themeObj; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName }
                            StatTile { Layout.fillWidth: true; title: "Скрінів"; value: String(backend.statsMap.screens || 0); themeObj: root.themeObj; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName }
                            StatTile { Layout.fillWidth: true; title: "Помилок"; value: String(backend.statsMap.errors || 0); themeObj: root.themeObj; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName }
                            StatTile { Layout.fillWidth: true; title: "Рестартів"; value: String(backend.statsMap.restarts || 0); themeObj: root.themeObj; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName }
                        }
                        ActionButton {
                            Layout.fillWidth: true
                            label: "Скинути статистику"
                            hint: "Обнуляє лічильники статистики."
                            fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                            hoverColor: root.themeObj.hoverFill
                            textColor: root.themeObj.text
                            fontSize: root.baseFontSize - 2
                            uiScale: root.uiScale
                            fontFamilyName: root.fontFamilyName
                            onClicked: backend.resetStats()
                        }
                    }

                    CardPanel {
                        visible: Boolean(backend.configMap["show_system_check_block"])
                        Layout.fillWidth: true
                        title: "Системні перевірки"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        Repeater {
                            model: backend.systemChecks
                            delegate: InfoRow {
                                label: modelData.ok ? "✔ " + modelData.name : "✖ " + modelData.name
                                value: modelData.details
                                themeObj: root.themeObj
                                uiScale: root.uiScale
                                fontFamilyName: root.fontFamilyName
                            }
                        }
                    }

                    CardPanel {
                        visible: Boolean(backend.configMap["show_quick_actions_block"])
                        Layout.fillWidth: true
                        title: "Керування"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: root.px(6)
                            ActionButton { Layout.fillWidth: true; label: "ЗАПУСК"; hint: "Запускає Signal Desktop, signal-cli, listener і AHK."; fillColor: root.themeObj.accent; hoverColor: Qt.lighter(root.themeObj.accent, 1.05); fontSize: root.baseFontSize - 1; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: { backend.saveNow(); backend.startAll() } }
                            ActionButton { Layout.fillWidth: true; label: "РЕСТАРТ"; hint: "Зупиняє і запускає модулі заново."; fillColor: root.themeObj.warning; hoverColor: Qt.lighter(root.themeObj.warning, 1.05); fontSize: root.baseFontSize - 1; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: { backend.saveNow(); backend.restartAll() } }
                            ActionButton { Layout.fillWidth: true; label: "СТОП"; hint: "Зупиняє модулі."; fillColor: root.themeObj.danger; hoverColor: Qt.lighter(root.themeObj.danger, 1.05); fontSize: root.baseFontSize - 1; uiScale: root.uiScale; fontFamilyName: root.fontFamilyName; onClicked: { backend.saveNow(); backend.stopAll() } }
                        }
                    }

                    CardPanel {
                        visible: Boolean(backend.configMap["show_last_target_block"])
                        Layout.fillWidth: true
                        title: "Остання ціль"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        Text { Layout.fillWidth: true; text: "Від кого: " + String(backend.lastTarget.source || "—"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Кори: " + String(backend.lastTarget.mgrs || "—"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Н.п.: " + String(backend.lastTarget.place || "—"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Час: " + String(backend.lastTarget.time || "—"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Статус: " + String(backend.lastTarget.state || "Нема"); color: root.themeObj.text; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                    }

                    CardPanel {
                        visible: Boolean(backend.configMap["show_receiver_block"])
                        Layout.fillWidth: true
                        title: "Прийом корів"
                        themeObj: root.themeObj
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        Text { Layout.fillWidth: true; text: backend.configMap["receiver_enabled"] ? "Прийом корів увімкнений" : "Прийом корів вимкнений"; color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Особисті: " + String(backend.configMap["receiver_personal_mode"] || "усі особисті"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Групи: " + (backend.configMap["receiver_accept_groups"] ? "так" : "ні"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Режим груп: " + String(backend.configMap["receiver_group_mode"] || "тільки вибрані"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        Text { Layout.fillWidth: true; text: "Джерело: " + String(backend.configMap["receiver_capture_mode"] || "signal"); color: root.themeObj.textMuted; font.family: root.fontFamilyName; font.pixelSize: root.fs(0.78); font.bold: true; wrapMode: Text.WordWrap }
                        ActionButton {
                            Layout.fillWidth: true
                            label: backend.configMap["receiver_enabled"] ? "Вимкнути прийом" : "Увімкнути прийом"
                            hint: "Швидкий перемикач прийому корів без заходу в налаштування."
                            fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                            hoverColor: root.themeObj.hoverFill
                            textColor: root.themeObj.text
                            fontSize: root.baseFontSize - 2
                            uiScale: root.uiScale
                            fontFamilyName: root.fontFamilyName
                            onClicked: backend.toggleReceiverEnabled()
                        }
                    }

                    Item { Layout.preferredHeight: root.px(10) }
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: root.px(10)
            color: root.panelFill(root.themeObj.panel)
            border.color: root.themeObj.cardBorder
            border.width: 1
            clip: true

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: root.px(10)
                spacing: root.px(8)

                RowLayout {
                    Layout.fillWidth: true
                    spacing: root.px(8)
                    Text {
                        text: "Фільтр логу:"
                        color: root.themeObj.textMuted
                        font.family: root.fontFamilyName
                        font.pixelSize: root.fs(0.8)
                        font.bold: true
                    }
                    HomeCombo {
                        id: filterCombo
                        Layout.preferredWidth: root.px(160)
                        model: backend.logLevels
                        currentIndex: Math.max(0, backend.logLevels.indexOf(root.selectedLogLevel))
                        onActivated: {
                            root.selectedLogLevel = currentText
                            backend.setLogFilter(currentText)
                        }
                        hint: "Все разом, тільки цілі або тільки помилки."
                    }
                    ActionButton {
                        Layout.preferredWidth: root.px(150)
                        label: "Очистити лог"
                        hint: "Очищає лог у вікні та файл на диску."
                        fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                        hoverColor: root.themeObj.hoverFill
                        textColor: root.themeObj.text
                        fontSize: root.baseFontSize - 2
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        onClicked: backend.clearLog()
                    }
                    ActionButton {
                        Layout.preferredWidth: root.px(170)
                        label: "Скопіювати лог"
                        hint: "Копіює видиму частину логу в буфер."
                        fillColor: root.panelSoftFill(root.themeObj.panelSoft)
                        hoverColor: root.themeObj.hoverFill
                        textColor: root.themeObj.text
                        fontSize: root.baseFontSize - 2
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        onClicked: backend.copyLog()
                    }
                    Item { Layout.fillWidth: true }
                    ActionButton {
                        Layout.preferredWidth: root.px(560)
                        label: "Донат розробнику на віскарь, та оплату GPT для подальших оновлень ПЗ 🤗"
                        hint: "Відкрити невелике вікно з QR і номером картки."
                        fillColor: root.themeObj.accent
                        hoverColor: Qt.lighter(root.themeObj.accent, 1.05)
                        textColor: "#ffffff"
                        hoverTextColor: "#ffffff"
                        fontSize: root.baseFontSize - 3
                        wrap: false
                        uiScale: root.uiScale
                        fontFamilyName: root.fontFamilyName
                        onClicked: donatePopup.open()
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    radius: root.px(10)
                    color: root.logFill(root.themeObj.logBg)
                    border.color: root.themeObj.cardBorder
                    border.width: 1
                    clip: true

                    Flickable {
                        id: logFlick
                        anchors.fill: parent
                        anchors.margins: root.px(12)
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        contentWidth: width
                        contentHeight: logText.paintedHeight
                        onContentHeightChanged: {
                            if (backend.getConfigBool("auto_scroll_log"))
                                contentY = Math.max(0, contentHeight - height)
                        }

                        ScrollBar.vertical: AppScrollBar {
                            themeObj: root.themeObj
                            uiScale: root.uiScale
                        }
                        TextEdit {
                            id: logText
                            width: parent.width
                            readOnly: true
                            selectByMouse: true
                            textFormat: TextEdit.RichText
                            wrapMode: TextEdit.WrapAnywhere
                            text: root.previewMode
                                  ? "<span style='color:" + root.themeObj.textDim + ";'>Попередній перегляд інтерфейсу</span>"
                                  : (backend.filteredLogHtml.length > 0 ? backend.filteredLogHtml : "<span style='color:" + root.themeObj.textDim + ";'>Лог порожній</span>")
                            color: root.themeObj.text
                            font.family: "Consolas"
                            font.pixelSize: root.fs(0.8)
                            font.bold: true
                        }
                    }
                }
            }
        }
    }
}
