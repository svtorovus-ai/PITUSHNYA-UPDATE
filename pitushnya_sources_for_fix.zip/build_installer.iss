#ifndef SourceDir
#define SourceDir ".\release"
#endif
#ifndef OutputDir
#define OutputDir ".\installer"
#endif
#ifndef OutputBase
#define OutputBase "PITUSHNYA_MCC_Setup"
#endif
#ifndef AppVersion
#define AppVersion "1.1.8"
#endif
#ifndef TelemetryUrl
#define TelemetryUrl "http://204.168.225.114:8787/telemetry"
#endif
#ifndef TelemetryToken
#define TelemetryToken "pit-1b66fb501c8b48811e10d437"
#endif

[Setup]
AppId={{8D028305-6A7C-4758-A9E0-E0C8D9716C55}
AppName=PITUSHNYA MCC
AppVersion={#AppVersion}
AppPublisher=Grey
AppPublisherURL=https://github.com/svtorovus-ai/PITUSHNYA-UPDATE
AppSupportURL=https://github.com/svtorovus-ai/PITUSHNYA-UPDATE
AppUpdatesURL=https://github.com/svtorovus-ai/PITUSHNYA-UPDATE/releases
DefaultDirName={localappdata}\Programs\PITUSHNYA MCC
DefaultGroupName=PITUSHNYA MCC
OutputDir={#OutputDir}
OutputBaseFilename={#OutputBase}
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\PITUSHNYA MCC.exe
DisableProgramGroupPage=yes
DisableDirPage=no
UsePreviousAppDir=no
CloseApplications=yes
RestartApplications=no
VersionInfoCompany=Grey
VersionInfoDescription=PITUSHNYA MCC Setup
VersionInfoProductName=PITUSHNYA MCC
VersionInfoProductVersion={#AppVersion}
VersionInfoVersion={#AppVersion}
VersionInfoCopyright=Copyright (C) Grey

[Dirs]
Name: "{userdocs}\ShareX"
Name: "{userdocs}\ShareX\Screenshots"
Name: "{userdocs}\ShareX\data"

[Files]
Source: "{#SourceDir}\app\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "config.json,data\*"
Source: "{#SourceDir}\app\config.json"; DestDir: "{app}"; Flags: ignoreversion onlyifdoesntexist
Source: "{#SourceDir}\app\data\*"; DestDir: "{app}\data"; Flags: ignoreversion onlyifdoesntexist recursesubdirs createallsubdirs
Source: "{#SourceDir}\updater\*"; DestDir: "{app}\updater"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#SourceDir}\app\sharex_data\*"; DestDir: "{userdocs}\ShareX"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist

[Icons]
Name: "{autodesktop}\PITUSHNYA MCC"; Filename: "{app}\PITUSHNYA MCC.exe"
Name: "{group}\PITUSHNYA MCC"; Filename: "{app}\PITUSHNYA MCC.exe"
Name: "{group}\Uninstall PITUSHNYA MCC"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\PITUSHNYA MCC.exe"; Description: "Запустити PITUSHNYA MCC"; Flags: nowait postinstall skipifsilent

[InstallDelete]
Type: filesandordirs; Name: "{app}\app"
Type: filesandordirs; Name: "{app}\build"
Type: filesandordirs; Name: "{app}\dist"
Type: filesandordirs; Name: "{app}\__pycache__"

[UninstallDelete]
Type: filesandordirs; Name: "{app}\__pycache__"
Type: filesandordirs; Name: "{app}\build"
Type: filesandordirs; Name: "{app}\dist"

[Code]
var
  InstallTelemetryStarted: Boolean;
  InstallTelemetryFinished: Boolean;
  InstallerSessionId: String;

function JsonEscape(Value: String): String;
begin
  Result := Value;
  StringChangeEx(Result, '\', '\\', True);
  StringChangeEx(Result, '"', '\"', True);
  StringChangeEx(Result, #13#10, '\n', True);
  StringChangeEx(Result, #13, '\n', True);
  StringChangeEx(Result, #10, '\n', True);
end;

function MakeInstallerSessionId(): String;
var
  TypeLib: Variant;
  GuidText: String;
begin
  try
    TypeLib := CreateOleObject('Scriptlet.TypeLib');
    GuidText := TypeLib.Guid;
    StringChangeEx(GuidText, '{', '', True);
    StringChangeEx(GuidText, '}', '', True);
    Result := GuidText;
  except
    Result := GetDateTimeString('yyyymmddhhnnss', '', '') + '-' + ExpandConstant('{computername}');
  end;
end;

procedure KillPitushnyaProcesses();
var
  ResultCode: Integer;
begin
  try
    Exec(ExpandConstant('{cmd}'), '/c taskkill /f /im "PITUSHNYA MCC.exe" /t >nul 2>nul', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  except
  end;

  try
    Exec(ExpandConstant('{cmd}'), '/c taskkill /f /im "target_prompt.exe" /t >nul 2>nul', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  except
  end;

  try
    Exec(ExpandConstant('{cmd}'), '/c taskkill /f /im "pitushnya_updater.exe" /t >nul 2>nul', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  except
  end;

  try
    Exec(ExpandConstant('{cmd}'), '/c taskkill /f /im "AutoHotkey64.exe" /t >nul 2>nul', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  except
  end;
end;

procedure SendInstallerTelemetry(EventName: String);
var
  Http: Variant;
  Payload: String;
  PayloadFile: String;
  PsArgs: String;
  ResultCode: Integer;
  SentOk: Boolean;
begin
  SentOk := False;

  try
    if InstallerSessionId = '' then
      InstallerSessionId := MakeInstallerSessionId();

    Payload := '{' +
      '"event":"' + JsonEscape(EventName) + '",' +
      '"install_id":"installer-' + JsonEscape(InstallerSessionId) + '",' +
      '"installer_session_id":"' + JsonEscape(InstallerSessionId) + '",' +
      '"app_version":"{#AppVersion}",' +
      '"installer_version":"{#AppVersion}",' +
      '"source":"installer",' +
      '"telemetry_enabled":true,' +
      '"ts":"' + JsonEscape(GetDateTimeString('yyyy-mm-dd hh:nn:ss', '', '')) + '"' +
      '}';

    Http := CreateOleObject('WinHttp.WinHttpRequest.5.1');
    Http.SetTimeouts(1500, 1500, 1500, 3000);
    Http.Open('POST', '{#TelemetryUrl}', False);
    Http.SetRequestHeader('Content-Type', 'application/json');
    Http.SetRequestHeader('X-PITUSHNYA-TOKEN', '{#TelemetryToken}');
    Http.SetRequestHeader('User-Agent', 'PITUSHNYA-MCC-Installer-Telemetry/1.1.8');
    Http.Send(Payload);

    SentOk := (Http.Status >= 200) and (Http.Status < 300);
  except
  end;

  if not SentOk then begin
    try
      PayloadFile := ExpandConstant('{tmp}\pitushnya_installer_telemetry.json');
      SaveStringToFile(PayloadFile, Payload, False);

      PsArgs :=
        '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "' +
        '$h=@{''Content-Type''=''application/json'';''X-PITUSHNYA-TOKEN''=''{#TelemetryToken}''};' +
        '$b=Get-Content -LiteralPath ''' + PayloadFile + ''' -Raw;' +
        'Invoke-RestMethod -Uri ''{#TelemetryUrl}'' -Method Post -Headers $h -Body $b -TimeoutSec 4 | Out-Null"';

      Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'), PsArgs, '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
    except
    end;
  end;
end;

function InitializeSetup(): Boolean;
begin
  InstallerSessionId := MakeInstallerSessionId();
  SendInstallerTelemetry('installer_started');
  Result := True;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssInstall then begin
    InstallTelemetryStarted := True;
    SendInstallerTelemetry('install_started');
  end else if CurStep = ssPostInstall then begin
    SendInstallerTelemetry('install_postinstall');
  end else if CurStep = ssDone then begin
    InstallTelemetryFinished := True;
    SendInstallerTelemetry('install_finished');
  end;
end;

procedure DeinitializeSetup();
begin
  if InstallTelemetryStarted and not InstallTelemetryFinished then
    SendInstallerTelemetry('install_cancelled');
end;

function InitializeUninstall(): Boolean;
begin
  InstallerSessionId := MakeInstallerSessionId();
  KillPitushnyaProcesses();
  SendInstallerTelemetry('uninstall_started');
  Result := True;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usUninstall then begin
    KillPitushnyaProcesses();
  end;
end;

procedure DeinitializeUninstall();
begin
  SendInstallerTelemetry('uninstall_finished');
end;