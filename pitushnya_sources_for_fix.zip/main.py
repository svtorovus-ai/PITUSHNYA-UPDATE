import html
import ctypes
import json
import math
import os
import re
import shutil
import socket
import subprocess
import tempfile
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid
from collections import deque
from datetime import datetime
from pathlib import Path
from PySide6.QtCore import QObject, Property, QTimer, QUrl, Signal, Slot, QCoreApplication
from PySide6.QtGui import QDesktopServices, QGuiApplication, QIcon, QAction
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtWidgets import QApplication, QMenu, QSystemTrayIcon
if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).resolve().parent
    RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", str(BASE_DIR)))
    if not (RESOURCE_DIR / "qml").exists():
        RESOURCE_DIR = BASE_DIR
else:
    BASE_DIR = Path(__file__).resolve().parent
    RESOURCE_DIR = BASE_DIR
DATA_DIR = BASE_DIR / "data"
CONFIG_FILE = BASE_DIR / "config.json"
README_FILES = [BASE_DIR / "README.md", BASE_DIR / "README.txt"]
STATS_FILE = DATA_DIR / "ui_stats.json"
EVENT_LOG_FILE = DATA_DIR / "pitusharnya_events.log"
READY_FILE = DATA_DIR / "delta_ready.txt"
STATE_FILE = DATA_DIR / "delta_state.ini"
DEBUG_FILE = DATA_DIR / "delta_debug.txt"
CALLSIGN_FILE = DATA_DIR / "callsign.txt"
TEMPLATE_TIME_FILE = DATA_DIR / "message_template_time_fix.txt"
TEMPLATE_COORDS_FILE = DATA_DIR / "message_template_coords.txt"
HOTKEYS_FILE = DATA_DIR / "hotkeys_description.txt"
RUNTIME_PROFILE_FILE = DATA_DIR / "runtime_profile.json"
TARGET_META_FILE = DATA_DIR / "delta_ready_meta.json"
TARGET_PROMPT_REQUEST_FILE = DATA_DIR / "target_prompt_request.json"
TARGET_PROMPT_RESULT_FILE = DATA_DIR / "target_prompt_result.json"
FORCE_WIZARD_FILE = DATA_DIR / "force_target_wizard.txt"
LISTENER_HEARTBEAT_FILE = DATA_DIR / "listener_heartbeat.txt"
SIGNAL_PROFILE_DIR_DEFAULT = r"data\signal-profile"
DONATE_BUTTON_TEXT = "Донат розробнику"
DONATE_TEXT = "Якщо ця пітушня реально зекономила тобі час, було б не хуйово підкинути розробнику на віскарь, та оплату GPT))\n\nНижче QR для переказу грн, та продубльований номер карти"
DONATE_CARD_NUMBER = "5168745197224980"

TELEMETRY_SERVER_URL = "http://204.168.225.114:8787/telemetry"
TELEMETRY_TOKEN = "pit-1b66fb501c8b48811e10d437"
DEFAULT_UPDATE_INTERVAL_MINUTES = 60

DEFAULT_TIME_TEMPLATE = "Ціль- підар, виявлено: ({time})"
DEFAULT_COORDS_TEMPLATE = "{time} {callsign}, {targets}, за корами ({mgrs}) н.п. ({place}), рух на {direction}"

THEME_NAMES = ["Темний OLED", "Молочний графіт", "Рижий монстр", "Hello Kitty"]
FONT_NAMES = [
    "Segoe UI",
    "Segoe UI Semibold",
    "Segoe UI Black",
    "Arial",
    "Arial Black",
    "Calibri",
    "Calibri Light",
    "Candara",
    "Consolas",
    "Cascadia Mono",
    "Cascadia Code",
    "Verdana",
    "Tahoma",
    "Trebuchet MS",
    "Bahnschrift",
    "Bahnschrift SemiBold",
]
ACCENT_NAMES = ["смарагд", "синій", "помаранчевий", "рожевий"]
TARGET_PROMPT_THEME_PALETTES = {
    "Темний OLED": {"window": "#000000", "panel": "#01060b", "panelAlt": "#071521", "panelSoft": "#10253a", "cardBorder": "#1f4f72", "text": "#f1f7ff", "muted": "#b6c6d8", "accent": "#53ea74", "accent2": "#3f9cff", "warning": "#f4bc3c", "danger": "#ff8a63", "input": "#020913", "inputBorder": "#2d5c82", "hover": "#173550", "selected": "#1b4f7a"},
    "Молочний графіт": {"window": "#e9edf2", "panel": "#f6f7f9", "panelAlt": "#eceff3", "panelSoft": "#e3e8ef", "cardBorder": "#cfd8e3", "text": "#182433", "muted": "#48596c", "accent": "#2468ad", "accent2": "#3f8ff3", "warning": "#c77b1b", "danger": "#e85b52", "input": "#ffffff", "inputBorder": "#d1d8e2", "hover": "#d9e2ee", "selected": "#c8d8ea"},
    "Рижий монстр": {"window": "#100804", "panel": "#130a05", "panelAlt": "#21110a", "panelSoft": "#3a1d0f", "cardBorder": "#7d3a12", "text": "#fff0dc", "muted": "#deb78c", "accent": "#ff7a1f", "accent2": "#ffae3b", "warning": "#ffb03b", "danger": "#ff6c4a", "input": "#170b06", "inputBorder": "#7d3a12", "hover": "#4b2411", "selected": "#5b2a13"},
    "Hello Kitty": {"window": "#ffd8ea", "panel": "#ffe4f0", "panelAlt": "#ffd7e8", "panelSoft": "#ffc3dd", "cardBorder": "#ee7eb2", "text": "#7a224e", "muted": "#963767", "accent": "#ff4fa2", "accent2": "#ff82bd", "warning": "#ff8d52", "danger": "#ff5a7f", "input": "#fff2f8", "inputBorder": "#f39ac3", "hover": "#ffb7d4", "selected": "#ffa2c9"},
}
COMPACT_MODES = ["щільний", "звичайний", "просторий"]
LOG_POSITIONS = ["праворуч", "знизу"]
STATS_MODES = ["за весь час", "за сеанс"]
RECEIVER_PERSONAL_MODES = ["усі особисті", "тільки вибрані"]
RECEIVER_GROUP_MODES = ["усі групи/чати", "тільки вибрані"]
RECEIVER_CAPTURE_MODES = ["signal", "буфер"]
TARGET_PROMPT_MODES = ["послідовно", "все в одному вікні"]
COORD_INPUT_OPTIONS = [
    "MGRS",
    "GEO decimal",
    "GEO deg-min",
    "GEO DMS",
    "СК-42 lat/lon",
    "СК-42 deg-min",
    "СК-42 DMS",
    "UTM",
    "USNG",
]

COORD_OUTPUT_OPTIONS = [
    "MGRS",
    "GEO decimal",
    "GEO deg-min",
    "GEO DMS",
    "СК-42 lat/lon",
    "СК-42 deg-min",
    "СК-42 DMS",
    "UTM",
    "USNG",
]
UPDATE_CHANNELS = ["stable", "beta"]
LEVEL_ORDER = ["Все разом", "Цілі", "Помилки"]
DEFAULT_CONFIG = {
    "title": "PITUSHNYA mcc",
    "theme": "Темний OLED",
    "accent": "смарагд",
    "font_family": "Segoe UI",
    "font_size": 17,
    "ui_scale": 0.80,
    "compact_mode": "звичайний",
    "log_position": "праворуч",
    "left_panel_width": 340,
    "window_x": 80,
    "window_y": 40,
    "window_w": 1540,
    "window_h": 930,
    "remember_tab": "Головна",
    "remember_window": True,
    "night_mode": True,
    "log_poll_ms": 2000,
    "status_poll_ms": 3200,
    "max_log_lines": 1500,
    "auto_scroll_log": True,
    "show_instruction_on_ready": True,
    "start_maximized_after_install": True,
    "minimize_to_tray_on_launch": False,
    "instruction_font_boost": 5,
    "show_stats_block": True,
    "show_status_block": True,
    "show_last_target_block": True,
    "show_receiver_block": True,
    "show_quick_actions_block": True,
    "show_system_check_block": True,
    "stats_mode": "за весь час",
    "receiver_enabled": True,
    "receiver_accept_groups": False,
    "receiver_source_mode": "усі особисті",
    "receiver_personal_mode": "усі особисті",
    "receiver_group_mode": "тільки вибрані",
    "receiver_allowed_senders": [],
    "receiver_allowed_groups": [],
    "signal_number": "",
    "callsign": "ЕКІПАЖ",
    "screenshots_path": str(Path.home() / "Documents" / "ShareX" / "Screenshots"),
    "signal_exe": str(Path.home() / "AppData" / "Local" / "Programs" / "signal-desktop" / "Signal.exe"),
    "signal_cli_bat": "signal-cli-local.bat",
    "signal_cli_http": "127.0.0.1:7583",
    "sharex_exe": "sharex\\ShareX.exe",
    "ahk_exe": "ahk\\AutoHotkey64.exe",
    "ahk_script": "ahk\\Pitusharnya.ahk",
    "listener_script": "py\\delta_listener.py",
    "python_exe": "python\\python.exe",
    "signal_profile_dir": SIGNAL_PROFILE_DIR_DEFAULT,
    "log_bg_color": "#0d1117",
    "log_fg_color": "#e6edf3",
    "log_border_color": "#30363d",
    "log_watermark": "PITUSHNYA mcc",
    "tab_memory_enabled": True,
    "auto_start_on_launch": True,
    "minimize_to_tray_on_launch": False,
    "receiver_watchdog": False,
    "receiver_restart_cooldown_sec": 6,
    "receiver_capture_mode": "signal",
    "coord_input_systems": list(COORD_INPUT_OPTIONS),
    "coord_output_systems": list(COORD_OUTPUT_OPTIONS),
    "coord_output_system": "MGRS",
    "target_prompt_enabled": True,
    "target_prompt_mode": "все в одному вікні",
    "target_prompt_font_size": 14,
    "target_prompt_ui_scale": 0.70,
    "target_prompt_follow_theme": True,
    "target_prompt_allow_same_coords": False,
    "clipboard_capture_ttl_sec": 8,
    "first_run_done": False,
    "signal_linked": False,
    "app_version": "1.1.8",
    "update_channel": "stable",
    "update_manifest_url": "https://raw.githubusercontent.com/svtorovus-ai/PITUSHNYA-UPDATE/main/version.json",
    "auto_check_updates": True,
    "update_check_interval_minutes": 60,
    "last_update_check": "",
    "update_available_version": "",
    "update_download_url": "",
    "update_notes": "",
    "message_template_time_fix": DEFAULT_TIME_TEMPLATE,
    "message_template_coords": DEFAULT_COORDS_TEMPLATE,
    "message_template_time_fix_default": DEFAULT_TIME_TEMPLATE,
    "message_template_coords_default": DEFAULT_COORDS_TEMPLATE,
    "hotkeys_description": "CTRL+ALT+Z — примусово відкрити майстер цілі для останніх готових корів, без вставки часу\nCTRL+SHIFT+Z — вибрати/оновити область захоплення\nCTRL+SPACEBAR — зробити скрін останньої області\nCTRL+ALT+X — кори в чат, якщо auto не спрацювало або вони змінились",
    "telemetry_enabled": True,
    "telemetry_server_url": TELEMETRY_SERVER_URL,
    "telemetry_token": TELEMETRY_TOKEN,
    "telemetry_signal_name": "",
    "install_id": "",
    "telemetry_funnel_app_first_launch_sent": False,
    "telemetry_funnel_callsign_sent": False,
    "telemetry_funnel_signal_link_sent": False,
    "telemetry_funnel_first_run_completed_sent": False,
    "target_type_items": [
        "о/с",
        "мото",
        "АТ",
        "ВАТ",
        "ББМ",
        "Гармата",
        "САУ",
        "РСЗВ",
        "КП",
        "РЕБ",
        "ППО",
        "ЗПМ БпЛА (літакового типу)",
        "ЗПМ БпЛА (вертикального злету, та посадки)"
    ],
    "target_prompt_x": 220,
    "target_prompt_y": 120,
    "target_prompt_w": 560,
    "target_prompt_h": 520,
}
INFO_OVERVIEW_TEXT = """PITUSHNYA MCC — це робоча панель для швидкої подачі цілі: скрін, час виявлення, координати, населений пункт, типи цілей, кількість, напрямок і готовий текст у Signal.

Навіщо воно потрібне:
• не тримати в голові час першого скріна;
• не шукати вручну н.п. біля координат;
• не переписувати координати між різними форматами;
• не складати щоразу один і той самий текст руками;
• не ловити, який із модулів здох: Signal, listener, AHK, ShareX чи Python.

Основний принцип: кожна ціль живе як окремий цикл. Перший скрін відкриває цикл і фіксує час. Координати з дозволеного джерела наповнюють цикл даними. Майстер цілі уточнює типи, кількість і напрямок. Після вставки готового тексту або закриття майстра цикл завершується, а наступний перший скрін починає нову ціль.

Пітушня не має сама вигадувати ціль зі старого буфера або чужого чату. Джерело координат обирається в налаштуваннях: або тільки Signal, або тільки буфер. Комбінованого режиму більше нема, бо саме він плодив дублікати й ламав послідовність. Якщо вибраний буфер, Signal-події не запускають обробку. Якщо вибраний Signal, старий або новий буфер не лізе в цикл.

У повідомлення вставляється не обов'язково той формат, який прилетів. Вхід може бути MGRS, GEO або СК-42, а вихідний формат задається окремо. Це зроблено, щоб оператор міг приймати все, що прилетіло, але віддавати текст у потрібній системі координат."""

INFO_WORKFLOW_TEXT = """1. Перший запуск
Задаєш шлях до Signal, перевіряєш signal-cli, прив'язуєш акаунт через QR і вписуєш позивний. Це одноразовий етап, щоб під час роботи додаток уже знав, кого підставляти в текст і де лежать службові файли.

2. Запуск модулів
Кнопка «ЗАПУСК» підіймає ShareX, signal-cli listener, Python-обробку й AHK-гарячі клавіші. Signal Desktop окремо не відкривається і не закривається автоматично при старті/виході з додатка, щоб не ламати вже відкриті чати.

3. Початок циклу
Перший скрін нової цілі фіксує час виявлення, вставляє сам скрін і додає в Signal короткий текст: «Час виявлення підара зафіксовано: |17:30|». Додаткові скріни в межах активного циклу не повинні перетирати цей час і не повинні дублювати службовий текст.

4. Координати
Координати можуть прийти з Signal або з буфера. Буфер обробляється тільки коли в ньому з'явився новий текст після запуску/перемикання режиму, тому старі кори з минулої роботи не повинні відкривати майстер самі по собі. Signal обробляється тільки тоді, коли режим джерела дозволяє Signal.

5. Пошук н.п.
Після розпізнавання координат додаток приводить їх до MGRS для внутрішньої роботи, шукає населений пункт у локальній GIS-базі, а якщо треба — використовує запасний онлайн-пошук. Якщо н.п. не знайдено, це має бути видно в логові як помилка, а не як мовчазна хуйня.

6. Майстер цілі
Майстер відкривається після готових координат. У ньому вибирається тип цілі, кількість і напрямок. Якщо закрити майстер хрестиком, це вважається завершенням циклу. Нові координати або новий перший скрін знову можуть відкрити майстер.

7. Примусовий запуск
CTRL+ALT+Z просто просить додаток відкрити майстер для останніх готових координат. Він не фіксує час, не вставляє службовий текст і не чіпає Signal зайвий раз. Це аварійна кнопка, коли послідовність збилась або майстер був випадково закритий.

8. Фінальний текст
Фінальний текст складається з часу, позивного, типів/кількості, координат у вибраній вихідній системі, н.п. і напрямку. Після цього цикл вважається закритим, щоб наступна ціль не змішалась із попередньою.

9. Лог
У логові не треба кожне натискання кнопки. Кнопки йдуть у телеметрію, а в додатку лишається те, що допомагає працювати: готовність, цілі, помилки й важливі службові події. Фільтр має три режими: все разом, цілі, помилки."""

INFO_SETTINGS_TEXT = """Прийом вхідних даних
• «Прийом корів увімкнений» — головний рубильник координат. Якщо вимкнено, обробка не стартує ні від Signal, ні від буфера.
• «Джерело корів» — найважливіший перемикач конфліктів. «signal» слухає тільки Signal і повністю ігнорує буфер. «буфер» слухає тільки новий буфер і повністю ігнорує Signal. Варіант «signal + буфер» прибрано, щоб не змішувати дві черги подій і не плодити дублікати цілей.
• «Дозволити групи/чати» відкриває групові повідомлення Signal. Якщо вимкнено, групи відсікаються.
• «Режим особистих» і «Режим груп/чатів» визначають, брати всі джерела чи тільки ті, що вписані нижче.
• «Дозволені абоненти» і «Дозволені чати/групи» — по одному запису на рядок. Для груп можна вписувати назву або ID, якщо він відомий.
• «Вихідна система координат» — формат, який потрапить у фінальне повідомлення. Вхід автоматичний, вихід керований.

Базове і шаблони
• «Позивний» підставляється у фіксацію часу, READY-текст, майстер і фінальне повідомлення.
• Після QR-прив'язки signal-cli сам підтягне номер акаунта, а в базових налаштуваннях буде видно, який Signal прив'язаний.
• «Шаблон: фіксація часу» лишається як службовий шаблон, але коротка фіксація першого скріна використовує зрозумілий текст про час виявлення.
• «Шаблон: коли прилетіли кори» описує чернетку, коли координати вже розпізнані й знайдено н.п.
• У шаблонах працюють змінні {time}, {callsign}, {mgrs}, {place}.

Майстер цілі
• «Увімкнути майстер цілі» дозволяє окреме вікно після координат. Якщо вимкнути, READY-текст усе одно готується, але типи/кількість треба буде дописувати вручну.
• «Режим майстра» перемикає покрокове проходження або компактне вікно.
• «Розмір шрифту майстра» керує тільки текстом у вікні майстра, незалежно від основного інтерфейсу.
• «Масштаб інтерфейсу майстра» стискає або збільшує саме вікно майстра: списки, кнопки, поля кількості й відступи.
• «Підлаштовувати під поточну тему?» змушує майстер брати кольори з вибраної теми. Якщо вимкнути, майстер лишається у стабільній темній схемі.
• «Типи цілей» — список кнопок у майстрі. У налаштуваннях можна додавати, перейменовувати, видаляти й рухати типи кнопками. У самому майстрі порядок міняється перетягуванням, і новий порядок одразу записується назад у налаштування.
• Закриття майстра хрестиком завершує цикл, а не ламає наступний запуск.

Лог і статистика
• «Режим статистики» перемикає весь час або тільки поточний запуск.
• «Оновлення статусу» і «Оновлення логу» впливають на частоту перевірок. Занадто малі значення можуть навантажувати інтерфейс.
• «Максимум рядків логу» обмежує, скільки тексту тримати в UI. Чим більше рядків, тим важче прокрутка.
• Фільтр логу на головній: «Все разом», «Цілі», «Помилки».

Шляхи
• Тут вказані реальні файли Signal, signal-cli, ShareX, AHK, listener і Python.
• Якщо проєкт перенесли або модуль не стартує, спершу перевіряється цей розділ.
• Папка зі скрінами визначає, звідки рахується перший скрін циклу.

Вигляд
• Тема, шрифт, масштаб і базовий розмір шрифту міняють основний інтерфейс.
• Розмір шрифту майстра цілі живе окремо у вкладці «Майстер цілі».
• Галочки блоків головної сторінки ховають або показують картки, але не вимикають логіку модулів.
• Запам'ятовування вкладки й геометрії впливає тільки на те, як відкриється вікно наступного разу."""

INFO_FEEDBACK_TEXT = """Найкорисніший репорт - це опис послідовності дій «дія - очікування - факт - лог/скрін». Можна звісно написати "Все пішло по пизді" але для дебагу це мало чим допоможе))

Канали зв'язку:
• Signal: кнопка нижче;
• Telegram / WhatsApp: +380 50 918 97 97;
• Email: s.v.torovus@gmail.com."""
READY_INSTRUCTION_TEXT = """PITUSHNYA MCC готова до роботи.

1. Відкрий потрібний чат у Signal.
2. Переконайся, що модулі запущені й статус системи зелений.
3. Перший скрін нової цілі робиться через CTRL+SPACEBAR.
4. Перший скрін фіксує час виявлення й вставляє в Signal текст за твоїм шаблоном.
5. Наступні скріни цього ж циклу час не перезаписують.
6. Координати приймаються з джерела, яке вибране в налаштуваннях: Signal або буфер.
7. Після координат відкривається майстер цілі.
8. У майстрі вибираєш тип, кількість і напрямок.
9. Після вставки фінального тексту цикл завершується.
10. Наступний перший скрін починає новий цикл.

Головне правило просте: один цикл = одна ціль.
Якщо щось пішло не туди, дивись лог. Він тепер для цього і потрібен.

З наступного першого скріна для нової цілі підтягнеться актуальний час виявлення."""
def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for p in [EVENT_LOG_FILE, READY_FILE, STATE_FILE, DEBUG_FILE, CALLSIGN_FILE, TEMPLATE_TIME_FILE, TEMPLATE_COORDS_FILE, HOTKEYS_FILE, LISTENER_HEARTBEAT_FILE, FORCE_WIZARD_FILE]:
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("", encoding="utf-8")
    if not TARGET_META_FILE.exists():
        TARGET_META_FILE.write_text("{}", encoding="utf-8")
def clamp_int(value, low, high, default):
    try:
        return max(low, min(high, int(float(value))))
    except Exception:
        return default
def clamp_float(value, low, high, default):
    try:
        return max(low, min(high, float(value)))
    except Exception:
        return default
def load_json_file(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default
def save_json_file(path: Path, data) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
def normalize_template_text(value: str, fallback: str) -> str:
    text = str(value or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    return text if text else fallback


def template_missing_fields(template: str, required_fields: list[str]) -> list[str]:
    text = str(template or "")
    return [field for field in required_fields if field not in text]


def sync_template_files_from_config(config: dict) -> None:
    ensure_dirs()

    time_template = normalize_template_text(
        config.get("message_template_time_fix"),
        config.get("message_template_time_fix_default") or DEFAULT_TIME_TEMPLATE,
    )
    coords_template = normalize_template_text(
        config.get("message_template_coords"),
        config.get("message_template_coords_default") or DEFAULT_COORDS_TEMPLATE,
    )

    TEMPLATE_TIME_FILE.write_text(time_template, encoding="utf-8")
    TEMPLATE_COORDS_FILE.write_text(coords_template, encoding="utf-8")
def tail_lines(path: Path, limit: int):
    result = deque(maxlen=max(10, int(limit)))
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                result.append(line.rstrip("\n"))
    except Exception:
        return []
    return list(result)
def format_prev_target_header(hhmm: str, source: str, mgrs: str, place: str) -> str:
    parts = []
    if hhmm and hhmm not in ("—", ""):
        parts.append(hhmm)
    if source and source not in ("—", ""):
        parts.append(source)
    if mgrs and mgrs not in ("—", ""):
        parts.append(mgrs)
    if place and place not in ("—", ""):
        parts.append(place)
    return " | ".join(parts) if parts else "—"


def _read_text_best_effort(path: Path | None) -> str:
    if not path or not path.exists():
        return ""
    for encoding in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
        except Exception:
            return ""
    return ""


def resolve_readme_files() -> list[Path]:
    candidates: list[tuple[float, int, Path]] = []
    for path in README_FILES:
        if not path.exists():
            continue
        try:
            mtime = path.stat().st_mtime
        except Exception:
            mtime = 0.0
        md_priority = 1 if path.suffix.lower() == ".md" else 0
        candidates.append((mtime, md_priority, path))
    if not candidates:
        return []
    candidates.sort(key=lambda item: (item[0], item[1]))
    return [item[2] for item in candidates]


def _strip_markdown_markup(value: str) -> str:
    text = str(value or "")
    text = re.sub(r"\[(.*?)\]\([^)]+\)", r"\1", text)
    for token in ("**", "__", "`"):
        text = text.replace(token, "")
    return text


def _normalize_readme_title(value: str) -> str:
    text = _strip_markdown_markup(value).strip()
    text = re.sub(r"^#+\s*", "", text)
    return text.rstrip(":").strip()


def _normalize_readme_line(line: str) -> str:
    raw = _strip_markdown_markup(str(line or "").rstrip())
    stripped = raw.strip()
    if not stripped:
        return ""
    if stripped.startswith("#"):
        return re.sub(r"^#+\s*", "", stripped).strip()
    if re.match(r"^[-*]\s+", stripped):
        return "• " + stripped[2:].strip()
    return raw.rstrip()


def _load_single_readme_sections(path: Path | None) -> dict:
    sections = {"overview": "", "workflow": "", "settings": "", "feedback": ""}
    titles = {
        "Опис": "overview",
        "Як це працює": "workflow",
        "Налаштування": "settings",
        "Зворотний зв'язок": "feedback",
    }
    raw = _read_text_best_effort(path)
    if not raw:
        return sections
    current = None
    chunks = {key: [] for key in sections}
    for line in raw.splitlines():
        stripped = line.strip()
        top_match = re.match(r"^##\s+(.+?)\s*$", stripped)
        plain_title = stripped == _normalize_readme_title(stripped)
        if top_match:
            current = titles.get(_normalize_readme_title(top_match.group(1)))
            continue
        if plain_title and _normalize_readme_title(stripped) in titles:
            current = titles.get(_normalize_readme_title(stripped))
            continue
        if current:
            chunks[current].append(_normalize_readme_line(line))
    for key, lines in chunks.items():
        text = "\n".join(lines).strip()
        text = re.sub(r"\n{3,}", "\n\n", text)
        if text:
            sections[key] = text
    return sections


def load_readme_sections(paths) -> dict:
    sections = {"overview": "", "workflow": "", "settings": "", "feedback": ""}
    if not paths:
        return sections
    if isinstance(paths, (str, Path)):
        paths = [paths]
    for path in list(paths):
        parsed = _load_single_readme_sections(Path(path) if path else None)
        for key, value in parsed.items():
            if value:
                sections[key] = value
    return sections
class Backend(QObject):
    themeIndexChanged = Signal()
    uiScaleChanged = Signal()
    fontSizeChanged = Signal()
    leftPanelWidthChanged = Signal()
    fontFamilyChanged = Signal()
    configMapChanged = Signal()
    statusChanged = Signal()
    logTextChanged = Signal()
    statsChanged = Signal()
    targetsChanged = Signal()
    systemChecksChanged = Signal()
    headerChanged = Signal()
    firstRunChanged = Signal()
    updateStateChanged = Signal()
    instructionRequested = Signal()
    targetWizardChanged = Signal()
    targetWizardRequested = Signal()
    noUpdateAvailable = Signal()
    clipboardTargetResolved = Signal(str, str, str)
    def __init__(self):
        super().__init__()
        self._main_window = None
        self._tray_icon = None
        self._tray_menu = None
        self._force_quit_requested = False
        self._startup_time = time.time()
        ensure_dirs()
        self._config = self._load_config()
        self._theme_index = self._theme_name_to_index(self._config.get("theme"))
        self._ui_scale = clamp_float(self._config.get("ui_scale", 0.80), 0.7, 1.4, 0.80)
        self._font_size = clamp_int(self._config.get("font_size", 17), 8, 18, 17)
        self._left_panel_width = clamp_int(self._config.get("left_panel_width", 340), 340, 700, 340)
        self._font_family = str(self._config.get("font_family", "Segoe UI") or "Segoe UI")
        self._log_filter = "Все разом"
        self._log_items = deque(maxlen=max(200, clamp_int(self._config.get("max_log_lines", 5000), 200, 20000, 5000)))
        self._filtered_log_text_cache = ""
        self._filtered_log_html_cache = ""
        self._last_log_mtime = 0.0
        self._log_file_offset = 0
        self._status_map = {"signal": False, "python": False, "ahk": False, "sharex": False}
        self._status_list = []
        self._stats_map = load_json_file(STATS_FILE, {"targets": 0, "screens": 0, "errors": 0, "restarts": 0, "manual_restarts": 0, "auto_restarts": 0})
        self._stats_map = {k: int(self._stats_map.get(k, 0) or 0) for k in ["targets", "screens", "errors", "restarts", "manual_restarts", "auto_restarts"]}
        self._session_stats = {"targets": 0, "screens": 0, "errors": 0, "restarts": 0, "manual_restarts": 0, "auto_restarts": 0}
        self._last_target = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема"}
        self._prev_target = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема"}
        self._system_checks = []
        self._system_status_text = "Ще не перевірено"
        self._system_status_ok = False
        self._system_status_level = "WARN"
        self._system_status_reasons = ""
        self._last_announced_system_status = ""
        self._system_ready_stable_count = 0
        self._system_ready_announced = False
        self._modules_starting_until = 0.0
        self._last_update_text = "—"
        self._update_busy = False
        self._seen_coord_events = set()
        self._seen_target_events = set()
        self._seen_error_events = set()
        self._new_target_events_pending_wizard = set()
        self._telemetry_seen_log_ids = set()
        self._startup_signal_cli_seen = False
        self._startup_error_after_signal_cli = False
        self._startup_started_at = 0.0
        self._spawned = {"signal": None, "python": None, "ahk": None, "sharex": None, "signal_desktop": None}
        self._target_wizard_context = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
        self._last_target_wizard_signature = ""
        self._active_target_key = ""
        self._prompted_target_keys = set()
        self._dismissed_target_keys = set()
        self._suppress_target_wizard = True
        self._instruction_ready_shown = False
        self._config_save_rebuild = False
        self._config_save_timer = QTimer(self)
        self._config_save_timer.setSingleShot(True)
        self._config_save_timer.timeout.connect(self._flush_config_save)
        self._link_poll_timer = QTimer(self)
        self._link_poll_timer.timeout.connect(self._poll_signal_link)
        self._telemetry_timer = QTimer(self)
        self._telemetry_timer.timeout.connect(self._telemetry_tick)
        self._callsign_telemetry_pending = ""
        self._callsign_telemetry_timer = QTimer(self)
        self._callsign_telemetry_timer.setSingleShot(True)
        self._callsign_telemetry_timer.timeout.connect(self._flush_callsign_telemetry)
        self._ui_preview_active = False
        self._last_telemetry_heartbeat_payload = None
        self._last_telemetry_error_sent = None
        self._target_prompt_proc = None
        self._active_target_key = ""
        self._prompted_target_keys = set()
        self._dismissed_target_keys = set()
        self._new_target_events_pending_wizard = set()
        self._instruction_ready_shown = False
        self._link_proc = None
        self._target_prompt_timer = QTimer(self)
        self._target_prompt_timer.timeout.connect(self._poll_target_prompt_result)
        self._clipboard_text_last = ""
        self._clipboard_sequence_last = 0
        self._clipboard_mute_until = time.time() + 5.0
        self._recent_clipboard_signatures = {}
        self._clipboard_place_cache = {}
        self._clipboard_pending_mgrs = set()
        self._place_helper_lock = threading.Lock()
        self._place_helper_mod = None
        self._place_helper_loaded = False
        self._place_helper_loading = False
        self._place_helper_failed = False
        self._place_helper_error = ""
        self._last_force_wizard_text = ""
        self._last_screenshot_scan_at = 0.0
        self._clipboard_timer = QTimer(self)
        self._clipboard_timer.timeout.connect(self._poll_clipboard_capture)
        self.clipboardTargetResolved.connect(self._handle_clipboard_place_resolved)
        self._ensure_place_helper_warming()
        self._auto_configure_paths(silent=True)
        self._ensure_install_id()
        self._info_sections = load_readme_sections(resolve_readme_files())
        self._session_screen_baseline = self._count_screenshot_files()
        self._last_screenshot_count = self._session_screen_baseline
        self._screenshot_cycle_active = False
        self._reset_cycle_runtime_state("app_start")
        self._reset_runtime_session_files()
        self._sync_clipboard_baseline()
        self._load_existing_log()
        self._bootstrap_stats_from_log()
        self._telemetry_seen_log_ids = {self._log_event_id(item) for item in self._log_items if self._log_event_id(item)}
        self._refresh_targets_from_logs()
        self._refresh_status()
        self._log_timer = QTimer(self)
        self._log_timer.timeout.connect(self._refresh_log_from_file)
        self._log_timer.start(self._log_interval())
        self._status_timer = QTimer(self)
        self._status_timer.timeout.connect(self._refresh_status_timer_tick)
        self._status_timer.start(self._status_interval())
        self._telemetry_timer.start(10000)
        self._target_prompt_timer.start(500)
        self._clipboard_timer.start(900)
        QTimer.singleShot(1500, self._release_target_wizard_suppress)
        QTimer.singleShot(1200, self._send_startup_telemetry)
        self._update_check_manual = False
        if bool(self._config.get("auto_check_updates", False)) and self._updates_allowed():
            QTimer.singleShot(1800, lambda: self.checkForUpdates(False))
    def _status_interval(self) -> int:
        return clamp_int(self._config.get("status_poll_ms", 3200), 3000, 10000, 3200)
    def _log_interval(self) -> int:
        return clamp_int(self._config.get("log_poll_ms", 2000), 1800, 10000, 2000)
    def _refresh_status_timer_tick(self):
        self._ensure_place_helper_warming()
        self._refresh_screenshot_stats()
        self._check_force_wizard_request()
        self._refresh_status()
    def _load_config(self) -> dict:
        cfg = dict(DEFAULT_CONFIG)
        try:
            if CONFIG_FILE.exists():
                cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
        cfg["font_size"] = clamp_int(cfg.get("font_size", 17), 8, 18, 17)
        cfg["ui_scale"] = clamp_float(cfg.get("ui_scale", 0.80), 0.7, 1.4, 0.80)
        cfg["left_panel_width"] = clamp_int(cfg.get("left_panel_width", 340), 340, 700, 340)
        cfg["max_log_lines"] = clamp_int(cfg.get("max_log_lines", 5000), 200, 20000, 5000)
        if cfg.get("theme") not in THEME_NAMES:
            cfg["theme"] = THEME_NAMES[0]
        if cfg.get("font_family") not in FONT_NAMES:
            cfg["font_family"] = FONT_NAMES[0]
        if cfg.get("accent") not in ACCENT_NAMES:
            cfg["accent"] = ACCENT_NAMES[0]
        if cfg.get("compact_mode") not in COMPACT_MODES:
            cfg["compact_mode"] = COMPACT_MODES[1]
        if cfg.get("log_position") not in LOG_POSITIONS:
            cfg["log_position"] = LOG_POSITIONS[0]
        if cfg.get("stats_mode") not in STATS_MODES:
            cfg["stats_mode"] = STATS_MODES[0]
        if cfg.get("receiver_personal_mode") not in RECEIVER_PERSONAL_MODES:
            cfg["receiver_personal_mode"] = RECEIVER_PERSONAL_MODES[0]
        if cfg.get("receiver_group_mode") not in RECEIVER_GROUP_MODES:
            cfg["receiver_group_mode"] = DEFAULT_CONFIG["receiver_group_mode"]
        if cfg.get("update_channel") not in UPDATE_CHANNELS:
            cfg["update_channel"] = UPDATE_CHANNELS[0]
        if str(cfg.get("receiver_capture_mode", "") or "").strip().casefold() in {"signal + буфер", "signal+буфер", "signal + buffer"}:
            cfg["receiver_capture_mode"] = "signal"
        if cfg.get("receiver_capture_mode") not in RECEIVER_CAPTURE_MODES:
            cfg["receiver_capture_mode"] = RECEIVER_CAPTURE_MODES[0]
        if str(cfg.get("app_version", "") or "") != DEFAULT_CONFIG["app_version"] and cfg.get("target_prompt_mode") == "послідовно":
            cfg["target_prompt_mode"] = DEFAULT_CONFIG["target_prompt_mode"]
        cfg["app_version"] = DEFAULT_CONFIG["app_version"]
        if cfg.get("target_prompt_mode") not in TARGET_PROMPT_MODES:
            cfg["target_prompt_mode"] = DEFAULT_CONFIG["target_prompt_mode"]
        cfg["target_prompt_font_size"] = clamp_int(cfg.get("target_prompt_font_size", DEFAULT_CONFIG["target_prompt_font_size"]), 11, 24, DEFAULT_CONFIG["target_prompt_font_size"])
        cfg["target_prompt_ui_scale"] = clamp_float(cfg.get("target_prompt_ui_scale", DEFAULT_CONFIG["target_prompt_ui_scale"]), 0.70, 1.30, DEFAULT_CONFIG["target_prompt_ui_scale"])
        cfg["target_prompt_follow_theme"] = bool(cfg.get("target_prompt_follow_theme", True))
        cfg["target_prompt_allow_same_coords"] = bool(cfg.get("target_prompt_allow_same_coords", False))
        cfg["clipboard_capture_ttl_sec"] = clamp_int(cfg.get("clipboard_capture_ttl_sec", DEFAULT_CONFIG["clipboard_capture_ttl_sec"]), 3, 30, DEFAULT_CONFIG["clipboard_capture_ttl_sec"])
        cfg["update_check_interval_minutes"] = clamp_int(cfg.get("update_check_interval_minutes", DEFAULT_UPDATE_INTERVAL_MINUTES), 15, 1440, DEFAULT_UPDATE_INTERVAL_MINUTES)
        cfg["receiver_allowed_senders"] = list(cfg.get("receiver_allowed_senders", []) or [])
        cfg["receiver_allowed_groups"] = list(cfg.get("receiver_allowed_groups", []) or [])
        cfg["coord_input_systems"] = list(COORD_INPUT_OPTIONS)
        cfg["target_type_items"] = [str(x).strip() for x in (cfg.get("target_type_items", []) or []) if str(x).strip()] or list(DEFAULT_CONFIG["target_type_items"])
        cfg["app_version"] = "1.1.8"

        cfg.setdefault("message_template_time_fix_default", DEFAULT_TIME_TEMPLATE)
        cfg.setdefault("message_template_coords_default", DEFAULT_COORDS_TEMPLATE)

        cfg["message_template_time_fix"] = normalize_template_text(
            cfg.get("message_template_time_fix"),
            cfg.get("message_template_time_fix_default") or DEFAULT_TIME_TEMPLATE,
        )
        cfg["message_template_coords"] = normalize_template_text(
            cfg.get("message_template_coords"),
            cfg.get("message_template_coords_default") or DEFAULT_COORDS_TEMPLATE,
        )

        cfg.setdefault("start_maximized_after_install", True)
        cfg.setdefault("minimize_to_tray_on_launch", False)
        cfg.setdefault("show_instruction_on_ready", True)
        cfg.setdefault("coord_output_systems", list(COORD_OUTPUT_OPTIONS))

        if cfg.get("coord_output_system") not in COORD_OUTPUT_OPTIONS:
            cfg["coord_output_system"] = "MGRS"
        return cfg
    def _schedule_config_save(self, rebuild: bool = True):
        self._config_save_rebuild = self._config_save_rebuild or rebuild
        self._config_save_timer.start(120)
    def _flush_config_save(self):
        self._save_config(None, rebuild=self._config_save_rebuild)
        self._config_save_rebuild = False
    def _save_config(self, log_message: str | None = None, rebuild: bool = True):
        self._config["theme"] = THEME_NAMES[self._theme_index]
        sync_template_files_from_config(self._config)
        self._config["ui_scale"] = round(self._ui_scale, 2)
        self._config["font_size"] = int(self._font_size)
        self._config["left_panel_width"] = int(self._left_panel_width)
        self._config["font_family"] = self._font_family
        self._config["telemetry_enabled"] = True
        self._config["telemetry_server_url"] = TELEMETRY_SERVER_URL
        self._config["telemetry_token"] = TELEMETRY_TOKEN
        if not str(self._config.get("telemetry_signal_name", "") or "").strip():
            self._config["telemetry_signal_name"] = str(self._config.get("callsign", "") or "").strip()
        save_json_file(CONFIG_FILE, self._config)
        if hasattr(self, "_log_timer"):
            self._log_timer.setInterval(self._log_interval())
        if hasattr(self, "_status_timer"):
            self._status_timer.setInterval(self._status_interval())
        self.configMapChanged.emit()
        self.firstRunChanged.emit()
        self._rebuild_system_checks()
        if log_message:
            self._append_log("INFO", log_message, also_file=False)
    def begin_preview_mode(self):
        if self._ui_preview_active:
            return
        self._ui_preview_active = True
        try:
            if hasattr(self, "_log_timer"):
                self._log_timer.stop()
            if hasattr(self, "_status_timer"):
                self._status_timer.stop()
        except Exception:
            pass

    def end_preview_mode(self):
        if not self._ui_preview_active:
            return
        self._ui_preview_active = False
        self._last_telemetry_heartbeat_payload = None
        self._last_telemetry_error_sent = None
        self._target_prompt_proc = None
        self._link_proc = None
        self._target_prompt_timer = QTimer(self)
        self._target_prompt_timer.timeout.connect(self._poll_target_prompt_result)
        self._sync_clipboard_baseline()
        self._clipboard_mute_until = time.time() + 3.0
        self._recent_clipboard_signatures = {}
        self._last_force_wizard_text = ""
        self._clipboard_timer = QTimer(self)
        self._clipboard_timer.timeout.connect(self._poll_clipboard_capture)
        try:
            if hasattr(self, "_log_timer"):
                self._log_timer.start(self._log_interval())
            if hasattr(self, "_status_timer"):
                self._status_timer.start(self._status_interval())
        except Exception:
            pass
        self._refresh_status()
        self._refresh_log_from_file()

    def _theme_name_to_index(self, name) -> int:
        try:
            return THEME_NAMES.index(str(name or "").strip())
        except Exception:
            return 0
    def _resolve_path(self, value: str | Path | None) -> Path:
        raw = str(value or "").strip()
        if raw.startswith('"') and raw.endswith('"') and len(raw) > 1:
            raw = raw[1:-1].strip()
        if not raw:
            return BASE_DIR / "__missing__"
        expanded = os.path.expandvars(os.path.expanduser(raw))
        p = Path(expanded)
        if p.is_absolute():
            return p
        return (BASE_DIR / p).resolve()
    def _to_rel_if_inside_base(self, path: Path) -> str:
        try:
            return str(path.resolve().relative_to(BASE_DIR.resolve())).replace("/", "\\")
        except Exception:
            return str(path)

    def _clipboard_capture_enabled(self) -> bool:
        mode = str(self._config.get("receiver_capture_mode", "signal") or "signal").strip().casefold()
        return bool(self._config.get("receiver_enabled", True)) and mode == "буфер"

    def _buffer_place_helper_required(self) -> bool:
        return self._clipboard_capture_enabled()

    def _ensure_place_helper_warming(self) -> None:
        if not self._buffer_place_helper_required():
            return
        if getattr(self, "_place_helper_loaded", False):
            return
        if getattr(self, "_place_helper_failed", False):
            return
        if getattr(self, "_place_helper_loading", False):
            return
        self._place_helper_loading = True
        threading.Thread(target=self._warm_place_helper, daemon=True).start()

    def _same_coords_allowed(self) -> bool:
        return bool(self._config.get("target_prompt_allow_same_coords", False))

    def _clipboard_sequence_number(self) -> int:
        if sys.platform != "win32":
            return 0
        try:
            return int(ctypes.windll.user32.GetClipboardSequenceNumber())
        except Exception:
            return 0

    def _sync_clipboard_baseline(self) -> None:
        try:
            self._clipboard_text_last = QGuiApplication.clipboard().text()
        except Exception:
            self._clipboard_text_last = ""
        self._clipboard_sequence_last = self._clipboard_sequence_number()

    def _remember_recent_clipboard_signature(self, signature: str) -> bool:
        now = time.time()
        window = max(8, int(self._config.get("clipboard_capture_ttl_sec", 8) or 8) * 3)
        self._recent_clipboard_signatures = {
            k: v for k, v in dict(getattr(self, "_recent_clipboard_signatures", {}) or {}).items()
            if (now - float(v or 0)) <= window
        }
        if signature in self._recent_clipboard_signatures:
            return False
        self._recent_clipboard_signatures[signature] = now
        return True

    def _clipboard_cache_key(self, mgrs_text: str) -> str:
        return re.sub(r"\s+", "", str(mgrs_text or "").upper())

    def _mgrs_from_text(self, text: str) -> str:
        raw = str(text or "")
        m = re.search(r'(\d{1,2}[A-Z]\s+[A-Z]{2}\s+\d{4,6}\s+\d{4,6})', raw, re.IGNORECASE)
        if m:
            return self._normalize_mgrs_text(m.group(1)) or re.sub(r"\s+", " ", m.group(1).upper()).strip()
        return self._convert_any_coords_to_mgrs(raw)

    def _normalize_mgrs_text(self, text: str) -> str:
        raw = re.sub(r"\s+", " ", str(text or "").upper()).strip()
        m = re.match(r"^(\d{1,2}[C-HJ-NP-X])\s*([A-HJ-NP-Z]{2})\s*(\d{2,10})(?:\s+|\b)(\d{2,10})$", raw, re.IGNORECASE)
        if m:
            zone, grid, east, north = m.group(1).upper(), m.group(2).upper(), m.group(3), m.group(4)
        else:
            compact = re.sub(r"\s+", "", raw)
            m2 = re.match(r"^(\d{1,2}[C-HJ-NP-X])([A-HJ-NP-Z]{2})(\d{4,20})$", compact, re.IGNORECASE)
            if not m2:
                return ""
            zone, grid, digits = m2.group(1).upper(), m2.group(2).upper(), m2.group(3)
            half = len(digits) // 2
            east, north = digits[:half], digits[half:]
        precision = min(5, max(2, len(east), len(north), 5))
        east = east[:precision].ljust(precision, "0")
        north = north[:precision].ljust(precision, "0")
        return f"{zone} {grid} {east} {north}"

    def _read_detect_time(self) -> str:
        try:
            if not STATE_FILE.exists():
                return ""
            text = STATE_FILE.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"(?im)^\s*time\s*=\s*(\d{2}:\d{2})\s*$", text)
            return m.group(1) if m else ""
        except Exception:
            return ""

    def _dms_to_decimal(self, deg: float, minutes: float = 0.0, seconds: float = 0.0, hemi: str = "") -> float:
        value = abs(float(deg)) + abs(float(minutes)) / 60.0 + abs(float(seconds)) / 3600.0
        hemi = str(hemi or "").strip().upper()
        if hemi in {"S", "W"} or float(deg) < 0:
            value *= -1
        return value

    def _latlon_to_mgrs(self, lat: float, lon: float) -> str:
        try:
            import mgrs as _mgrs_mod
            conv = _mgrs_mod.MGRS()
            raw = str(conv.toMGRS(float(lat), float(lon))).strip().upper()
            mm = re.match(r'^(\d{1,2}[A-Z])([A-Z]{2})(\d+)$', raw)
            if mm and len(mm.group(3)) % 2 == 0:
                half = len(mm.group(3)) // 2
                return f"{mm.group(1)} {mm.group(2)} {mm.group(3)[:half]} {mm.group(3)[half:]}"
            return raw
        except Exception:
            return ""

    def _mgrs_to_latlon(self, mgrs_text: str):
        try:
            import mgrs as _mgrs_mod
            conv = _mgrs_mod.MGRS()
            compact = re.sub(r"\s+", "", str(mgrs_text or "").upper())
            return conv.toLatLon(compact)
        except Exception:
            return None

    def _transform_latlon(self, lat: float, lon: float, src_epsg: int, dst_epsg: int):
        try:
            from pyproj import Transformer
            transformer = Transformer.from_crs(src_epsg, dst_epsg, always_xy=True)
            out_lon, out_lat = transformer.transform(float(lon), float(lat))
            return float(out_lat), float(out_lon)
        except Exception:
            return float(lat), float(lon)

    def _direction_label(self, direction: str) -> str:
        value = str(direction or "").strip().lower()
        mapping = {
            "": "без руху",
            "без руху": "без руху",
            "пн": "пн",
            "пд": "пд",
            "зх": "зх",
            "сх": "сх",
            "пн_зх": "пн-зх",
            "пн-зх": "пн-зх",
            "пн_сх": "пн-сх",
            "пн-сх": "пн-сх",
            "пд_зх": "пд-зх",
            "пд-зх": "пд-зх",
            "пд_сх": "пд-сх",
            "пд-сх": "пд-сх",
        }
        return mapping.get(value, str(direction or "").strip() or "без руху")

    def _format_target_items_for_template(self, items) -> str:
        result = []
        if not isinstance(items, list):
            return ""

        for item in items:
            if isinstance(item, dict):
                name = str(item.get("type", "") or item.get("name", "") or "").strip()
                try:
                    qty = int(float(item.get("qty", 0) or 0))
                except Exception:
                    qty = 0
            else:
                name = str(item or "").strip()
                qty = 0

            if not name:
                continue

            if qty > 0:
                result.append(f"{qty} {name}")
            else:
                result.append(name)

        return ", ".join(result).strip()

    def _build_final_target_text(self, ctx: dict, items, direction: str) -> str:
        ctx = dict(ctx or {})

        template = normalize_template_text(
            self._config.get("message_template_coords"),
            self._config.get("message_template_coords_default") or DEFAULT_COORDS_TEMPLATE,
        )

        detect_time = str(ctx.get("time", "") or self._read_detect_time() or datetime.now().strftime("%H:%M")).strip()
        callsign = str(self._config.get("callsign", "") or ctx.get("callsign", "") or "ЕКІПАЖ").strip()
        mgrs_value = str(ctx.get("mgrs", "") or "").strip()
        place = str(ctx.get("place", "") or "").strip()
        targets = self._format_target_items_for_template(items) or "ціль не вибрана"
        direction_label = self._direction_label(direction)
        coords_out = self._format_coord_output(mgrs_value)

        result = str(template)
        result = result.replace("{time}", detect_time)
        result = result.replace("{callsign}", callsign)
        result = result.replace("{mgrs}", coords_out)
        result = result.replace("{place}", place)
        result = result.replace("{targets}", targets)
        result = result.replace("{target}", targets)
        result = result.replace("{direction}", direction_label)

        result = result.replace("ТУТ ТИП ЦІЛІ", targets)
        result = result.replace("ТУТ НАПРЯМОК РУХУ", direction_label)

        return result.strip()

    def _extract_latlon_candidates(self, raw: str):
        text = str(raw or "").replace(",", ".")
        m = re.search(r'(?P<a>[+-]?\d{1,2}\.\d+)\D+(?P<b>[+-]?\d{1,3}\.\d+)', text)
        if m:
            a = float(m.group('a')); b = float(m.group('b'))
            if abs(a) <= 90 and abs(b) <= 180:
                return a, b
        dm = re.search(r'(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2}\.\d+)\D*([NS])\D+(\d{1,3})[^0-9A-Za-z]{0,3}(\d{1,2}\.\d+)\D*([EW])', text, re.I)
        if dm:
            return self._dms_to_decimal(dm.group(1), dm.group(2), 0, dm.group(3)), self._dms_to_decimal(dm.group(4), dm.group(5), 0, dm.group(6))
        dms = re.search(r'(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2}(?:\.\d+)?)\D*([NS])\D+(\d{1,3})[^0-9A-Za-z]{0,3}(\d{1,2})[^0-9A-Za-z]{0,3}(\d{1,2}(?:\.\d+)?)\D*([EW])', text, re.I)
        if dms:
            return self._dms_to_decimal(dms.group(1), dms.group(2), dms.group(3), dms.group(4)), self._dms_to_decimal(dms.group(5), dms.group(6), dms.group(7), dms.group(8))
        dm_plain = re.search(r'(?<!\d)(\d{1,2})\D+(\d{1,2}(?:\.\d+)?)\D+(\d{2,3})\D+(\d{1,2}(?:\.\d+)?)(?!\d)', text)
        if dm_plain:
            return self._dms_to_decimal(dm_plain.group(1), dm_plain.group(2), 0, "N"), self._dms_to_decimal(dm_plain.group(3), dm_plain.group(4), 0, "E")
        dms_plain = re.search(r'(?<!\d)(\d{1,2})\D+(\d{1,2})\D+(\d{1,2}(?:\.\d+)?)\D+(\d{2,3})\D+(\d{1,2})\D+(\d{1,2}(?:\.\d+)?)(?!\d)', text)
        if dms_plain:
            return self._dms_to_decimal(dms_plain.group(1), dms_plain.group(2), dms_plain.group(3), "N"), self._dms_to_decimal(dms_plain.group(4), dms_plain.group(5), dms_plain.group(6), "E")
        return None

    def _convert_any_coords_to_mgrs(self, raw: str) -> str:
        text = str(raw or "")
        m = re.search(r'(\d{1,2}[A-Z]\s*[A-Z]{2}(?:\s*\d{2,10}\s*\d{2,10}|\d{4,15}))', text, re.IGNORECASE)
        if m:
            normalized = self._normalize_mgrs_text(m.group(1))
            if normalized:
                return normalized
        latlon = self._extract_latlon_candidates(text)
        if not latlon:
            return ""
        lat, lon = float(latlon[0]), float(latlon[1])
        if abs(lat) > 90 or abs(lon) > 180:
            return ""
        raw_lower = text.lower()
        if "ск-42" in raw_lower or "ск42" in raw_lower:
            lat, lon = self._transform_latlon(lat, lon, 4284, 4326)
        return self._latlon_to_mgrs(lat, lon)

    def _cache_clipboard_place(self, cache_key: str, place: str) -> str:
        value = str(place or "").strip()
        if value and not self._place_is_admin_area(value):
            self._clipboard_place_cache[str(cache_key or "")] = value
            return value
        return ""

    def _warm_place_helper(self) -> None:
        try:
            self._load_place_helper()
        finally:
            self._place_helper_loading = False

    def _load_place_helper(self):
        lock = getattr(self, "_place_helper_lock", None)
        if lock is not None:
            with lock:
                return self._load_place_helper_unlocked()
        return self._load_place_helper_unlocked()

    def _load_place_helper_unlocked(self):
        if getattr(self, "_place_helper_failed", False):
            return None
        mod = getattr(self, "_place_helper_mod", None)
        if mod is not None:
            return mod
        try:
            import importlib.util
            helper_path = (BASE_DIR / "py" / "delta_listener.py").resolve()
            if not helper_path.exists():
                self._place_helper_failed = True
                self._place_helper_error = f"helper script not found: {helper_path}"
                return None
            spec = importlib.util.spec_from_file_location("pit_delta_listener", helper_path)
            if not spec or not spec.loader:
                self._place_helper_failed = True
                self._place_helper_error = f"bad import spec for helper: {helper_path}"
                return None
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            self._place_helper_mod = mod
            self._place_helper_error = ""
            try:
                if hasattr(mod, "load_cache"):
                    mod.load_cache()
                polygons = getattr(mod, "POLYGONS_FILE", Path())
                points = getattr(mod, "POINTS_FILE", Path())
                if hasattr(mod, "load_places") and Path(polygons).exists() and Path(points).exists():
                    import contextlib
                    import io
                    orig_println = getattr(mod, "println", None)
                    orig_write_event = getattr(mod, "write_event", None)
                    if callable(orig_println):
                        mod.println = lambda *args, **kwargs: None
                    if callable(orig_write_event):
                        mod.write_event = lambda *args, **kwargs: None
                    with contextlib.redirect_stdout(io.StringIO()):
                        try:
                            mod.load_places()
                        finally:
                            if callable(orig_println):
                                mod.println = orig_println
                            if callable(orig_write_event):
                                mod.write_event = orig_write_event
                    self._place_helper_loaded = True
            except Exception as e:
                self._place_helper_loaded = False
                self._place_helper_error = str(e)
            return mod
        except Exception as e:
            self._place_helper_failed = True
            self._place_helper_error = str(e)
            return None

    def _clipboard_place_via_external_python(self, mgrs_text: str) -> str:
        mgrs_text = str(mgrs_text or "").strip()
        if not mgrs_text:
            return ""
        script = self._resolve_path(self._config.get("listener_script", r"py\delta_listener.py"))
        py = self._resolve_python_executable()
        py_path = py if isinstance(py, Path) else Path(str(py))
        if not script.exists() or not py_path.exists():
            return ""
        helper_code = "\n".join([
            "import importlib.util",
            "import sys",
            "import contextlib",
            "import io",
            "from pathlib import Path",
            "script = Path(sys.argv[1]).resolve()",
            "mgrs_text = str(sys.argv[2]).strip()",
            "spec = importlib.util.spec_from_file_location('pit_delta_listener_sidecar', script)",
            "mod = importlib.util.module_from_spec(spec)",
            "spec.loader.exec_module(mod)",
            "try:",
            "    mod.load_cache()",
            "except Exception:",
            "    pass",
            "gis_loaded = False",
            "orig_println = getattr(mod, 'println', None)",
            "orig_write_event = getattr(mod, 'write_event', None)",
            "if callable(orig_println):",
            "    mod.println = lambda *args, **kwargs: None",
            "if callable(orig_write_event):",
            "    mod.write_event = lambda *args, **kwargs: None",
            "try:",
            "    with contextlib.redirect_stdout(io.StringIO()):",
            "        mod.load_places()",
            "        gis_loaded = True",
            "except Exception:",
            "    gis_loaded = False",
            "finally:",
            "    if callable(orig_println):",
            "        mod.println = orig_println",
            "    if callable(orig_write_event):",
            "        mod.write_event = orig_write_event",
            "lat, lon = mod.mgrs_to_latlon(mgrs_text)",
            "place = ''",
            "if gis_loaded:",
            "    try:",
                "        place = str(mod.nearest_place_local(lat, lon) or '').strip()",
            "    except Exception:",
            "        place = ''",
            "if not place:",
            "    try:",
            "        place = str(mod.nearest_place_online(lat, lon) or '').strip()",
            "    except Exception:",
            "        place = ''",
            "print(place, end='')",
        ])
        try:
            result = subprocess.run(
                [str(py_path), "-c", helper_code, str(script), mgrs_text],
                cwd=str(BASE_DIR),
                capture_output=True,
                text=True,
                timeout=20,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception:
            return ""
        if result.returncode != 0:
            return ""
        lines = [line.strip() for line in str(result.stdout or "").splitlines() if line.strip()]
        return lines[-1] if lines else ""

    def _clipboard_place_for_mgrs(self, mgrs_text: str) -> str:
        if not mgrs_text:
            return "невідомо"
        cache_key = self._clipboard_cache_key(mgrs_text)
        cached = str(getattr(self, "_clipboard_place_cache", {}).get(cache_key, "") or "")
        if cached:
            return cached
        latlon = self._mgrs_to_latlon(mgrs_text)
        helper = self._load_place_helper()
        place = ""
        if helper is not None:
            try:
                lat, lon = helper.mgrs_to_latlon(mgrs_text)
                latlon = (float(lat), float(lon))
                place = helper.nearest_place_local(lat, lon)
                cached_place = self._cache_clipboard_place(cache_key, place)
                if cached_place:
                    return cached_place
            except Exception:
                pass
        if helper is None and not self._place_known(place):
            external_place = self._clipboard_place_via_external_python(mgrs_text)
            cached_place = self._cache_clipboard_place(cache_key, external_place)
            if cached_place:
                return cached_place
        if latlon:
            for zoom in (18, 14, 10):
                try:
                    params = urllib.parse.urlencode({
                        "lat": float(latlon[0]),
                        "lon": float(latlon[1]),
                        "format": "jsonv2",
                        "accept-language": "uk",
                        "zoom": zoom,
                        "addressdetails": 1,
                    })
                    req = urllib.request.Request(
                        f"https://nominatim.openstreetmap.org/reverse?{params}",
                        headers={"User-Agent": "PITUSHNYA-MCC/1.0"},
                    )
                    with urllib.request.urlopen(req, timeout=4) as resp:
                        data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                    addr = data.get("address", {}) if isinstance(data, dict) else {}
                    for key in ("city", "town", "village", "hamlet", "locality", "suburb"):
                        cached_place = self._cache_clipboard_place(cache_key, addr.get(key, ""))
                        if cached_place:
                            return cached_place
                    display = str(data.get("display_name", "") or "").strip() if isinstance(data, dict) else ""
                    if display:
                        for chunk in [x.strip() for x in display.split(",") if x.strip()]:
                            cached_place = self._cache_clipboard_place(cache_key, chunk)
                            if cached_place:
                                return cached_place
                except Exception:
                    continue
        if latlon:
            try:
                overpass = self._nearest_place_overpass(float(latlon[0]), float(latlon[1]))
                if overpass:
                    cached_place = self._cache_clipboard_place(cache_key, overpass)
                    if cached_place:
                        return cached_place
            except Exception:
                pass
        return "невідомо"

    def _nearest_place_overpass(self, lat: float, lon: float) -> str:
        payload = {}
        for radius in (18000, 45000):
            query = f"""
            [out:json][timeout:9];
            (
              node(around:{radius},{float(lat)},{float(lon)})["place"~"^(city|town|village|hamlet|locality)$"]["name"];
              way(around:{radius},{float(lat)},{float(lon)})["place"~"^(city|town|village|hamlet|locality)$"]["name"];
              relation(around:{radius},{float(lat)},{float(lon)})["place"~"^(city|town|village|hamlet|locality)$"]["name"];
            );
            out tags center 80;
            """
            data = urllib.parse.urlencode({"data": query}).encode("utf-8")
            for url in ("https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"):
                try:
                    req = urllib.request.Request(
                        url,
                        data=data,
                        headers={"User-Agent": "PITUSHNYA-MCC/1.0", "Content-Type": "application/x-www-form-urlencoded"},
                        method="POST",
                    )
                    with urllib.request.urlopen(req, timeout=6) as resp:
                        payload = json.loads(resp.read().decode("utf-8", errors="ignore"))
                    if isinstance(payload, dict) and payload.get("elements"):
                        break
                except Exception:
                    payload = {}
            if isinstance(payload, dict) and payload.get("elements"):
                break
        best = None
        for el in payload.get("elements", []) if isinstance(payload, dict) else []:
            tags = el.get("tags", {}) or {}
            name = str(tags.get("name:uk") or tags.get("name") or "").strip()
            if not name:
                continue
            try:
                center = el.get("center", {}) or {}
                plat = float(el.get("lat", center.get("lat")))
                plon = float(el.get("lon", center.get("lon")))
            except Exception:
                continue
            dist = self._haversine_km(float(lat), float(lon), plat, plon)
            place_type = str(tags.get("place") or "")
            bonus = {"city": 6.0, "town": 2.0, "village": 0.0, "hamlet": 0.3, "locality": 1.2}.get(place_type, 0.0)
            score = dist + bonus
            if best is None or score < best["score"]:
                best = {"name": name, "score": score}
        return str(best["name"]) if best else ""

    @staticmethod
    def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        r = 6371.0
        p1 = math.radians(float(lat1))
        p2 = math.radians(float(lat2))
        dp = math.radians(float(lat2) - float(lat1))
        dl = math.radians(float(lon2) - float(lon1))
        a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
        return 2 * r * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1 - a)))

    def _place_known(self, place: str) -> bool:
        value = str(place or "").strip().casefold()
        return bool(value) and value not in {"невідомо", "н.п. невідомо", "unknown", "none", "null", "—", "-"} and not self._place_is_admin_area(place)

    @staticmethod
    def _place_is_admin_area(place: str) -> bool:
        value = str(place or "").strip().casefold()
        admin_words = (
            "громада",
            "територіальна громада",
            "район",
            "область",
            "адміністративний округ",
            "municipality",
            "community",
            "district",
            "oblast",
            "raion",
            "україна",
            "ukraine",
        )
        return any(word in value for word in admin_words)

    def _target_key(self, source: str, mgrs: str) -> str:
        return f"{str(source or '').strip().casefold()}|{str(mgrs or '').strip().upper()}"

    def _target_key_from_context(self, ctx: dict | None = None) -> str:
        data = dict(ctx or self._target_wizard_context or {})
        return self._target_key(str(data.get("source", "") or ""), str(data.get("mgrs", "") or ""))

    def _poll_clipboard_capture(self):
        if not self._clipboard_capture_enabled():
            self._sync_clipboard_baseline()
            return
        if time.time() < float(self._clipboard_mute_until or 0):
            self._sync_clipboard_baseline()
            return
        try:
            text = QGuiApplication.clipboard().text()
        except Exception:
            return
        seq = self._clipboard_sequence_number()
        same_text = text == self._clipboard_text_last
        same_sequence = bool(seq) and seq == int(getattr(self, "_clipboard_sequence_last", 0) or 0)
        if not text or (same_text and (not seq or same_sequence or not self._same_coords_allowed())):
            return
        self._clipboard_text_last = text
        self._clipboard_sequence_last = seq
        mgrs = self._mgrs_from_text(text)
        if not mgrs:
            return
        self._resolve_clipboard_target_async(mgrs)

    def _resolve_clipboard_target_async(self, mgrs: str) -> None:
        mgrs = self._normalize_mgrs_text(mgrs) or str(mgrs or "").strip()
        if not mgrs:
            return
        cache_key = self._clipboard_cache_key(mgrs)
        cached = str(getattr(self, "_clipboard_place_cache", {}).get(cache_key, "") or "")
        if cached:
            self._handle_clipboard_target(mgrs, cached)
            return
        pending = getattr(self, "_clipboard_pending_mgrs", set())
        if cache_key in pending:
            return
        pending.add(cache_key)
        self._clipboard_pending_mgrs = pending
        threading.Thread(target=self._resolve_clipboard_target_worker, args=(mgrs, cache_key), daemon=True).start()

    def _resolve_clipboard_target_worker(self, mgrs: str, cache_key: str) -> None:
        place = ""
        try:
            place = self._clipboard_place_for_mgrs(mgrs)
        except Exception:
            place = ""
        try:
            self.clipboardTargetResolved.emit(str(mgrs or ""), str(place or ""), str(cache_key or ""))
        except Exception:
            pass

    @Slot(str, str, str)
    def _handle_clipboard_place_resolved(self, mgrs: str, place: str, cache_key: str) -> None:
        try:
            self._clipboard_pending_mgrs.discard(str(cache_key or ""))
        except Exception:
            self._clipboard_pending_mgrs = set()
        if not self._clipboard_capture_enabled():
            return
        self._handle_clipboard_target(mgrs, place)

    def _handle_clipboard_target(self, mgrs: str, place: str) -> None:
        mgrs = self._normalize_mgrs_text(mgrs) or str(mgrs or "").strip()
        place = str(place or "").strip()
        if not mgrs:
            return
        if not self._place_known(place):
            self._append_log("ERROR", f'Буфер: знайшов кори {mgrs}, але не визначив н.п. Ціль не відкриваю, щоб не вставляти "невідомо".', also_file=False)
            return
        signature = f"буфер обміну|{mgrs.upper()}|{place.casefold()}"
        target_key = self._target_key("Буфер обміну", mgrs)
        if not self._same_coords_allowed() and not self._remember_recent_clipboard_signature(signature):
            return
        if not self._same_coords_allowed() and (target_key in self._dismissed_target_keys or target_key in self._prompted_target_keys):
            return
        if signature == str(self._last_target_wizard_signature or "") and self._target_prompt_proc is not None:
            return
        hhmm = self._read_detect_time() or datetime.now().strftime("%H:%M")
        self._target_wizard_context = {
            "source": "Буфер обміну",
            "mgrs": mgrs,
            "place": place,
            "time": hhmm,
            "state": "Оброблено",
            "signature": signature,
        }
        try:
            coords_out = self._format_coord_output(mgrs)
            preview_template = normalize_template_text(
                self._config.get("message_template_coords"),
                self._config.get("message_template_coords_default") or DEFAULT_COORDS_TEMPLATE,
            )
            preview_text = str(preview_template)
            preview_text = preview_text.replace("{time}", hhmm)
            preview_text = preview_text.replace("{callsign}", str(self._config.get("callsign", "ЕКІПАЖ") or "ЕКІПАЖ"))
            preview_text = preview_text.replace("{mgrs}", coords_out)
            preview_text = preview_text.replace("{place}", place)
            preview_text = preview_text.replace("{targets}", "ТУТ ТИП ЦІЛІ")
            preview_text = preview_text.replace("{target}", "ТУТ ТИП ЦІЛІ")
            preview_text = preview_text.replace("{direction}", "ТУТ НАПРЯМОК РУХУ")
            READY_FILE.write_text(preview_text, encoding="utf-8")
            self._write_target_meta({"source": "Буфер обміну", "mgrs": mgrs, "place": place, "time": hhmm, "signature": signature})
        except Exception:
            pass
        self._append_log("READY", f'Отримав кори від "Буфер обміну": {mgrs} -> {place}', also_file=False)
        self._maybe_launch_target_prompt_from_context()

    def _open_path(self, path: Path):
        if not path.exists():
            if path.suffix:
                path.parent.mkdir(parents=True, exist_ok=True)
            else:
                path.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
    def _detect_signal_desktop_candidates(self):
        result = []
        local = os.environ.get("LOCALAPPDATA", "")
        roaming = os.environ.get("APPDATA", "")
        home = str(Path.home())
        for raw in [
            Path(local) / "Programs" / "signal-desktop" / "Signal.exe",
            Path(roaming) / "Programs" / "signal-desktop" / "Signal.exe",
            Path(home) / "AppData" / "Local" / "Programs" / "signal-desktop" / "Signal.exe",
        ]:
            if raw not in result:
                result.append(raw)
        return result
    def _ensure_sharex_documents_seed(self) -> bool:
        changed = False
        dst = Path.home() / "Documents" / "ShareX"
        screenshots = dst / "Screenshots"
        service_files = {
            "ApplicationConfig.json",
            "AutoHotkey64.exe",
            "HotkeysConfig.json",
            "PersonalPath.cfg",
            "Signal-skrin.ahk",
            "UploadersConfig.json",
            "run_sharex_action.bat",
        }
        service_dirs = {"ImageEffects", "ShareX"}
        try:
            if not dst.exists():
                dst.mkdir(parents=True, exist_ok=True)
                changed = True
            screenshots.mkdir(parents=True, exist_ok=True)
            src = BASE_DIR / "sharex_data"
            if src.exists() and src.is_dir():
                for item in src.iterdir():
                    target = dst / item.name
                    if item.is_dir():
                        if item.name in service_dirs or not target.exists():
                            before = target.exists()
                            shutil.copytree(item, target, dirs_exist_ok=True)
                            changed = changed or not before or item.name in service_dirs
                    elif item.is_file():
                        if item.name in service_files or not target.exists():
                            shutil.copy2(item, target)
                            changed = True
        except Exception:
            pass
        return changed

    def _sync_sharex_runtime_files(self) -> None:
        docs_root = Path.home() / "Documents" / "ShareX"
        docs_data = docs_root / "data"
        try:
            docs_root.mkdir(parents=True, exist_ok=True)
            docs_data.mkdir(parents=True, exist_ok=True)
            (docs_data / CALLSIGN_FILE.name).write_text(str(self._config.get("callsign", "") or "").strip(), encoding="utf-8")
            (docs_data / TEMPLATE_TIME_FILE.name).write_text(str(self._config.get("message_template_time_fix", "") or ""), encoding="utf-8")
            (docs_data / TEMPLATE_COORDS_FILE.name).write_text(str(self._config.get("message_template_coords", "") or ""), encoding="utf-8")
            (docs_data / HOTKEYS_FILE.name).write_text(str(self._config.get("hotkeys_description", "") or ""), encoding="utf-8")
            save_json_file(docs_data / RUNTIME_PROFILE_FILE.name, {
                "callsign": str(self._config.get("callsign", "") or ""),
                "signal_number": str(self._config.get("signal_number", "") or ""),
                "signal_http": str(self._config.get("signal_cli_http", "127.0.0.1:7583") or "127.0.0.1:7583"),
                "signal_exe": str(self._resolve_path(self._config.get("signal_exe", ""))),
                "receiver_enabled": bool(self._config.get("receiver_enabled", True)),
                "receiver_accept_groups": bool(self._config.get("receiver_accept_groups", False)),
                "receiver_personal_mode": self._config.get("receiver_personal_mode", "усі особисті"),
                "receiver_group_mode": self._config.get("receiver_group_mode", "тільки вибрані"),
                "receiver_allowed_senders": list(self._config.get("receiver_allowed_senders", [])),
                "receiver_allowed_groups": list(self._config.get("receiver_allowed_groups", [])),
                "receiver_capture_mode": self._config.get("receiver_capture_mode", "signal"),
                "receiver_ignore_own_account": bool(self._config.get("receiver_ignore_own_account", True)),
                "receiver_ignore_last_generated_message": bool(self._config.get("receiver_ignore_last_generated_message", True)),
                "coord_output_system": self._config.get("coord_output_system", "MGRS"),
                "message_template_time_fix": self._config.get("message_template_time_fix", ""),
                "message_template_coords": self._config.get("message_template_coords", ""),
                "hotkeys_description": self._config.get("hotkeys_description", ""),
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            })
        except Exception:
            pass
    def _auto_configure_paths(self, silent=False):
        changed = self._ensure_sharex_documents_seed()
        mapping = {
            "sharex_exe": BASE_DIR / "sharex" / "ShareX.exe",
            "ahk_exe": BASE_DIR / "ahk" / "AutoHotkey64.exe",
            "ahk_script": BASE_DIR / "ahk" / "Pitusharnya.ahk",
            "listener_script": BASE_DIR / "py" / "delta_listener.py",
            "signal_cli_bat": BASE_DIR / "signal-cli-local.bat",
        }
        py_internal = BASE_DIR / "python" / "python.exe"
        if py_internal.exists():
            mapping["python_exe"] = py_internal
        for key, candidate in mapping.items():
            current = self._resolve_path(self._config.get(key, "")) if str(self._config.get(key, "")).strip() else Path()
            if current.exists():
                continue
            if candidate.exists():
                self._config[key] = self._to_rel_if_inside_base(candidate)
                changed = True
        screenshots_raw = str(self._config.get("screenshots_path", DEFAULT_CONFIG["screenshots_path"]) or "").strip()
        screenshots_dir = self._resolve_path(screenshots_raw)
        docs_screenshots = Path.home() / "Documents" / "ShareX" / "Screenshots"
        if screenshots_dir.name.lower() == "sharex":
            screenshots_dir = screenshots_dir / "Screenshots"
            self._config["screenshots_path"] = str(docs_screenshots if "Documents" in str(screenshots_dir) else screenshots_dir)
            changed = True
        try:
            current_home = str(Path.home().resolve()).lower()
            resolved_screens = str(screenshots_dir.resolve()).lower()
            if "\\documents\\sharex" in resolved_screens and not resolved_screens.startswith(current_home):
                screenshots_dir = docs_screenshots
                self._config["screenshots_path"] = str(docs_screenshots)
                changed = True
        except Exception:
            pass
        try:
            screenshots_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            fallback = docs_screenshots
            fallback.mkdir(parents=True, exist_ok=True)
            self._config["screenshots_path"] = str(fallback)
            changed = True
        self._config["signal_profile_dir"] = SIGNAL_PROFILE_DIR_DEFAULT
        signal_path = self._resolve_path(self._config.get("signal_exe", "")) if str(self._config.get("signal_exe", "")).strip() else Path()
        candidates = self._detect_signal_desktop_candidates()
        if not str(self._config.get("signal_exe", "")).strip() and candidates:
            self._config["signal_exe"] = str(candidates[0])
            signal_path = self._resolve_path(self._config.get("signal_exe", ""))
            changed = True
        if not signal_path.exists():
            for candidate in candidates:
                if candidate.exists():
                    self._config["signal_exe"] = str(candidate)
                    changed = True
                    break
        if changed and not silent:
            self._save_config("Шляхи автопідібрано")
        elif changed:
            save_json_file(CONFIG_FILE, self._config)
            self.configMapChanged.emit()
            self.firstRunChanged.emit()
        return changed
    def _ensure_install_id(self):
        raw = str(self._config.get("install_id", "") or "").strip()
        if raw:
            return raw
        raw = str(uuid.uuid4())
        self._config["install_id"] = raw
        save_json_file(CONFIG_FILE, self._config)
        return raw
    def _activate_signal_window(self):
        if sys.platform != "win32":
            return False
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            target_pid = None
            proc = self._spawned.get("signal_desktop")
            if proc and proc.poll() is None:
                target_pid = int(proc.pid)
            hwnds = []
            EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            def _enum(hwnd, lparam):
                if not user32.IsWindowVisible(hwnd):
                    return True
                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                title = ctypes.create_unicode_buffer(512)
                user32.GetWindowTextW(hwnd, title, 512)
                t = title.value or ""
                if target_pid and pid.value == target_pid:
                    hwnds.append(hwnd)
                elif ("signal" in t.lower()) and pid.value:
                    hwnds.append(hwnd)
                return True
            user32.EnumWindows(EnumWindowsProc(_enum), 0)
            if not hwnds:
                return False
            hwnd = hwnds[-1]
            if user32.IsIconic(hwnd):
                user32.ShowWindow(hwnd, 9)
            elif not user32.IsWindowVisible(hwnd):
                user32.ShowWindow(hwnd, 5)
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
            time.sleep(0.05)
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
            return True
        except Exception:
            return False

    def _mark_cycle_started(self, source: str = "скрін"):
        if self._screenshot_cycle_active:
            return

        detect_time = datetime.now().strftime("%H:%M")

        try:
            STATE_FILE.write_text(f"[delta]\nstatus=waiting_coords\ntime={detect_time}\n", encoding="utf-8")
        except Exception:
            pass

        self._screenshot_cycle_active = True
        self._append_log("INFO", f"Зафіксував час по першому {source} циклу: {detect_time}", also_file=False)

    def _finish_cycle(self, reason: str = "") -> None:
        active_key = self._target_key_from_context()
        if active_key:
            if reason and reason not in {"target_inserted", "inserted"}:
                self._dismissed_target_keys.add(active_key)
            else:
                self._dismissed_target_keys.discard(active_key)
            self._prompted_target_keys.discard(active_key)
        self._screenshot_cycle_active = False
        self._target_prompt_proc = None
        self._active_target_key = ""
        self._recent_clipboard_signatures = {}
        try:
            detect_time = self._read_detect_time() or datetime.now().strftime("%H:%M")
            STATE_FILE.write_text(f"[delta]\nstatus=idle\ntime={detect_time}\nlast_reason={reason}\n", encoding="utf-8")
        except Exception:
            pass

    def _reset_cycle_runtime_state(self, reason: str = "startup") -> None:
        self._screenshot_cycle_active = False
        self._active_target_key = ""
        self._recent_clipboard_signatures = {}
        try:
            STATE_FILE.write_text(f"[delta]\nstatus=idle\ntime=\nlast_reason={reason}\n", encoding="utf-8")
        except Exception:
            pass

    def _reset_runtime_session_files(self) -> None:
        self._target_wizard_context = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
        self._last_target_wizard_signature = ""
        self._last_force_wizard_text = ""
        self._active_target_key = ""
        self._new_target_events_pending_wizard = set()
        self._prompted_target_keys = set()
        self._dismissed_target_keys = set()
        self._target_prompt_proc = None
        for path, content in [
            (READY_FILE, ""),
            (FORCE_WIZARD_FILE, ""),
            (TARGET_META_FILE, "{}"),
        ]:
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="utf-8")
            except Exception:
                pass
        for path in [TARGET_PROMPT_REQUEST_FILE, TARGET_PROMPT_RESULT_FILE]:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass

    def _clear_receiver_cycle_guards(self, reason: str = "receiver_changed") -> None:
        self._active_target_key = ""
        self._last_target_wizard_signature = ""
        self._recent_clipboard_signatures = {}
        self._new_target_events_pending_wizard = set()
        self._prompted_target_keys = set()
        self._dismissed_target_keys = set()
        self._target_wizard_context = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
        for path, content in [(READY_FILE, ""), (TARGET_META_FILE, "{}")]:
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="utf-8")
            except Exception:
                pass
        self._reset_cycle_runtime_state(reason)

    def _release_target_wizard_suppress(self) -> None:
        self._suppress_target_wizard = False

    def _maybe_launch_target_prompt_from_context(self) -> bool:
        ctx = dict(self._target_wizard_context or {})
        source = str(ctx.get("source", "") or "")
        mgrs = str(ctx.get("mgrs", "") or "")
        place = str(ctx.get("place", "") or "")
        signature = str(ctx.get("signature", "") or "")
        target_key = self._target_key(source, mgrs)
        if not target_key or "|" not in target_key or target_key.endswith("|"):
            return False
        if not self._same_coords_allowed() and (target_key in self._dismissed_target_keys or target_key in self._prompted_target_keys):
            return False
        if not self._place_known(place):
            self._append_log("ERROR", f"Кори {mgrs}: н.п. не визначено, майстер не запускаю.", also_file=False)
            return False
        if self._target_prompt_proc is not None:
            try:
                if self._target_prompt_proc.poll() is None:
                    return False
            except Exception:
                pass
        self._active_target_key = target_key
        if signature:
            self._last_target_wizard_signature = signature
        launched = self._launch_target_prompt()
        if launched:
            if not self._same_coords_allowed():
                self._prompted_target_keys.add(target_key)
        return bool(launched)

    def _check_force_wizard_request(self) -> None:
        try:
            if not FORCE_WIZARD_FILE.exists():
                return
            token = FORCE_WIZARD_FILE.read_text(encoding="utf-8", errors="ignore").strip()
        except Exception:
            return
        if not token or token == str(getattr(self, "_last_force_wizard_text", "") or ""):
            return
        self._last_force_wizard_text = token
        meta = self._load_target_meta()
        if not meta:
            self._screenshot_cycle_active = False
            self._append_log("WARN", "CTRL+ALT+Z: нема останніх готових корів для майстра цілі", also_file=False)
            return
        self._screenshot_cycle_active = True
        signature = str(meta.get("signature") or "")
        self._target_wizard_context = {
            "source": meta.get("source") or self._last_target.get("source", "—"),
            "mgrs": meta.get("mgrs") or self._last_target.get("mgrs", "—"),
            "place": meta.get("place") or self._last_target.get("place", "—"),
            "time": meta.get("time") or self._read_detect_time() or datetime.now().strftime("%H:%M"),
            "state": "Оброблено",
            "signature": signature,
        }
        self.targetWizardChanged.emit()
        target_key = self._target_key_from_context()
        if target_key:
            self._dismissed_target_keys.discard(target_key)
            self._prompted_target_keys.discard(target_key)
        self._maybe_launch_target_prompt_from_context()

    def _signal_profile_dir(self) -> Path:
        p = self._resolve_path(self._config.get("signal_profile_dir", SIGNAL_PROFILE_DIR_DEFAULT))
        try:
            p.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return p
    def _signal_cli_base_cmd(self):
        cli = self._resolve_path(self._config.get("signal_cli_bat", "signal-cli-local.bat"))
        if not cli.exists():
            return None
        return [str(cli), "--config", str(self._signal_profile_dir())]
    def _resolve_python_executable(self):
        raw = str(self._config.get("python_exe", "") or "").strip()
        internal = (BASE_DIR / "python" / "python.exe").resolve()
        if internal.exists():
            return internal
        if not raw:
            return sys.executable
        expanded = os.path.expandvars(os.path.expanduser(raw))
        p = Path(expanded)
        if raw and not any(sep in raw for sep in ("\\", "/")) and not p.suffix:
            return raw
        resolved = self._resolve_path(raw)
        if resolved.is_dir():
            for cand in [resolved / "python.exe", resolved / "Scripts" / "python.exe"]:
                if cand.exists():
                    return cand
        return resolved
    def _screenshot_folders(self):
        candidates = []
        seen = set()
        configured = self._resolve_path(self._config.get("screenshots_path", "screenshots"))
        if configured.name.lower() == "sharex":
            configured = configured / "Screenshots"
        raw = [
            configured,
            Path.home() / "Documents" / "ShareX" / "Screenshots",
        ]
        for folder in raw:
            try:
                key = str(folder.resolve())
            except Exception:
                key = str(folder)
            if key in seen:
                continue
            seen.add(key)
            candidates.append(folder)
        return candidates

    def _count_screenshot_files(self) -> int:
        try:
            files = set()
            for idx, folder in enumerate(self._screenshot_folders()):
                if not folder.exists():
                    continue
                iterator = folder.rglob("*") if idx == 0 else folder.glob("*")
                for p in iterator:
                    if p.is_file() and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                        try:
                            files.add(str(p.resolve()))
                        except Exception:
                            files.add(str(p))
            return len(files)
        except Exception:
            return 0

    def _log_colors(self) -> dict:
        theme_name = str(self._config.get("theme", THEME_NAMES[0]) or THEME_NAMES[0])
        if theme_name == "Hello Kitty":
            return {
                "ERROR": "#ff6b7d",
                "WARN": "#ffd166",
                "OK": "#f9e8ff",
                "READY": "#42ff86",
                "SYSTEM": "#8bd5ff",
                "INFO": "#f9e8ff",
            }
        ready_color = "#0d7a37" if theme_name in {"Молочний графіт", "Hello Kitty"} else "#56ef66"
        system_color = "#2468ad" if theme_name in {"Молочний графіт", "Hello Kitty"} else "#7ee787"
        info_color = "#425266" if theme_name in {"Молочний графіт", "Hello Kitty"} else "#c9d1d9"
        if theme_name in {"Молочний графіт", "Hello Kitty"}:
            return {
                "ERROR": "#c73943",
                "WARN": "#9b5b00",
                "OK": info_color,
                "READY": ready_color,
                "SYSTEM": system_color,
                "INFO": info_color,
            }
        return {
            "ERROR": "#ff7b72",
            "WARN": "#f2cc60",
            "OK": info_color,
            "READY": ready_color,
            "SYSTEM": system_color,
            "INFO": info_color,
        }

    def _rebuild_log_cache(self):
        colors = self._log_colors()
        items = list(self._log_items)
        if self._log_filter == "Помилки":
            items = [x for x in items if x.get("level") == "ERROR"]
        elif self._log_filter == "Цілі":
            items = [
                x for x in items
                if self._target_signature(x)
                or "сформовано текст цілі" in str(x.get("msg", "")).casefold()
            ]
        self._filtered_log_text_cache = "\n".join(x.get("display", "") for x in items)
        lines = []
        for x in items:
            level = str(x.get("level", "INFO")).upper()
            msg = html.escape(x.get("display", ""))
            color = colors.get(level, "#c9d1d9")
            lines.append(f'<span style="color:{color};">{msg}</span>')
        self._filtered_log_html_cache = '<pre style="margin:0; white-space:pre-wrap; font-family:Consolas, monospace;">' + '<br/>'.join(lines) + '</pre>'

    def _load_existing_log(self):
        self._log_items.clear()
        self._log_file_offset = 0
        if not EVENT_LOG_FILE.exists():
            self._last_log_mtime = 0.0
            self._rebuild_log_cache()
            return
        try:
            stat = EVENT_LOG_FILE.stat()
            self._last_log_mtime = stat.st_mtime
            self._log_file_offset = stat.st_size
        except Exception:
            pass
        self._rebuild_log_cache()

    def _parse_log_line(self, raw: str):
        raw = str(raw or "").strip()
        if not raw:
            return None
        m = re.match(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\|([A-Z]+)\|(.*)$", raw)
        if m:
            ts, level, msg = m.group(1), m.group(2), m.group(3)
            hhmmss = ts[-8:]
            return {"ts": ts, "hhmmss": hhmmss, "level": level.upper(), "msg": msg, "display": f"[{hhmmss}] {msg}"}
        m = re.match(r"^\[(\d{2}:\d{2}:\d{2})\]\s*(.*)$", raw)
        if m:
            hhmmss, msg = m.group(1), m.group(2)
            return {"ts": f"0000-00-00 {hhmmss}", "hhmmss": hhmmss, "level": "INFO", "msg": msg, "display": f"[{hhmmss}] {msg}"}
        return {"ts": "", "hhmmss": "--:--:--", "level": "INFO", "msg": raw, "display": raw}

    def _log_event_id(self, item: dict) -> str:
        return f"{item.get('ts','')}|{item.get('level','')}|{item.get('msg','')}"

    def _send_log_telemetry_for_item(self, item: dict) -> None:
        event_id = self._log_event_id(item)
        if not event_id or event_id in getattr(self, "_telemetry_seen_log_ids", set()):
            return
        self._telemetry_seen_log_ids.add(event_id)
        lvl = str(item.get("level", "INFO") or "INFO").upper()
        msg = str(item.get("msg", "") or "")
        self._send_telemetry_async("log_event", {
            "level": lvl,
            "message": msg[:2000],
            "display": str(item.get("display", ""))[:2200],
            "silent": lvl not in {"ERROR", "WARN"},
        })

    def _has_error_after_signal_cli_ready(self) -> bool:
        seen_signal = False
        had_error = False
        for item in self._log_items:
            msg = str(item.get("msg", "") or "")
            if "Signal-cli на зв'язку" in msg:
                seen_signal = True
                had_error = False
                continue
            if seen_signal and str(item.get("level", "")).upper() == "ERROR":
                had_error = True
        return had_error

    def _log_item_is_current_startup(self, item: dict) -> bool:
        start = float(getattr(self, "_startup_started_at", 0.0) or 0.0)
        if not start:
            return True
        try:
            ts = datetime.strptime(str(item.get("ts", "") or ""), "%Y-%m-%d %H:%M:%S").timestamp()
            return ts >= start - 2
        except Exception:
            return False

    def _append_log(self, level: str, msg: str, also_file: bool = True):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lvl = str(level).upper()
        item = {"ts": ts, "hhmmss": ts[-8:], "level": lvl, "msg": str(msg), "display": f"[{ts[-8:]}] {msg}"}
        self._log_items.append(item)
        if "Signal-cli на зв'язку" in str(msg):
            self._startup_signal_cli_seen = True
            self._startup_error_after_signal_cli = False
        elif self._startup_signal_cli_seen and lvl == "ERROR":
            self._startup_error_after_signal_cli = True
        if also_file:
            try:
                EVENT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
                with EVENT_LOG_FILE.open("a", encoding="utf-8") as f:
                    f.write(f"{ts}|{lvl}|{msg}\n")
                self._log_file_offset = EVENT_LOG_FILE.stat().st_size
                self._last_log_mtime = EVENT_LOG_FILE.stat().st_mtime
            except Exception:
                pass
        low_msg = str(msg).lower()
        if lvl in {"READY", "ERROR"} or "отримав кори від" in low_msg or "сформовано текст цілі" in low_msg:
            self._scan_new_stats_from_log(initial=False)
            self._refresh_targets_from_logs(allow_launch=False)
        self._rebuild_log_cache()
        self.logTextChanged.emit()
        self.headerChanged.emit()
        self._send_log_telemetry_for_item(item)

    def _refresh_log_from_file(self):
        if not EVENT_LOG_FILE.exists():
            return
        try:
            stat = EVENT_LOG_FILE.stat()
            if stat.st_size < self._log_file_offset:
                self._log_file_offset = 0
            if stat.st_mtime <= self._last_log_mtime and stat.st_size == self._log_file_offset:
                return
            new_items = []
            with EVENT_LOG_FILE.open("rb") as f:
                f.seek(self._log_file_offset)
                for line in f:
                    item = self._parse_log_line(line.decode("utf-8", errors="ignore"))
                    if item:
                        new_items.append(item)
                self._log_file_offset = f.tell()
            self._last_log_mtime = stat.st_mtime
            if not new_items:
                return
            for item in new_items:
                self._log_items.append(item)
                msg = str(item.get("msg", "") or "")
                lvl = str(item.get("level", "") or "").upper()
                if self._log_item_is_current_startup(item):
                    if "Signal-cli на зв'язку" in msg:
                        self._startup_signal_cli_seen = True
                        self._startup_error_after_signal_cli = False
                    elif self._startup_signal_cli_seen and lvl == "ERROR":
                        self._startup_error_after_signal_cli = True
                self._send_log_telemetry_for_item(item)
            self._scan_new_stats_from_log(initial=False)
            self._refresh_targets_from_logs(allow_launch=True)
            self._rebuild_log_cache()
            self.logTextChanged.emit()
            self.headerChanged.emit()
        except Exception:
            pass

    def _load_target_meta(self):
        try:
            data = json.loads(TARGET_META_FILE.read_text(encoding="utf-8")) if TARGET_META_FILE.exists() else {}
            if isinstance(data, dict):
                return data
        except Exception:
            pass
        return {}

    def _write_target_meta(self, data: dict):
        try:
            TARGET_META_FILE.write_text(json.dumps(dict(data or {}), ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _extract_target_fields(self, msg: str):
        raw = str(msg or "").strip()
        if not raw:
            return None
        low = raw.lower()
        if "отримав кори від" not in low:
            return None
        source_match = re.search(r'отримав кори від\s+"([^"]+)"', raw, re.IGNORECASE)
        source = source_match.group(1).strip() if source_match else "—"
        mgrs_match = re.search(r'(\d{1,2}[A-Z]\s+[A-Z]{2}\s+\d{4,6}\s+\d{4,6})', raw, re.IGNORECASE)
        mgrs = mgrs_match.group(1).strip() if mgrs_match else "—"
        place = "—"
        for arrow in ("->", "=>", "→"):
            if arrow in raw:
                place = raw.split(arrow, 1)[1].strip()
                break
        return source, mgrs, place or "—"

    def _coord_event_signature(self, item) -> str | None:
        parsed = self._extract_target_fields(item.get("msg", ""))
        if not parsed:
            return None
        src, mgrs, place = parsed
        base = f"{src.lower()}|{mgrs.upper()}|{place.lower()}"
        if self._same_coords_allowed():
            return f"{base}|{item.get('ts','')}"
        return base

    def _target_signature(self, item) -> str | None:
        msg = str(item.get("msg", "") or "").strip()
        if "сформовано текст цілі:" not in msg.casefold():
            return None
        return f"{item.get('ts','')}|{msg}"

    def _error_signature(self, item) -> str | None:
        msg = str(item.get("msg", ""))
        low = msg.lower()
        if item.get("level") == "ERROR" or "обісра" in low or "пішов по пизді" in low:
            return f"{item.get('ts','')}|{msg}"
        return None
    def _bootstrap_stats_from_log(self):
        coord_sigs = set()
        target_sigs = set()
        error_sigs = set()
        for item in self._log_items:
            csig = self._coord_event_signature(item)
            if csig:
                coord_sigs.add(csig)
            tsig = self._target_signature(item)
            if tsig:
                target_sigs.add(tsig)
            esig = self._error_signature(item)
            if esig:
                error_sigs.add(esig)
        self._seen_coord_events = set(coord_sigs)
        self._seen_target_events = set(target_sigs)
        self._seen_error_events = set(error_sigs)
        self._new_target_events_pending_wizard = set()
        if not any(self._stats_map.values()):
            self._stats_map["targets"] = len(target_sigs)
            self._stats_map["errors"] = len(error_sigs)
            self._stats_map["screens"] = self._count_screenshot_files()
            save_json_file(STATS_FILE, self._stats_map)
        self.statsChanged.emit()
    def _scan_new_stats_from_log(self, initial=False):
        changed = False
        for item in self._log_items:
            csig = self._coord_event_signature(item)
            if csig and csig not in self._seen_coord_events:
                self._seen_coord_events.add(csig)
                self._new_target_events_pending_wizard.add(csig)
            tsig = self._target_signature(item)
            if tsig and tsig not in self._seen_target_events:
                self._seen_target_events.add(tsig)
                if not initial:
                    self._stats_map["targets"] = int(self._stats_map.get("targets", 0)) + 1
                    self._session_stats["targets"] = int(self._session_stats.get("targets", 0)) + 1
                    self._send_telemetry_async("target_processed", {"targets_total": int(self._stats_map.get("targets", 0)), "screenshots_total": int(self._stats_map.get("screens", 0))})
                    changed = True
            esig = self._error_signature(item)
            if esig and esig not in self._seen_error_events:
                self._seen_error_events.add(esig)
                if not initial:
                    self._stats_map["errors"] = int(self._stats_map.get("errors", 0)) + 1
                    self._session_stats["errors"] = int(self._session_stats.get("errors", 0)) + 1
                    changed = True
        if changed:
            save_json_file(STATS_FILE, self._stats_map)
            self.statsChanged.emit()
    def _refresh_targets_from_logs(self, allow_launch: bool = False):
        ready_items = []
        seen = set()
        for item in self._log_items:
            if str(item.get("level", "") or "").upper() != "READY":
                continue
            parsed = self._extract_target_fields(item.get("msg", ""))
            if not parsed:
                continue
            source, mgrs, place = parsed
            base_sig = f"{source.casefold()}|{mgrs.upper()}|{place.casefold()}"
            sig = f"{base_sig}|{item.get('ts','')}" if self._same_coords_allowed() else base_sig
            if sig in seen:
                continue
            seen.add(sig)
            ready_items.append({
                "source": source,
                "mgrs": mgrs,
                "place": place,
                "time": item.get("hhmmss", "--:--")[:5],
                "state": "Оброблено" if item.get("level") == "READY" else item.get("level", "INFO"),
                "signature": sig,
            })
        prev_last = dict(self._last_target)
        prev_prev = dict(self._prev_target)
        if ready_items:
            self._last_target = ready_items[-1]
            self._prev_target = ready_items[-2] if len(ready_items) > 1 else {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
        else:
            self._last_target = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
            self._prev_target = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
        if self._last_target != prev_last or self._prev_target != prev_prev:
            self.targetsChanged.emit()
            self.headerChanged.emit()
        sig = str(self._last_target.get("signature", "") or "")
        if allow_launch and sig and not self._suppress_target_wizard:
            pending = getattr(self, "_new_target_events_pending_wizard", set())
            launch_item = next((item for item in reversed(ready_items) if str(item.get("signature", "") or "") in pending), None)
            if not launch_item:
                return
            sig = str(launch_item.get("signature", "") or "")
            if str(self._config.get("receiver_capture_mode", "signal") or "signal").strip().casefold() != "signal":
                pending.discard(sig)
                return
            meta = self._load_target_meta()
            source = meta.get("source") if str(meta.get("signature") or "") == sig else ""
            mgrs = meta.get("mgrs") if str(meta.get("signature") or "") == sig else ""
            place = meta.get("place") if str(meta.get("signature") or "") == sig else ""
            self._target_wizard_context = {
                "source": source or launch_item.get("source", "—"),
                "mgrs": mgrs or launch_item.get("mgrs", "—"),
                "place": place or launch_item.get("place", "—"),
                "time": (meta.get("time") if str(meta.get("signature") or "") == sig else "") or launch_item.get("time", "—"),
                "state": launch_item.get("state", "Нема"),
                "signature": sig,
            }
            self.targetWizardChanged.emit()
            self._maybe_launch_target_prompt_from_context()
            pending.discard(sig)
    def _current_stats(self):
        return self._session_stats if self._config.get("stats_mode") == "за сеанс" else self._stats_map
    def _refresh_screenshot_stats(self):
        now = time.time()
        if now - float(getattr(self, "_last_screenshot_scan_at", 0.0) or 0.0) < 2.5:
            return
        self._last_screenshot_scan_at = now
        count = self._count_screenshot_files()
        session_count = max(0, count - self._session_screen_baseline)
        if count > self._last_screenshot_count:
            delta = count - self._last_screenshot_count
            self._stats_map["screens"] = int(self._stats_map.get("screens", 0)) + delta
            self._session_stats["screens"] = int(self._session_stats.get("screens", 0)) + delta
            if not self._screenshot_cycle_active:
                self._mark_cycle_started("скріну")
            save_json_file(STATS_FILE, self._stats_map)
            self._send_telemetry_async("screenshot_processed", {"screenshots_delta": int(delta), "screenshots_total": int(self._stats_map.get("screens", 0)), "targets_total": int(self._stats_map.get("targets", 0))})
            self.statsChanged.emit()
        elif self._session_stats.get("screens", 0) != session_count:
            self._session_stats["screens"] = session_count
            self.statsChanged.emit()
        self._last_screenshot_count = count
    def _tasklist_snapshot(self) -> str:
        if sys.platform != "win32":
            return ""
        try:
            return subprocess.check_output(["tasklist"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), text=True, encoding="cp866", errors="ignore").lower()
        except Exception:
            return ""

    def _tasklist_has(self, image_name: str, snapshot: str | None = None) -> bool:
        snap = snapshot if isinstance(snapshot, str) else self._tasklist_snapshot()
        return bool(image_name and image_name.lower() in snap)
    def _powershell_find_pids(self, image_name: str | None = None, command_contains: str | None = None):
        if sys.platform != "win32":
            return []
        filters = []
        if image_name:
            filters.append(f"($_.Name -like '{image_name}')")
        if command_contains:
            safe = command_contains.replace("'", "''")
            filters.append(f"($_.CommandLine -like '*{safe}*')")
        where = " -and ".join(filters) if filters else "$true"
        cmd = [
            str(Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"),
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-Command",
            f"$ErrorActionPreference='SilentlyContinue'; Get-CimInstance Win32_Process | Where-Object {{ {where} }} | Select-Object -ExpandProperty ProcessId"
        ]
        try:
            out = subprocess.check_output(cmd, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), text=True, encoding="utf-8", errors="ignore")
            return [int(x.strip()) for x in out.splitlines() if x.strip().isdigit()]
        except Exception:
            return []
    def _kill_pids(self, pids):
        for pid in pids or []:
            try:
                subprocess.run(["taskkill", "/PID", str(pid), "/F"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            except Exception:
                pass
    def _parse_signal_http(self):
        raw = str(self._config.get("signal_cli_http", "127.0.0.1:7583") or "127.0.0.1:7583").strip()
        if ":" not in raw:
            return "127.0.0.1", 7583
        host, port = raw.rsplit(":", 1)
        try:
            return host.strip() or "127.0.0.1", int(port)
        except Exception:
            return "127.0.0.1", 7583
    def _port_open(self, host: str, port: int) -> bool:
        try:
            with socket.create_connection((host, port), timeout=0.35):
                return True
        except Exception:
            return False
    def _signal_ok(self) -> bool:
        host, port = self._parse_signal_http()
        return self._port_open(host, port)
    def _signal_accounts(self):
        base_cmd = self._signal_cli_base_cmd()
        if not base_cmd:
            return []
        try:
            out = subprocess.check_output(base_cmd + ["listAccounts"], cwd=str(BASE_DIR), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), stderr=subprocess.STDOUT, timeout=12, text=True, encoding="utf-8", errors="ignore")
        except Exception:
            return []
        found = []
        for line in str(out or "").splitlines():
            line = line.strip()
            if not line:
                continue
            nums = re.findall(r"\+?\d{6,15}", line)
            for num in nums:
                num = num.strip()
                if num and num not in found:
                    found.append(num)
        return found
    def _listener_heartbeat_ok(self) -> bool:
        try:
            if not LISTENER_HEARTBEAT_FILE.exists():
                return False
            age = time.time() - LISTENER_HEARTBEAT_FILE.stat().st_mtime
            return age <= max(10, self._status_interval() / 1000.0 * 4)
        except Exception:
            return False
    def _python_ok(self, snapshot: str | None = None) -> bool:
        proc = self._spawned.get("python")
        if proc is not None and proc.poll() is None:
            return True
        return self._listener_heartbeat_ok()
    def _ahk_ok(self, snapshot: str | None = None) -> bool:
        proc = self._spawned.get("ahk")
        if proc is not None and proc.poll() is None:
            return True
        return self._tasklist_has("autohotkey64.exe", snapshot)
    def _sharex_ok(self, snapshot: str | None = None) -> bool:
        proc = self._spawned.get("sharex")
        if proc is not None and proc.poll() is None:
            return True
        return self._tasklist_has("sharex.exe", snapshot)
    def _signal_desktop_running(self, snapshot: str | None = None) -> bool:
        proc = self._spawned.get("signal_desktop")
        if proc is not None and proc.poll() is None:
            return True
        return self._tasklist_has("signal.exe", snapshot)
    def _signal_cmd(self):
        number = str(self._config.get("signal_number", "") or "").strip()
        base_cmd = self._signal_cli_base_cmd()
        if not number or not base_cmd:
            return None
        host_port = str(self._config.get("signal_cli_http", "127.0.0.1:7583") or "127.0.0.1:7583").strip()
        return base_cmd + ["-a", number, "daemon", "--http", host_port, "--receive-mode", "on-connection"]
    def _python_cmd(self):
        script = self._resolve_path(self._config.get("listener_script", "py\\delta_listener.py"))
        if not script.exists():
            return None
        py = self._resolve_python_executable()
        return [str(py), str(script)]
    def _ahk_cmd(self):
        exe = self._resolve_path(self._config.get("ahk_exe", "ahk\\AutoHotkey64.exe"))
        script = self._resolve_path(self._config.get("ahk_script", "ahk\\Pitusharnya.ahk"))
        if not exe.exists() or not script.exists():
            return None
        return [str(exe), str(script)]
    def _sharex_cmd(self):
        exe = self._resolve_path(self._config.get("sharex_exe", "sharex\\ShareX.exe"))
        return [str(exe)] if exe.exists() else None
    def _start_component(self, name: str, cmd):
        if not cmd:
            self._append_log("WARN", f"Старт {name} пропущено: нема команди або шлях ще кривий", also_file=False)
            return False
        try:
            final_cmd = list(cmd)
            kwargs = {"cwd": str(BASE_DIR), "creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
            if sys.platform == "win32" and str(final_cmd[0]).lower().endswith(('.bat', '.cmd')):
                final_cmd = ["cmd", "/c", "call"] + final_cmd
            proc = subprocess.Popen(final_cmd, **kwargs)
            self._spawned[name] = proc
            self._append_log("INFO", f"Старт {name}", also_file=False)
            return True
        except Exception as e:
            self._append_log("ERROR", f"Не вдалося стартанути {name}: {e}", also_file=False)
            return False
    def _restart_listener_if_running(self) -> None:
        try:
            proc = self._spawned.get("python")
            running = bool(proc and proc.poll() is None) or bool(self._status_map.get("python", False))
            if not running or self.firstRunNeeded:
                return
            self._stop_component("python")
            QTimer.singleShot(650, lambda: self._start_component("python", self._python_cmd()))
        except Exception:
            pass
    def _stop_component(self, name: str):
        pids = []
        image = None
        if name == "sharex":
            image = "ShareX.exe"
            pids = self._powershell_find_pids(image_name=image)
        elif name == "ahk":
            image = "AutoHotkey64.exe"
            pids = self._powershell_find_pids(image_name=image, command_contains="Pitusharnya.ahk")
        elif name == "python":
            image = "python.exe"
            pids = self._powershell_find_pids(command_contains="delta_listener.py") + self._powershell_find_pids(image_name="pythonw.exe", command_contains="delta_listener.py")
        elif name == "signal":
            pids = self._powershell_find_pids(command_contains="signal-cli") + self._powershell_find_pids(image_name="java.exe", command_contains="signal-cli") + self._powershell_find_pids(image_name="javaw.exe", command_contains="signal-cli") + self._powershell_find_pids(image_name="cmd.exe", command_contains="signal-cli")
        elif name == "signal_desktop":
            image = "Signal.exe"
            pids = self._powershell_find_pids(image_name=image)
        proc = self._spawned.get(name)
        if proc and proc.poll() is None:
            try:
                subprocess.run(["taskkill", "/PID", str(proc.pid), "/F", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                try:
                    proc.terminate()
                except Exception:
                    pass
        for pid in pids:
            try:
                subprocess.run(["taskkill", "/PID", str(pid), "/F", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
        if image:
            try:
                subprocess.run(["taskkill", "/IM", image, "/F", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
        self._kill_pids(pids)
        self._spawned[name] = None
        if name in {"sharex", "ahk", "python", "signal", "signal_desktop"}:
            self._append_log("WARN", f"Стоп {name}", also_file=False)
    def _build_system_status_reasons(self) -> str:
        reasons = []
        if not str(self._config.get("callsign", "")).strip() or str(self._config.get("callsign", "")).strip().lower() in {"екіпаж", "callsign", "crew"}:
            reasons.append("не заданий нормальний позивний")
        if not str(self._config.get("signal_number", "")).strip():
            reasons.append("акаунт Signal ще не підтягнувся після QR")
        if not self._resolve_path(self._config.get("signal_exe", "")).exists():
            reasons.append("не знайдено Signal Desktop")
        if not self._resolve_path(self._config.get("signal_cli_bat", "signal-cli-local.bat")).exists():
            reasons.append("не знайдено signal-cli")
        if not self._resolve_path(self._config.get("sharex_exe", r"sharex\ShareX.exe")).exists():
            reasons.append("не знайдено ShareX")
        if not self._resolve_path(self._config.get("ahk_exe", r"ahk\AutoHotkey64.exe")).exists():
            reasons.append("не знайдено AutoHotkey")
        if not self._resolve_path(self._config.get("ahk_script", r"ahk\Pitusharnya.ahk")).exists():
            reasons.append("не знайдено AHK-скрипт")
        if not self._resolve_path(self._config.get("listener_script", r"py\delta_listener.py")).exists():
            reasons.append("не знайдено listener")
        py = self._resolve_python_executable()
        if isinstance(py, Path) and not py.exists() and not str(py).lower().endswith("python"):
            reasons.append("не знайдено внутрішній Python")
        if not bool(self._config.get("signal_linked", False)):
            reasons.append("signal-cli ще не прив'язаний")
        if not bool(self._config.get("first_run_done", False)):
            reasons.append("перший запуск ще не завершений")
        if not self._status_map.get("signal", False):
            reasons.append("signal-cli daemon не відповідає")
        if not self._status_map.get("python", False):
            reasons.append("listener не живий")
        if not self._status_map.get("ahk", False):
            reasons.append("AHK не живий")
        if not self._status_map.get("sharex", False):
            reasons.append("ShareX не живий")
        return "\n".join([f"• {x}" for x in reasons]) if reasons else "Все працює. Якщо щось не подобається, дивись лог, а не ворожи на каві."

    def _rebuild_system_checks(self):
        signal_exe_ok = self._resolve_path(self._config.get("signal_exe", "")).exists()
        signal_cli_ok = self._resolve_path(self._config.get("signal_cli_bat", "signal-cli-local.bat")).exists()
        sharex_ok = self._resolve_path(self._config.get("sharex_exe", r"sharex\ShareX.exe")).exists()
        ahk_ok = self._resolve_path(self._config.get("ahk_exe", r"ahk\AutoHotkey64.exe")).exists() and self._resolve_path(self._config.get("ahk_script", r"ahk\Pitusharnya.ahk")).exists()
        listener_ok = self._resolve_path(self._config.get("listener_script", r"py\delta_listener.py")).exists()
        python_exe = self._resolve_python_executable()
        python_ok = (not isinstance(python_exe, Path)) or python_exe.exists()
        callsign_ok = bool(str(self._config.get("callsign", "")).strip()) and str(self._config.get("callsign", "")).strip().lower() not in {"екіпаж", "crew", "callsign"}
        number_ok = bool(str(self._config.get("signal_number", "")).strip())
        runtime_issues = []
        if not self._status_map.get("signal", False):
            runtime_issues.append("signal-cli daemon")
        if not self._status_map.get("python", False):
            runtime_issues.append("listener")
        if not self._status_map.get("ahk", False):
            runtime_issues.append("AHK")
        if not self._status_map.get("sharex", False):
            runtime_issues.append("ShareX")
        runtime_ok = len(runtime_issues) == 0
        checks = [
            {"name": "Позивний", "ok": callsign_ok, "details": "працює" if callsign_ok else "вкажи нормальний позивний"},
            {"name": "Акаунт Signal", "ok": number_ok, "details": "працює" if number_ok else "ще не підтягнувся після QR"},
            {"name": "Signal Desktop", "ok": signal_exe_ok, "details": "працює" if signal_exe_ok else "не знайдено клієнт Signal"},
            {"name": "signal-cli", "ok": signal_cli_ok and bool(self._config.get("signal_linked", False)), "details": "працює" if signal_cli_ok and bool(self._config.get("signal_linked", False)) else ("ще не прив'язаний" if signal_cli_ok else "не знайдено signal-cli")},
            {"name": "ShareX", "ok": sharex_ok, "details": "працює" if sharex_ok else "не знайдено ShareX"},
            {"name": "AHK", "ok": ahk_ok, "details": "працює" if ahk_ok else "нема AutoHotkey або скрипта"},
            {"name": "Listener", "ok": listener_ok and python_ok, "details": "працює" if listener_ok and python_ok else ("не знайдено listener" if not listener_ok else "не знайдено внутрішній Python")},
            {"name": "Стан модулів", "ok": runtime_ok, "details": "усі модулі живі" if runtime_ok else ("не ок: " + ", ".join([x.replace("signal-cli daemon", "daemon") for x in runtime_issues]))},
        ]
        self._system_checks = checks
        critical_ok = all(x["ok"] for x in checks[:7])
        modules_ok = runtime_ok
        any_modules = any(self._status_map.values())
        self._system_status_reasons = self._build_system_status_reasons()
        if critical_ok and modules_ok:
            self._system_status_text = "Система готова"
            self._system_status_level = "OK"
            self._system_status_ok = True
        elif critical_ok and any_modules:
            self._system_status_text = "Система частково готова"
            self._system_status_level = "WARN"
            self._system_status_ok = False
        else:
            self._system_status_text = "Система не готова"
            self._system_status_level = "ERROR"
            self._system_status_ok = False
        self.systemChecksChanged.emit()
        self.headerChanged.emit()

    def _refresh_status(self):
        snapshot = self._tasklist_snapshot()
        status = {
            "signal": self._signal_ok(),
            "python": self._python_ok(snapshot),
            "ahk": self._ahk_ok(snapshot),
            "sharex": self._sharex_ok(snapshot),
        }
        changed = status != self._status_map
        self._status_map = status
        self._status_list = [
            {"name": "SIGNAL", "ok": status["signal"]},
            {"name": "PYTHON", "ok": status["python"]},
            {"name": "AHK", "ok": status["ahk"]},
            {"name": "SHAREX", "ok": status["sharex"]},
        ]
        self._last_update_text = datetime.now().strftime("%H:%M:%S")
        prev_status = self._system_status_text
        self._rebuild_system_checks()
        if changed:
            self.statusChanged.emit()
        if self._system_status_text != prev_status:
            if self._system_status_text != "Система готова" and prev_status:
                self._system_ready_stable_count = 0
                self._system_ready_announced = False
                self._append_log("WARN", self._system_status_text, also_file=False)
        if self._system_status_text == "Система готова":
            self._system_ready_stable_count += 1
            if (
                not self._system_ready_announced
                and self._system_ready_stable_count >= 2
                and time.time() > float(getattr(self, "_modules_starting_until", 0.0) or 0.0)
                and time.time() - getattr(self, "_startup_time", time.time()) > 6
                and bool(getattr(self, "_startup_signal_cli_seen", False))
                and not bool(getattr(self, "_startup_error_after_signal_cli", False))
            ):
                self._system_ready_announced = True
                self._append_log("OK", "Системо повністю готова👌🏻 Якщо твій сигнал запущений, і є стрім- можеш починати подавати в чат цілі.", also_file=False)
                if bool(self._config.get("show_instruction_on_ready", True)) and not self._instruction_ready_shown:
                    self._instruction_ready_shown = True
                    self.instructionRequested.emit()
        else:
            self._system_ready_stable_count = 0
    def _refresh_all(self):
        self._refresh_log_from_file()
        self._refresh_screenshot_stats()
        self._refresh_status()
    def _send_telemetry(self, event_type: str, extra: dict | None = None) -> bool:
        try:
            if not bool(self._config.get("telemetry_enabled", False)):
                return False
            url = str(self._config.get("telemetry_server_url", TELEMETRY_SERVER_URL) or TELEMETRY_SERVER_URL).strip()
            token = str(self._config.get("telemetry_token", TELEMETRY_TOKEN) or TELEMETRY_TOKEN).strip()
            if not url or not token:
                return False
            payload = {
                "event": event_type,
                "install_id": self._ensure_install_id(),
                "signal_number": str(self._config.get("signal_number", "") or "").strip(),
                "signal_name": str(self._config.get("telemetry_signal_name", "") or self._config.get("callsign", "") or "").strip(),
                "callsign": str(self._config.get("callsign", "") or "").strip(),
                "app_version": str(self._config.get("app_version", DEFAULT_CONFIG["app_version"]) or DEFAULT_CONFIG["app_version"]),
                "telemetry_enabled": bool(self._config.get("telemetry_enabled", False)),
                "screenshots_total": int(self._stats_map.get("screens", 0)),
                "targets_total": int(self._stats_map.get("targets", 0)),
                "errors_total": int(self._stats_map.get("errors", 0)),
                "launches_total": int(self._stats_map.get("restarts", 0)),
                "last_error": next((x.get("msg", "") for x in reversed(self._log_items) if x.get("level") == "ERROR"), ""),
                "ts": datetime.now().isoformat(timespec="seconds"),
            }
            if isinstance(extra, dict):
                payload.update(extra)
            if payload.get("silent"):
                payload.pop("last_error", None)
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", "X-PITUSHNYA-TOKEN": token, "User-Agent": "PITUSHNYA-MCC-Telemetry/1.0"}, method="POST")
            with urllib.request.urlopen(req, timeout=4) as resp:
                resp.read()
            return True
        except Exception:
            return False
    def _send_telemetry_async(self, event_type: str, extra: dict | None = None):
        threading.Thread(target=self._send_telemetry, args=(event_type, extra), daemon=True).start()
    def _send_funnel_once(self, flag_key: str, event_type: str, extra: dict | None = None):
        flag_key = str(flag_key or "").strip()
        if not flag_key or bool(self._config.get(flag_key, False)):
            return
        self._config[flag_key] = True
        try:
            save_json_file(CONFIG_FILE, self._config)
        except Exception:
            pass
        payload = {"funnel": True}
        if isinstance(extra, dict):
            payload.update(extra)
        self._send_telemetry_async(event_type, payload)
    def _schedule_callsign_telemetry(self, callsign: str):
        self._callsign_telemetry_pending = str(callsign or "").strip()
        try:
            self._callsign_telemetry_timer.start(2500)
        except Exception:
            self._flush_callsign_telemetry()
    def _flush_callsign_telemetry(self):
        callsign = str(getattr(self, "_callsign_telemetry_pending", "") or "").strip()
        if not callsign:
            return
        if callsign == str(getattr(self, "_last_callsign_telemetry_sent", "") or ""):
            self._callsign_telemetry_pending = ""
            return
        self._last_callsign_telemetry_sent = callsign
        self._callsign_telemetry_pending = ""
        self._send_telemetry_async("callsign_changed", {"callsign": callsign, "signal_name": callsign})
        if callsign.lower() not in {"екіпаж", "crew", "callsign"}:
            self._send_funnel_once("telemetry_funnel_callsign_sent", "callsign_set", {"callsign": callsign, "signal_name": callsign})
    def _send_startup_telemetry(self):
        payload = {
            "screenshots_total": int(self._stats_map.get("screens", 0)),
            "targets_total": int(self._stats_map.get("targets", 0)),
        }
        self._send_telemetry_async("startup", dict(payload))
        self._send_telemetry_async("app_launched", {"funnel": True, **payload})
        self._send_funnel_once("telemetry_funnel_app_first_launch_sent", "app_first_launch", payload)
    def _telemetry_tick(self):
        payload = {
            "system_status": self._system_status_text,
            "status_map": dict(self._status_map),
            "last_target": dict(self._last_target),
            "silent": True,
            "suppress_user_log": True,
            "hidden": True,
            "user_visible": False,
            "log": False,
            "kind": "heartbeat",
        }
        self._last_telemetry_heartbeat_payload = payload
        self._send_telemetry_async("telemetry_heartbeat", payload)
    def _version_tuple(self, value: str):
        nums = re.findall(r"\d+", str(value or ""))
        return tuple(int(x) for x in nums[:4]) or (0,)
    def _updates_allowed(self) -> bool:
        try:
            return not bool(self.firstRunNeeded)
        except Exception:
            return False
    def _mark_updates_locked_until_first_run(self):
        self._config["last_update_check"] = f"{datetime.now().strftime('%H:%M:%S')} | доступно після QR-прив'язки і завершення першого запуску"
        self._config["update_available_version"] = ""
        self._config["update_download_url"] = ""
        self._config["update_notes"] = "Оновлення відкриються після прив'язки Signal і завершення першого запуску."
        save_json_file(CONFIG_FILE, self._config)
        self.configMapChanged.emit()
        self.updateStateChanged.emit()
    def _check_updates_worker(self):
        try:
            if not self._updates_allowed():
                self._mark_updates_locked_until_first_run()
                return
            url = str(self._config.get("update_manifest_url", "") or "").strip()
            if not url:
                self._config["last_update_check"] = f"{datetime.now().strftime('%H:%M:%S')} | manifest URL не задано"
                self._append_log("WARN", "Перевірка оновлень: manifest URL не задано", also_file=False)
                self._save_config(None)
                return
            req = urllib.request.Request(url, headers={"User-Agent": "PITUSHNYA-MCC-Updater/1.0"})
            with urllib.request.urlopen(req, timeout=12) as resp:
                raw_bytes = resp.read()
            raw_text = raw_bytes.decode("utf-8-sig", errors="ignore")
            payload = json.loads(raw_text)
            remote_version = str(payload.get("version", "") or "").strip()
            remote_channel = str(payload.get("channel", "stable") or "stable").strip()
            remote_url = str(payload.get("url", "") or payload.get("download_url", "") or "").strip()
            remote_notes = str(payload.get("notes", "") or payload.get("changelog", "") or "").strip()
            local_version = str(self._config.get("app_version", DEFAULT_CONFIG["app_version"]) or DEFAULT_CONFIG["app_version"]).strip()
            wanted_channel = str(self._config.get("update_channel", "stable") or "stable")

            if remote_channel != wanted_channel:
                self._config["last_update_check"] = f"{datetime.now().strftime('%H:%M:%S')} | канал не збігся ({remote_channel})"
                self._config["update_available_version"] = ""
                self._config["update_download_url"] = remote_url
                self._config["update_notes"] = ""
                if bool(getattr(self, "_update_check_manual", False)):
                    self.noUpdateAvailable.emit()
            elif self._version_tuple(remote_version) > self._version_tuple(local_version):
                self._config["last_update_check"] = f"{datetime.now().strftime('%H:%M:%S')} | знайдено {remote_version}"
                self._config["update_available_version"] = remote_version
                self._config["update_download_url"] = remote_url
                self._config["update_notes"] = remote_notes
            else:
                self._config["last_update_check"] = f"{datetime.now().strftime('%H:%M:%S')} | ти вже на актуальній {local_version}"
                self._config["update_available_version"] = ""
                self._config["update_download_url"] = remote_url
                self._config["update_notes"] = ""
                if bool(getattr(self, "_update_check_manual", False)):
                    self.noUpdateAvailable.emit()
            save_json_file(CONFIG_FILE, self._config)
        except Exception as e:
            self._config["last_update_check"] = f"{datetime.now().strftime('%H:%M:%S')} | помилка перевірки"
            save_json_file(CONFIG_FILE, self._config)
            self._append_log("ERROR", f"Оновлення обісрались: {type(e).__name__}: {e}", also_file=False)
        finally:
            self._update_busy = False
            self.configMapChanged.emit()
            self.updateStateChanged.emit()

    # Properties
    @Property(int, notify=themeIndexChanged)
    def themeIndex(self):
        return self._theme_index
    @Property(float, notify=uiScaleChanged)
    def uiScale(self):
        return self._ui_scale
    @Property(int, notify=fontSizeChanged)
    def baseFontSize(self):
        return self._font_size + 4
    @Property(int, notify=leftPanelWidthChanged)
    def leftPanelWidth(self):
        return self._left_panel_width
    @Property(str, notify=fontFamilyChanged)
    def fontFamily(self):
        return self._font_family
    @Property("QVariantList", constant=True)
    def themeNames(self):
        return THEME_NAMES
    @Property("QVariantList", constant=True)
    def fontNames(self):
        return FONT_NAMES
    @Property("QVariantList", constant=True)
    def accentNames(self):
        return ACCENT_NAMES
    @Property("QVariantList", constant=True)
    def receiverCaptureModes(self):
        return RECEIVER_CAPTURE_MODES
    @Property("QVariantList", constant=True)
    def coordInputOptions(self):
        return COORD_INPUT_OPTIONS
    @Property("QVariantList", constant=True)
    def coordOutputOptions(self):
        return COORD_OUTPUT_OPTIONS
    @Property("QVariantList", constant=True)
    def targetPromptModes(self):
        return TARGET_PROMPT_MODES
    @Property("QVariantList", constant=True)
    def compactModes(self):
        return COMPACT_MODES
    @Property("QVariantList", constant=True)
    def logPositions(self):
        return LOG_POSITIONS
    @Property("QVariantList", constant=True)
    def statsModes(self):
        return STATS_MODES
    @Property("QVariantList", constant=True)
    def receiverPersonalModes(self):
        return RECEIVER_PERSONAL_MODES
    @Property("QVariantList", constant=True)
    def receiverGroupModes(self):
        return RECEIVER_GROUP_MODES
    @Property("QVariantList", constant=True)
    def updateChannels(self):
        return UPDATE_CHANNELS
    @Property("QVariantList", constant=True)
    def logLevels(self):
        return LEVEL_ORDER
    @Property("QVariantMap", notify=configMapChanged)
    def configMap(self):
        return dict(self._config)
    @Property("QVariantList", notify=statusChanged)
    def statusList(self):
        return list(self._status_list)
    @Property("QVariantMap", notify=statusChanged)
    def statusMap(self):
        return dict(self._status_map)
    @Property("QVariantMap", notify=statsChanged)
    def statsMap(self):
        return dict(self._current_stats())
    @Property("QVariantMap", notify=targetsChanged)
    def lastTarget(self):
        return dict(self._last_target)
    @Property("QVariantMap", notify=targetsChanged)
    def prevTarget(self):
        return dict(self._prev_target)
    @Property("QVariantList", notify=systemChecksChanged)
    def systemChecks(self):
        return list(self._system_checks)
    @Property(str, notify=headerChanged)
    def lastUpdateText(self):
        return self._last_update_text
    @Property(str, notify=headerChanged)
    def prevTargetHeader(self):
        return format_prev_target_header(self._prev_target.get("time", "—"), self._prev_target.get("source", "—"), self._prev_target.get("mgrs", "—"), self._prev_target.get("place", "—"))
    @Property(str, notify=headerChanged)
    def systemStatusText(self):
        return self._system_status_text
    @Property(bool, notify=headerChanged)
    def systemStatusOk(self):
        return self._system_status_ok
    @Property(str, notify=headerChanged)
    def systemStatusLevel(self):
        return self._system_status_level
    @Property(str, notify=systemChecksChanged)
    def systemStatusReasonsText(self):
        return self._system_status_reasons
    @Property(str, notify=logTextChanged)
    def filteredLogText(self):
        return self._filtered_log_text_cache
    @Property(str, notify=logTextChanged)
    def filteredLogHtml(self):
        return self._filtered_log_html_cache
    @Property(str, constant=True)
    def roosterSource(self):
        return QUrl.fromLocalFile(str((RESOURCE_DIR / "assets" / "rooster.png").resolve())).toString()
    @Property(str, constant=True)
    def helloKittySource(self):
        return QUrl.fromLocalFile(str((RESOURCE_DIR / "assets" / "hello_kitty_bg.png").resolve())).toString()
    @Property(str, constant=True)
    def donateQrSource(self):
        return QUrl.fromLocalFile(str((RESOURCE_DIR / "assets" / "donate_qr.png").resolve())).toString()
    @Property(str, constant=True)
    def donateText(self):
        return DONATE_TEXT
    @Property(str, constant=True)
    def donateButtonText(self):
        return DONATE_BUTTON_TEXT
    @Property(str, constant=True)
    def donateCardNumber(self):
        return DONATE_CARD_NUMBER
    @Property(str, notify=configMapChanged)
    def titleText(self):
        return str(self._config.get("title") or "PITUSHNYA mcc")
    @Property(str, notify=configMapChanged)
    def versionText(self):
        return str(self._config.get("app_version") or DEFAULT_CONFIG["app_version"])
    @Property(str, notify=configMapChanged)
    def callsign(self):
        return str(self._config.get("callsign") or "ЕКІПАЖ")
    @Property(bool, notify=firstRunChanged)
    def firstRunNeeded(self):
        callsign = str(self._config.get("callsign", "") or "").strip().lower()
        callsign_ok = bool(callsign) and callsign not in {"екіпаж", "crew", "callsign"}
        return (not bool(self._config.get("first_run_done", False)) or not bool(self._config.get("signal_linked", False)) or not callsign_ok or not bool(str(self._config.get("signal_number", "")).strip()) or not self._resolve_path(self._config.get("signal_exe", "")).exists())
    @Property(bool, notify=firstRunChanged)
    def firstRunCallsignReady(self):
        callsign = str(self._config.get("callsign", "") or "").strip().lower()
        return bool(callsign) and callsign not in {"екіпаж", "crew", "callsign"}
    @Property(str, notify=firstRunChanged)
    def firstRunStatusText(self):
        signal_path = self._resolve_path(self._config.get("signal_exe", ""))
        callsign = str(self._config.get("callsign", "") or "").strip()
        callsign_ok = bool(callsign) and callsign.lower() not in {"екіпаж", "crew", "callsign"}
        number_ok = bool(str(self._config.get("signal_number", "")).strip())
        linked_ok = bool(self._config.get("signal_linked", False))
        first_ok = bool(self._config.get("first_run_done", False))
        lines = [
            ("✔" if signal_path.exists() else "✖") + " Signal Desktop " + ("знайдено" if signal_path.exists() else "ще не знайдено"),
            ("✔" if linked_ok else "✖") + " signal-cli " + ("уже прив'язаний" if linked_ok else "ще не прив'язаний"),
            ("✔" if number_ok else "✖") + " Акаунт Signal " + ("підтягнувся автоматично" if number_ok else "ще не підтягнувся після QR"),
            ("✔" if callsign_ok else "✖") + " Позивний " + ("нормальний" if callsign_ok else "ще не заданий"),
            ("✔" if first_ok else "•") + " Перший запуск " + ("завершений" if first_ok else "ще не завершений"),
        ]
        return "\n".join(lines)
    @Property(bool, notify=firstRunChanged)
    def firstRunCanComplete(self):
        callsign = str(self._config.get("callsign", "") or "").strip().lower()
        callsign_ok = bool(callsign) and callsign not in {"екіпаж", "crew", "callsign"}
        return bool(self._resolve_path(self._config.get("signal_exe", "")).exists()) and bool(self._config.get("signal_linked", False)) and bool(str(self._config.get("signal_number", "") or "").strip()) and callsign_ok

    @Property(str, constant=True)
    def instructionText(self):
        return READY_INSTRUCTION_TEXT
    @Property(bool, notify=updateStateChanged)
    def updateBusy(self):
        return self._update_busy
    @Property(bool, notify=firstRunChanged)
    def updateAllowed(self):
        return self._updates_allowed()
    @Property(str, constant=True)
    def infoOverviewText(self):
        return self._info_sections.get("overview") or INFO_OVERVIEW_TEXT
    @Property(str, constant=True)
    def infoWorkflowText(self):
        return self._info_sections.get("workflow") or READY_INSTRUCTION_TEXT
    @Property(str, constant=True)
    def infoSettingsText(self):
        return self._info_sections.get("settings") or INFO_SETTINGS_TEXT
    @Property(str, constant=True)
    def infoFeedbackText(self):
        return self._info_sections.get("feedback") or INFO_FEEDBACK_TEXT
    # Slots
    @Slot(int)
    def setThemeIndex(self, index: int):
        index = max(0, min(len(THEME_NAMES) - 1, int(index)))
        if index == self._theme_index:
            return
        self._theme_index = index
        self._config["theme"] = THEME_NAMES[index]
        self.themeIndexChanged.emit()
        self._rebuild_log_cache()
        self.logTextChanged.emit()
        self._log_user_action("set_theme", {"theme": THEME_NAMES[index]})
        self._schedule_config_save(rebuild=False)
    @Slot(float)
    def setUiScale(self, value: float):
        value = clamp_float(value, 0.7, 1.4, self._ui_scale)
        if abs(value - self._ui_scale) < 0.001:
            return
        self._ui_scale = value
        self.uiScaleChanged.emit()
        self._log_user_action("set_ui_scale", {"value": round(float(value), 3)})
        self._schedule_config_save(rebuild=False)
    @Slot(int)
    def setBaseFontSize(self, value: int):
        value = clamp_int(value, 12, 22, self._font_size + 4)
        raw = value - 4
        if raw == self._font_size:
            return
        self._font_size = raw
        self.fontSizeChanged.emit()
        self._log_user_action("set_base_font_size", {"value": int(value), "raw": int(raw)})
        self._schedule_config_save(rebuild=False)
    @Slot(int)
    def setLeftPanelWidth(self, value: int):
        value = clamp_int(value, 340, 700, self._left_panel_width)
        if value == self._left_panel_width:
            return
        self._left_panel_width = value
        self.leftPanelWidthChanged.emit()
        self._log_user_action("set_left_panel_width", {"value": int(value)})
        self._schedule_config_save(rebuild=False)
    @Slot(str)
    def setFontFamily(self, value: str):
        value = str(value or "").strip() or FONT_NAMES[0]
        if value == self._font_family:
            return
        self._font_family = value
        self.fontFamilyChanged.emit()
        self._log_user_action("set_font_family", {"value": value})
        self._schedule_config_save(rebuild=False)
    def _log_user_action(self, action: str, extra: dict | None = None):
        action = str(action or "ui_action").strip()
        payload = dict(extra or {})
        value_text = str(payload.get("value", "") or "").strip().lower()
        key_text = str(payload.get("key", "") or "").strip().lower()
        if action in {"settings_section", "settings section", "open_settings_section", "info_section", "info section"}:
            return
        if action == "ui_action" and value_text in {"settings_section", "info_section"}:
            return
        if action == "set_config" and key_text in {"callsign", "telemetry_signal_name"}:
            return
        self._send_telemetry_async("user_action", {"action": action, **payload})

    @Slot(str, str)
    def logUiAction(self, action: str, value: str = ""):
        self._log_user_action(str(action or "ui_action"), {"value": str(value or "")[:300]})

    def _config_needs_immediate_apply(self, key: str) -> bool:
        return str(key) in {
            "receiver_enabled",
            "receiver_accept_groups",
            "receiver_capture_mode",
            "receiver_personal_mode",
            "receiver_group_mode",
            "receiver_allowed_senders",
            "receiver_allowed_groups",
            "coord_output_system",
            "target_prompt_enabled",
            "target_prompt_mode",
            "target_prompt_font_size",
            "target_prompt_ui_scale",
            "target_prompt_follow_theme",
            "target_prompt_allow_same_coords",
            "screenshots_path",
            "callsign",
            "telemetry_signal_name",
            "stats_mode",
            "message_template_time_fix",
            "message_template_coords",
        }

    def _apply_config_change_now_if_needed(self, key: str) -> None:
        if not self._config_needs_immediate_apply(key):
            return
        try:
            self._config_save_timer.stop()
            self._save_config(None, rebuild=False)
            self._sync_sharex_runtime_files()
        except Exception:
            pass
        if str(key) in {
            "receiver_enabled",
            "receiver_accept_groups",
            "receiver_capture_mode",
            "receiver_personal_mode",
            "receiver_group_mode",
            "receiver_allowed_senders",
            "receiver_allowed_groups",
        }:
            self._restart_listener_if_running()
        self.configMapChanged.emit()

    @Slot(str, result="QVariant")
    def getConfig(self, key: str):
        return self._config.get(key)
    @Slot(str, result=str)
    def getConfigString(self, key: str):
        value = self._config.get(key, "")
        if isinstance(value, list):
            return "\n".join(str(x) for x in value)
        if isinstance(value, bool):
            return "true" if value else "false"
        return str(value if value is not None else "")
    @Slot(str, result=bool)
    def getConfigBool(self, key: str):
        return bool(self._config.get(key, False))
    @Slot(str, result=str)
    def getConfigListText(self, key: str):
        value = self._config.get(key, [])
        if isinstance(value, list):
            return "\n".join(str(x) for x in value)
        return str(value or "")
    @Slot(str, str)
    def setConfigValue(self, key: str, value: str):
        key = str(key or "").strip()
        if not key:
            return
        current = self._config.get(key)
        new_value = value
        if isinstance(current, bool):
            new_value = str(value).strip().lower() in {"1", "true", "yes", "так", "on"}
        elif isinstance(current, int) and key not in {"window_x", "window_y", "window_w", "window_h"}:
            new_value = clamp_int(value, -999999, 999999, current)
        elif isinstance(current, float):
            new_value = clamp_float(value, -999999.0, 999999.0, current)
        else:
            new_value = str(value)
        if key == "font_size":
            new_value = clamp_int(new_value, 8, 18, self._font_size)
            self._font_size = new_value
            self.fontSizeChanged.emit()
        elif key == "ui_scale":
            new_value = clamp_float(new_value, 0.7, 1.4, self._ui_scale)
            self._ui_scale = new_value
            self.uiScaleChanged.emit()
        elif key == "left_panel_width":
            new_value = clamp_int(new_value, 340, 700, self._left_panel_width)
            self._left_panel_width = new_value
            self.leftPanelWidthChanged.emit()
        elif key == "theme" and str(new_value) in THEME_NAMES:
            self._theme_index = THEME_NAMES.index(str(new_value))
            self.themeIndexChanged.emit()
            self._rebuild_log_cache()
            self.logTextChanged.emit()
            QTimer.singleShot(80, self._apply_windows_titlebar_theme)
        elif key == "font_family":
            self._font_family = str(new_value or FONT_NAMES[0])
            self.fontFamilyChanged.emit()
        elif key == "max_log_lines":
            new_value = clamp_int(new_value, 200, 20000, self._config.get("max_log_lines", 5000))
            old_items = list(self._log_items)[-new_value:]
            self._log_items = deque(old_items, maxlen=new_value)
            self._rebuild_log_cache()
            self.logTextChanged.emit()
        if key == "callsign":
            callsign = str(new_value or "").strip()
            self._config["telemetry_signal_name"] = callsign
            try:
                CALLSIGN_FILE.write_text(callsign, encoding="utf-8")
            except Exception:
                pass
            self._schedule_callsign_telemetry(callsign)
        self._config[key] = new_value
        if key == "stats_mode":
            if str(new_value) not in STATS_MODES:
                self._config[key] = STATS_MODES[0]
            self.statsChanged.emit()
        if key == "receiver_capture_mode":
            self._sync_clipboard_baseline()
            self._clipboard_mute_until = time.time() + 1.0
            self._place_helper_failed = False
            self._place_helper_error = ""
            self._clear_receiver_cycle_guards("receiver_capture_mode_changed")
            self._ensure_place_helper_warming()
        if key != "callsign":
            self._log_user_action("set_config", {"key": key, "value": str(new_value)[:120]})
        self._schedule_config_save(rebuild=key not in {"theme", "ui_scale", "font_size", "left_panel_width", "font_family"})
        self._apply_config_change_now_if_needed(key)
    @Slot(str, bool)
    def setConfigBool(self, key: str, value: bool):
        key = str(key)
        self._config[key] = bool(value)
        if key == "receiver_enabled":
            self._sync_clipboard_baseline()
            self._clipboard_mute_until = time.time() + 1.0
            self._clear_receiver_cycle_guards("receiver_enabled_changed")
            self._ensure_place_helper_warming()
        self._log_user_action("set_config_bool", {"key": key, "value": bool(value)})
        self._schedule_config_save(rebuild=key not in {"show_instruction_on_ready", "target_prompt_follow_theme"})
        self._apply_config_change_now_if_needed(key)
    @Slot(str, int)
    def setConfigInt(self, key: str, value: int):
        key = str(key)
        self._config[key] = int(value)
        self._log_user_action("set_config_int", {"key": key, "value": int(value)})
        self._schedule_config_save(rebuild=key not in {"target_prompt_font_size"})
        self._apply_config_change_now_if_needed(key)
    @Slot(str, float)
    def setConfigFloat(self, key: str, value: float):
        key = str(key)
        self._config[key] = float(value)
        self._log_user_action("set_config_float", {"key": key, "value": float(value)})
        self._schedule_config_save(rebuild=key not in {"target_prompt_ui_scale"})
        self._apply_config_change_now_if_needed(key)
    @Slot(str, str)
    def setConfigListFromText(self, key: str, text: str):
        items = [x.strip() for x in str(text or "").splitlines() if x.strip()]
        self._config[str(key)] = items
        self._log_user_action("set_config_list", {"key": str(key), "count": len(items)})
        self._schedule_config_save(rebuild=True)
        self._apply_config_change_now_if_needed(str(key))

    @Property("QVariantList", notify=configMapChanged)
    def targetTypeItems(self):
        return list(self._config.get("target_type_items", []) or [])

    def _set_target_type_items(self, items):
        self._config["target_type_items"] = [str(x).strip() for x in (items or []) if str(x).strip()]
        if not self._config["target_type_items"]:
            self._config["target_type_items"] = list(DEFAULT_CONFIG["target_type_items"])
        self.configMapChanged.emit()
        self._schedule_config_save(rebuild=True)
        try:
            self._config_save_timer.stop()
            self._save_config(None, rebuild=False)
        except Exception:
            pass

    @Slot(str)
    def addTargetType(self, value: str):
        val = str(value or "").strip()
        if not val:
            return
        items = list(self._config.get("target_type_items", []) or [])
        if val in items:
            return
        items.append(val)
        self._log_user_action("target_type_add", {"value": val})
        self._set_target_type_items(items)

    @Slot(int, str)
    def renameTargetType(self, index: int, value: str):
        items = list(self._config.get("target_type_items", []) or [])
        index = int(index)
        val = str(value or "").strip()
        if not (0 <= index < len(items)) or not val:
            return
        if val in items and items[index] != val:
            return
        old = items[index]
        items[index] = val
        self._log_user_action("target_type_rename", {"index": index, "old": old, "new": val})
        self._set_target_type_items(items)

    @Slot(int)
    def removeTargetType(self, index: int):
        items = list(self._config.get("target_type_items", []) or [])
        if 0 <= int(index) < len(items):
            removed = items.pop(int(index))
            self._log_user_action("target_type_remove", {"value": removed, "index": int(index)})
            self._set_target_type_items(items)

    @Slot(int, int)
    def moveTargetType(self, index: int, direction: int):
        items = list(self._config.get("target_type_items", []) or [])
        index = int(index)
        direction = int(direction)
        new_index = index + direction
        if 0 <= index < len(items) and 0 <= new_index < len(items):
            items[index], items[new_index] = items[new_index], items[index]
            self._log_user_action("target_type_move", {"from_index": index, "to_index": new_index})
            self._set_target_type_items(items)

    @Slot(int, int)
    def moveTargetTypeTo(self, from_index: int, to_index: int):
        items = list(self._config.get("target_type_items", []) or [])
        if not items:
            return
        src = max(0, min(len(items) - 1, int(from_index)))
        dst = max(0, min(len(items) - 1, int(to_index)))
        if src == dst:
            return
        item = items.pop(src)
        items.insert(dst, item)
        self._log_user_action("target_type_move_to", {"from_index": src, "to_index": dst})
        self._set_target_type_items(items)

    @Slot()
    def resetTargetTypes(self):
        self._log_user_action("target_type_reset")
        self._set_target_type_items(list(DEFAULT_CONFIG["target_type_items"]))

    @Slot()
    def sortTargetTypesAz(self):
        items = sorted(list(self._config.get("target_type_items", []) or []), key=lambda s: str(s).casefold())
        self._log_user_action("target_type_sort_az")
        self._set_target_type_items(items)
    @Slot(result=bool)
    def restoreDefaultMessageTemplates(self):
        self._log_user_action("settings_changed", {"section": "text_templates", "action": "restore_defaults"})
        try:
            self._config["message_template_time_fix"] = self._config.get("message_template_time_fix_default") or DEFAULT_TIME_TEMPLATE
            self._config["message_template_coords"] = self._config.get("message_template_coords_default") or DEFAULT_COORDS_TEMPLATE
            sync_template_files_from_config(self._config)
            self._schedule_config_save(rebuild=False)
            self.configMapChanged.emit()
            self._append_log("OK", "Відновлено дефолтні текстові шаблони повідомлень", also_file=False)
            return True
        except Exception as e:
            self._append_log("ERROR", f"Не зміг відновити дефолтні текстові шаблони: {e}", also_file=False)
            return False
    @Slot(str, result=bool)
    def copyTextToClipboard(self, text: str):
        value = str(text or "").strip()
        if not value:
            return False
        try:
            QGuiApplication.clipboard().setText(value)
            self._log_user_action("copy_text", {"value": value})
            return True
        except Exception as e:
            self._append_log("ERROR", f"Не зміг скопіювати текст у буфер: {e}", also_file=False)
            return False
    def saveAuxFiles(self):
        self._log_user_action("save_aux_files")
        ensure_dirs()
        try:
            CALLSIGN_FILE.write_text(str(self._config.get("callsign", "") or "").strip(), encoding="utf-8")
            sync_template_files_from_config(self._config)
            HOTKEYS_FILE.write_text(str(self._config.get("hotkeys_description", "") or ""), encoding="utf-8")
            save_json_file(RUNTIME_PROFILE_FILE, {
                "callsign": str(self._config.get("callsign", "") or ""),
                "signal_number": str(self._config.get("signal_number", "") or ""),
                "signal_http": str(self._config.get("signal_cli_http", "127.0.0.1:7583") or "127.0.0.1:7583"),
                "signal_exe": str(self._resolve_path(self._config.get("signal_exe", ""))),
                "receiver_enabled": bool(self._config.get("receiver_enabled", True)),
                "receiver_accept_groups": bool(self._config.get("receiver_accept_groups", False)),
                "receiver_personal_mode": self._config.get("receiver_personal_mode", "усі особисті"),
                "receiver_group_mode": self._config.get("receiver_group_mode", "тільки вибрані"),
                "receiver_allowed_senders": list(self._config.get("receiver_allowed_senders", [])),
                "receiver_allowed_groups": list(self._config.get("receiver_allowed_groups", [])),
                "receiver_capture_mode": self._config.get("receiver_capture_mode", "signal"),
                "receiver_ignore_own_account": bool(self._config.get("receiver_ignore_own_account", True)),
                "receiver_ignore_last_generated_message": bool(self._config.get("receiver_ignore_last_generated_message", True)),
                "coord_output_system": self._config.get("coord_output_system", "MGRS"),
                "message_template_time_fix": self._config.get("message_template_time_fix", ""),
                "message_template_coords": self._config.get("message_template_coords", ""),
                "hotkeys_description": self._config.get("hotkeys_description", ""),
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            })
            self._sync_sharex_runtime_files()
        except Exception as e:
            self._append_log("ERROR", f"Не зміг зберегти службові файли: {e}", also_file=False)
            return
    @Slot()
    def autoConfigurePaths(self):
        self._log_user_action("auto_configure_paths")
        self._auto_configure_paths(silent=False)
    @Slot()
    def openSignalDesktop(self):
        self._log_user_action("open_signal_desktop")
        exe = self._resolve_path(self._config.get("signal_exe", ""))
        if not exe.exists():
            self._append_log("ERROR", "Signal.exe не знайдено", also_file=False)
            return
        try:
            proc = subprocess.Popen([str(exe)], cwd=str(exe.parent), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            self._spawned["signal_desktop"] = proc
            self._append_log("INFO", "Signal Desktop відкрито", also_file=False)
        except Exception as e:
            self._append_log("ERROR", f"Не вдалося відкрити Signal Desktop: {e}", also_file=False)
        self._refresh_all()
    @Slot()
    def startSignalLink(self):
        self._log_user_action("start_signal_link")
        base_cmd = self._signal_cli_base_cmd()
        if not base_cmd:
            self._append_log("ERROR", "signal-cli.bat не знайдено", also_file=False)
            return
        device_name = f"PITUSHNYA-{(self._config.get('callsign') or 'user').strip() or 'user'}"
        try:
            existing = self._signal_accounts()
            self._link_accounts_before = set(existing)
            cmd = ["cmd", "/c", "call"] + base_cmd + ["link", "-n", device_name]
            creationflags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            self._link_proc = subprocess.Popen(cmd, cwd=str(BASE_DIR), creationflags=creationflags)
            self._link_poll_timer.start(1200)
            self._append_log("INFO", "Відкрив QR-прив'язку signal-cli", also_file=False)
        except Exception as e:
            self._append_log("ERROR", f"Не вдалося стартанути QR/link: {e}", also_file=False)
    @Slot(result=bool)
    def _poll_signal_link(self):
        try:
            if self._link_proc is not None and self._link_proc.poll() is None:
                return False
        except Exception:
            pass
        ok = self.verifySignalLink()
        if ok:
            self._link_poll_timer.stop()
        return ok
    def verifySignalLink(self):
        base_cmd = self._signal_cli_base_cmd()
        if not base_cmd:
            self._append_log("ERROR", "signal-cli.bat не знайдено", also_file=False)
            return False
        try:
            numbers = self._signal_accounts()
            if not numbers:
                self._append_log("WARN", "signal-cli акаунт поки не зловив", also_file=False)
                return False
            num = str(numbers[0]).strip()
            self._config["signal_number"] = num
            self._config["signal_linked"] = True
            self._config["telemetry_signal_name"] = str(self._config.get("callsign", "") or "").strip()
            self._save_config(None)
            self.saveAuxFiles()
            self._send_telemetry_async("linked", {"signal_number": num})
            self._send_funnel_once("telemetry_funnel_signal_link_sent", "signal_linked", {"signal_number": num})
            self._append_log("OK", f"signal-cli сам підтягнув акаунт {num}", also_file=False)
            try:
                if self._link_proc is not None and self._link_proc.poll() is None:
                    subprocess.run(["taskkill", "/PID", str(self._link_proc.pid), "/F", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
            self._link_proc = None
            self.configMapChanged.emit()
            self.firstRunChanged.emit()
            return True
        except Exception:
            self._append_log("WARN", "signal-cli акаунт поки не зловив", also_file=False)
            return False
    @Slot(result=bool)
    def completeFirstRun(self):
        self._log_user_action("complete_first_run")
        self._auto_configure_paths(silent=True)
        self.saveAuxFiles()
        self.verifySignalLink()
        callsign = str(self._config.get("callsign", "") or "").strip().lower()
        callsign_ok = bool(callsign) and callsign not in {"екіпаж", "crew", "callsign"}
        ready = bool(self._resolve_path(self._config.get("signal_exe", "")).exists()) and bool(self._config.get("signal_linked", False)) and bool(str(self._config.get("signal_number", "") or "").strip()) and callsign_ok
        if ready:
            self._config["first_run_done"] = True
            self._config["telemetry_signal_name"] = str(self._config.get("callsign", "") or "").strip()
            self._save_config(None)
            self.configMapChanged.emit()
            self.firstRunChanged.emit()
            self._send_funnel_once("telemetry_funnel_first_run_completed_sent", "first_run_completed", {"signal_number": str(self._config.get("signal_number", "") or "").strip()})
            self._append_log("OK", "Перший запуск завершено", also_file=False)
            if bool(self._config.get("auto_check_updates", False)):
                QTimer.singleShot(1500, self.checkForUpdates)
            return True
        self._append_log("WARN", "Перший запуск ще не можна завершити", also_file=False)
        return False
    @Slot()
    def startAll(self):
        self._log_user_action("start_all")
        self._modules_starting_until = time.time() + 8.0
        self._startup_started_at = time.time()
        self._startup_signal_cli_seen = False
        self._startup_error_after_signal_cli = False
        self._system_ready_stable_count = 0
        self._system_ready_announced = False
        self._instruction_ready_shown = False
        self._suppress_target_wizard = True
        self._reset_cycle_runtime_state("start_all")
        self._reset_runtime_session_files()
        self._sync_clipboard_baseline()
        self._clipboard_mute_until = time.time() + 3.0
        self._auto_configure_paths(silent=True)
        self.saveAuxFiles()
        if self.firstRunNeeded:
            self._append_log("WARN", "Старт заблоковано: спочатку добий перший запуск і прив'язку", also_file=False)
            self._refresh_all()
            return
        self._start_component("sharex", self._sharex_cmd())
        self._start_component("signal", self._signal_cmd())
        self._start_component("python", self._python_cmd())
        self._start_component("ahk", self._ahk_cmd())
        self._stats_map["restarts"] = int(self._stats_map.get("restarts", 0)) + 1
        self._session_stats["restarts"] = int(self._session_stats.get("restarts", 0)) + 1
        save_json_file(STATS_FILE, self._stats_map)
        self.statsChanged.emit()
        self._send_telemetry_async("startup_run", {"screenshots_total": int(self._stats_map.get("screens", 0)), "targets_total": int(self._stats_map.get("targets", 0))})
        self._refresh_all()
        QTimer.singleShot(1800, self._release_target_wizard_suppress)
    @Slot()
    def stopAll(self):
        self._log_user_action("stop_all")
        self._suppress_target_wizard = True
        try:
            self._config_save_timer.stop()
            self._save_config(None)
            self.saveAuxFiles()
        except Exception:
            pass
        for name in ["ahk", "python", "signal", "sharex"]:
            self._stop_component(name)
        try:
            if self._target_prompt_proc is not None and self._target_prompt_proc.poll() is None:
                self._target_prompt_proc.terminate()
        except Exception:
            pass
        try:
            if self._link_proc is not None and self._link_proc.poll() is None:
                self._link_proc.terminate()
        except Exception:
            pass
        try:
            self._kill_pids(self._powershell_find_pids(command_contains="target_prompt.py") + self._powershell_find_pids(image_name="target_prompt.exe"))
        except Exception:
            pass
        for image in ["target_prompt.exe"]:
            try:
                subprocess.run(["taskkill", "/IM", image, "/F", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
        self._link_proc = None
        self._screenshot_cycle_active = False
        self._refresh_all()
    @Slot()
    def restartAll(self):
        self._log_user_action("restart_all")
        try:
            self._config_save_timer.stop()
            self._save_config(None)
            self.saveAuxFiles()
        except Exception:
            pass
        self._append_log("WARN", "РЕСТАРТ", also_file=False)
        self.stopAll()
        QTimer.singleShot(700, self.startAll)
    @Slot()
    def clearLog(self):
        self._log_user_action("clear_log")
        self._log_items.clear()
        self._seen_coord_events.clear()
        self._seen_target_events.clear()
        self._seen_error_events.clear()
        self._new_target_events_pending_wizard.clear()
        try:
            EVENT_LOG_FILE.write_text("", encoding="utf-8")
        except Exception:
            pass
        self._last_log_mtime = EVENT_LOG_FILE.stat().st_mtime if EVENT_LOG_FILE.exists() else 0.0
        self._log_file_offset = EVENT_LOG_FILE.stat().st_size if EVENT_LOG_FILE.exists() else 0
        self._rebuild_log_cache()
        self.logTextChanged.emit()
        self._last_target = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
        self._prev_target = {"source": "—", "mgrs": "—", "place": "—", "time": "—", "state": "Нема", "signature": ""}
        self.targetsChanged.emit()
        self.headerChanged.emit()
        self._append_log("INFO", "Лог очищено", also_file=False)
    @Slot()
    def copyLog(self):
        self._log_user_action("copy_log")
        QGuiApplication.clipboard().setText(self.filteredLogText)
        self._append_log("INFO", "Лог скопійовано в буфер", also_file=False)
    @Slot(str)
    def setLogFilter(self, level: str):
        level = str(level or "Все разом").strip()
        aliases = {"ALL": "Все разом", "READY": "Цілі", "ERROR": "Помилки"}
        level = aliases.get(level.upper(), level)
        if level not in LEVEL_ORDER:
            level = "Все разом"
        if level == self._log_filter:
            return
        self._log_filter = level
        self._rebuild_log_cache()
        self.logTextChanged.emit()
    @Slot()
    def resetStats(self):
        self._log_user_action("reset_stats")
        self._stats_map = {k: 0 for k in self._stats_map.keys()}
        self._session_stats = {k: 0 for k in self._session_stats.keys()}
        self._session_screen_baseline = self._count_screenshot_files()
        self._last_screenshot_count = self._session_screen_baseline
        self._screenshot_cycle_active = False
        # Після скидання вважаємо поточний лог уже обробленим, щоб старі записи не набігали назад.
        self._seen_coord_events = {sig for sig in (self._coord_event_signature(x) for x in self._log_items) if sig}
        self._seen_target_events = {sig for sig in (self._target_signature(x) for x in self._log_items) if sig}
        self._seen_error_events = {sig for sig in (self._error_signature(x) for x in self._log_items) if sig}
        save_json_file(STATS_FILE, self._stats_map)
        self.statsChanged.emit()
        self._append_log("WARN", "Статистику скинуто", also_file=False)
    @Slot()
    def toggleReceiverEnabled(self):
        self._config["receiver_enabled"] = not bool(self._config.get("receiver_enabled", True))
        self._sync_clipboard_baseline()
        self._clipboard_mute_until = time.time() + 1.0
        self._clear_receiver_cycle_guards("receiver_enabled_toggled")
        self._ensure_place_helper_warming()
        self._log_user_action("toggle_receiver_enabled", {"value": bool(self._config.get("receiver_enabled", True))})
        self._save_config(None)
    @Slot()
    @Slot(bool)
    def checkForUpdates(self, manual: bool = True):
        self._update_check_manual = bool(manual)
        if manual:
            self._log_user_action("check_updates")
        if not self._updates_allowed():
            self._append_log("WARN", "Оновлення доступні тільки після QR-прив'язки і завершення першого запуску", also_file=False)
            self._mark_updates_locked_until_first_run()
            return
        if self._update_busy:
            return
        self._update_busy = True
        self.updateStateChanged.emit()
        threading.Thread(target=self._check_updates_worker, daemon=True).start()
    @Slot()
    def openUpdateDownloadUrl(self):
        self._log_user_action("open_update_download_url")
        if not self._updates_allowed():
            self._append_log("WARN", "Посилання оновлення відкриється після першого налаштування", also_file=False)
            self._mark_updates_locked_until_first_run()
            return
        url = str(self._config.get("update_download_url", "") or "").strip()
        if not url:
            url = str(self._config.get("update_manifest_url", "") or "").strip()
        if not url:
            self._append_log("WARN", "Нема чого відкривати для оновлення", also_file=False)
            return
        ok = QDesktopServices.openUrl(QUrl(url))
        if ok:
            self._append_log("INFO", f"Відкрив URL оновлення: {url}", also_file=False)
        else:
            self._append_log("ERROR", f"Не відкрився URL оновлення: {url}", also_file=False)
    @Slot()
    def runUpdater(self):
        self._log_user_action("run_updater")
        if not self._updates_allowed():
            self._append_log("WARN", "Updater заблоковано до QR-прив'язки і завершення першого запуску", also_file=False)
            self._mark_updates_locked_until_first_run()
            return
        candidates = [
            BASE_DIR / "updater" / "pitushnya_updater.exe",
            BASE_DIR / "pitushnya_updater.exe",
            BASE_DIR.parent / "updater" / "pitushnya_updater.exe",
            BASE_DIR.parent / "pitushnya_updater.exe",
            BASE_DIR.parent.parent / "pitushnya_updater.exe",
            BASE_DIR / "dist" / "pitushnya_updater.exe",
        ]
        updater = next((p for p in candidates if p.exists()), None)
        if not updater:
            self._append_log("WARN", "updater.exe не знайдено", also_file=False)
            return
        download_url = str(self._config.get("update_download_url", "") or "").strip()
        if not download_url:
            self._append_log("WARN", "Нема URL для запуску updater. Спершу перевір оновлення.", also_file=False)
            return
        app_exe = Path(sys.executable) if getattr(sys, "frozen", False) else ((BASE_DIR / "app" / "PITUSHNYA MCC.exe") if (BASE_DIR / "app" / "PITUSHNYA MCC.exe").exists() else (BASE_DIR / "PITUSHNYA MCC.exe"))
        install_dir = app_exe.parent if app_exe.exists() else BASE_DIR
        temp_dir = Path(tempfile.gettempdir()) / "pitushnya_update"
        temp_dir.mkdir(parents=True, exist_ok=True)
        runtime_updater = temp_dir / f"pitushnya_updater_runtime_{os.getpid()}_{int(time.time())}.exe"
        installer_path = temp_dir / "PITUSHNYA_MCC_update.exe"
        log_file = temp_dir / "pitushnya_updater_launcher.log"
        try:
            shutil.copy2(updater, runtime_updater)
        except Exception as e:
            self._append_log("ERROR", f"Не вдалося підготувати temp-копію updater: {e}", also_file=False)
            return
        args = [
            str(runtime_updater),
            "--app-pid", str(os.getpid()),
            "--download-url", download_url,
            "--installer-path", str(installer_path),
            "--install-dir", str(install_dir),
            "--app-exe", str(app_exe),
            "--log-file", str(log_file),
        ]
        try:
            subprocess.Popen(args, cwd=str(temp_dir), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            self._append_log("INFO", f"Updater запущено: {download_url}", also_file=False)
            QTimer.singleShot(350, self.stopAll)
            QTimer.singleShot(900, lambda: QCoreApplication.instance().quit())
        except Exception as e:
            self._append_log("ERROR", f"Не вдалося запустити updater: {e}", also_file=False)
    @Slot(result=str)
    def roosterClickMessage(self):
        self._log_user_action("rooster_click")
        return 'От тобі прям треба було клікнути по ньому¿ Ти вже все налаштував під себе, в усьому прям розібрався?? Читай вкладку "Інфо". Дрочиш того пітуха..)'
    @Slot(result=bool)
    def shutdownEverything(self):
        self.stopAll()
        return True

    @Property(bool)
    def forceQuitRequested(self):
        return bool(getattr(self, "_force_quit_requested", False))

    def set_main_window(self, window) -> None:
        self._main_window = window
        self._apply_windows_titlebar_theme()
        QTimer.singleShot(250, self._apply_windows_titlebar_theme)
        QTimer.singleShot(1200, self._apply_windows_titlebar_theme)
        self._ensure_tray_icon()

    def _apply_windows_titlebar_theme(self) -> None:
        if sys.platform != "win32" or self._main_window is None:
            return
        try:
            hwnd = int(self._main_window.winId())
            value = ctypes.c_int(1)
            for attr in (20, 19):
                try:
                    ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(value), ctypes.sizeof(value))
                    break
                except Exception:
                    pass
            border_color = ctypes.c_int(0x00111f2d)
            try:
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(border_color), ctypes.sizeof(border_color))
            except Exception:
                pass
        except Exception:
            pass

    def _ensure_tray_icon(self) -> None:
        if self._tray_icon is not None:
            return
        try:
            if not QSystemTrayIcon.isSystemTrayAvailable():
                return
            icon_path = RESOURCE_DIR / "icons" / "PITUSHNYA.ico"
            icon = QIcon(str(icon_path)) if icon_path.exists() else QIcon()
            tray = QSystemTrayIcon(icon, self)
            tray.setToolTip("PITUSHNYA MCC")
            menu = QMenu()
            show_action = QAction("Показати PITUSHNYA", menu)
            show_action.triggered.connect(self.showFromTray)
            quit_action = QAction("Закрити цю поїботу", menu)
            quit_action.triggered.connect(self.quitApplication)
            menu.addAction(show_action)
            menu.addSeparator()
            menu.addAction(quit_action)
            tray.setContextMenu(menu)
            tray.activated.connect(lambda reason: self.showFromTray() if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick) else None)
            tray.show()
            self._tray_icon = tray
            self._tray_menu = menu
        except Exception:
            self._tray_icon = None
            self._tray_menu = None

    @Slot()
    def minimizeToTray(self):
        self._log_user_action("minimize_to_tray")
        self._ensure_tray_icon()
        try:
            if self._main_window is not None:
                self._main_window.hide()
            if self._tray_icon is not None:
                self._tray_icon.showMessage("PITUSHNYA MCC", "Згорнув у фон. Працюю через гарячі клавіші.", QSystemTrayIcon.Information, 2400)
        except Exception:
            pass

    @Slot()
    def showFromTray(self):
        self._log_user_action("show_from_tray")
        try:
            if self._main_window is not None:
                self._main_window.show()
                raiser = getattr(self._main_window, "raise_", None)
                if callable(raiser):
                    raiser()
                self._main_window.requestActivate()
        except Exception:
            pass

    @Slot()
    def quitApplication(self):
        self._log_user_action("quit_application")
        self._force_quit_requested = True

        try:
            if self._main_window is not None:
                self._main_window.hide()
        except Exception:
            pass

        app = QApplication.instance()

        def finish_quit():
            try:
                self.stopAll()
            except Exception:
                pass

            try:
                self._save_config(None)
            except Exception:
                pass

            if app is not None:
                app.quit()

        QTimer.singleShot(120, finish_quit)

    def _target_prompt_cmd(self):
        helper_exe = BASE_DIR / "target_prompt.exe"
        if helper_exe.exists():
            return [str(helper_exe), str(TARGET_PROMPT_REQUEST_FILE), str(TARGET_PROMPT_RESULT_FILE)]
        helper = BASE_DIR / "target_prompt.py"
        if not helper.exists():
            return None
        if not getattr(sys, "frozen", False):
            pyexe = Path(sys.executable)
        else:
            internal_pythonw = BASE_DIR / "python" / "pythonw.exe"
            internal_python = BASE_DIR / "python" / "python.exe"
            if internal_pythonw.exists():
                pyexe = internal_pythonw
            elif internal_python.exists():
                pyexe = internal_python
            else:
                pyexe = Path(sys.executable)
        return [str(pyexe), str(helper), str(TARGET_PROMPT_REQUEST_FILE), str(TARGET_PROMPT_RESULT_FILE)]

    def _launch_target_prompt(self):
        try:
            if self._target_prompt_proc is not None:
                if self._target_prompt_proc.poll() is None:
                    self._append_log("WARN", "Майстер цілі ще відкритий, друге вікно не плоджу", also_file=False)
                    return False
                self._target_prompt_proc = None
        except Exception:
            self._target_prompt_proc = None
        ctx = dict(self._target_wizard_context or {})
        if not str(ctx.get("time", "") or "").strip() or str(ctx.get("time")) == "—":
            ctx["time"] = datetime.now().strftime("%H:%M")
        ctx["callsign"] = str(self._config.get("callsign", "") or "").strip()
        try:
            STATE_FILE.write_text(f"[delta]\nstatus=waiting_coords\ntime={ctx['time']}\n", encoding="utf-8")
        except Exception:
            pass
        if not bool(self._config.get("target_prompt_enabled", True)):
            return False
        payload = {
            "context": ctx,
            "items": list(self._config.get("target_type_items", []) or []),
            "callsign": str(self._config.get("callsign", "") or "").strip(),
            "mode": str(self._config.get("target_prompt_mode", "все в одному вікні") or "все в одному вікні"),
            "font_size": int(self._config.get("target_prompt_font_size", 14) or 14),
            "ui_scale": float(self._config.get("target_prompt_ui_scale", 0.70) or 0.70),
            "follow_theme": bool(self._config.get("target_prompt_follow_theme", True)),
            "theme_name": str(self._config.get("theme", THEME_NAMES[0]) or THEME_NAMES[0]),
            "theme": TARGET_PROMPT_THEME_PALETTES.get(str(self._config.get("theme", THEME_NAMES[0]) or THEME_NAMES[0]), TARGET_PROMPT_THEME_PALETTES[THEME_NAMES[0]]),
            "wallpaper": str((RESOURCE_DIR / "assets" / "hello_kitty_bg.png").resolve()),
        }
        try:
            TARGET_PROMPT_REQUEST_FILE.parent.mkdir(parents=True, exist_ok=True)
            TARGET_PROMPT_REQUEST_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            TARGET_PROMPT_RESULT_FILE.unlink(missing_ok=True)
        except Exception as e:
            self._append_log("ERROR", f"Не зміг підготувати вікно цілі: {e}", also_file=False)
            return False
        cmd = self._target_prompt_cmd()
        if not cmd:
            self._append_log("ERROR", "Не знайдено helper для вікна цілі", also_file=False)
            return False
        try:
            creationflags = 0
            if str(cmd[0]).lower().endswith("python.exe"):
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            self._target_prompt_proc = subprocess.Popen(cmd, cwd=str(BASE_DIR), creationflags=creationflags)
            self._append_log("INFO", "Відкрив майстер вибору цілі", also_file=False)
            return True
        except Exception as e:
            self._append_log("ERROR", f"Не вдалося відкрити вікно цілі: {e}", also_file=False)
            return False

    def _poll_target_prompt_result(self):
        if not TARGET_PROMPT_RESULT_FILE.exists():
            return

        try:
            data = load_json_file(TARGET_PROMPT_RESULT_FILE, {})
            TARGET_PROMPT_RESULT_FILE.unlink(missing_ok=True)
        except Exception:
            return

        if not isinstance(data, dict):
            return

        action = str(data.get("action", "") or "").strip().lower()

        if (
            data.get("cancelled") is True
            or data.get("canceled") is True
            or data.get("closed") is True
            or data.get("accepted") is False
            or data.get("ok") is False
            or action in {"cancel", "close", "dismiss", "closed"}
        ):
            try:
                self._finish_cycle("target_prompt_cancelled")
            except Exception:
                pass
            self._target_prompt_proc = None
            self.targetWizardChanged.emit()
            return

        all_items = data.get("all_items") or data.get("target_type_items") or []
        if isinstance(all_items, list) and all_items:
            self._config["target_type_items"] = [str(x).strip() for x in all_items if str(x).strip()]
            self._schedule_config_save(False)

        items = (
            data.get("items")
            or data.get("targets")
            or data.get("selected_items")
            or data.get("selected")
            or []
        )

        if isinstance(items, dict):
            items = [items]

        if isinstance(items, str):
            items = [{"type": items, "qty": 0}]

        direction = str(
            data.get("direction", "")
            or data.get("move_direction", "")
            or data.get("movement", "")
            or ""
        ).strip()

        ctx = dict(self._target_wizard_context or {})

        if not str(ctx.get("time", "") or "").strip() or str(ctx.get("time", "") or "") == "—":
            ctx["time"] = self._read_detect_time() or datetime.now().strftime("%H:%M")

        final_text = self._build_final_target_text(ctx, items, direction)
        if not final_text:
            final_text = str(data.get("final_text", "") or data.get("text", "") or "").strip()

        if not final_text:
            return

        try:
            self._finish_cycle("target_inserted")
        except Exception:
            self._screenshot_cycle_active = False

        try:
            READY_FILE.write_text(final_text, encoding="utf-8")
        except Exception:
            pass

        try:
            QGuiApplication.clipboard().setText(final_text)
            self._clipboard_mute_until = time.time() + 3.0
            self._clipboard_text_last = final_text
            self._clipboard_sequence_last = self._clipboard_sequence_number()
        except Exception:
            pass

        try:
            meta = load_json_file(TARGET_META_FILE, {})
            if not isinstance(meta, dict):
                meta = {}

            meta.update({
                "source": str(ctx.get("source", "") or ""),
                "mgrs": str(ctx.get("mgrs", "") or ""),
                "place": str(ctx.get("place", "") or ""),
                "time": str(ctx.get("time", "") or ""),
                "targets": self._format_target_items_for_template(items),
                "direction": self._direction_label(direction),
                "final_text": final_text,
                "finalized_at": datetime.now().isoformat(timespec="seconds"),
            })

            save_json_file(TARGET_META_FILE, meta)
        except Exception:
            pass

        self._append_log("READY", "Фінальний текст цілі сформовано після майстра", also_file=False)

        try:
            self._refresh_targets_from_logs()
        except Exception:
            pass

        try:
            self._refresh_status()
        except Exception:
            pass

        self._target_prompt_proc = None
        self.targetWizardChanged.emit()

    @Slot(str, result=str)
    def buildTargetMessage(self, payload_json: str):
        try:
            payload = json.loads(payload_json or "{}")
        except Exception:
            payload = {}

        items = payload.get("items", []) or []
        direction = str(payload.get("direction", "") or "").strip()
        ctx = dict(self._target_wizard_context or {})

        return self._build_final_target_text(ctx, items, direction)
    @Slot(str, result=bool)
    def insertTargetMessage(self, payload_json: str):
        text = self.buildTargetMessage(payload_json)
        if not text:
            self._append_log("WARN", "Не вдалося вставити ціль: нема обраних типів цілі", also_file=False)
            return False
        ctx = dict(self._target_wizard_context or {})
        hhmm = str(ctx.get("time", "") or self._last_target.get("time", "") or datetime.now().strftime("%H:%M")).strip() or datetime.now().strftime("%H:%M")
        try:
            READY_FILE.write_text(text, encoding="utf-8")
            STATE_FILE.write_text(f"[delta]\nstatus=waiting_coords\ntime={hhmm}\n", encoding="utf-8")
            self._screenshot_cycle_active = False
            QTimer.singleShot(2600, lambda: self._finish_cycle("target_inserted"))
            self._append_log("OK", f"Сформовано текст цілі: {text}", also_file=False)
            self._activate_signal_window()
            return True
        except Exception as e:
            self._append_log("ERROR", f"Не зміг закинути фінальний текст цілі: {e}", also_file=False)
            return False

    @Slot()
    def beginAppearancePreview(self):
        self._log_user_action("begin_appearance_preview")
        self.begin_preview_mode()

    @Slot()
    def endAppearancePreview(self):
        self._log_user_action("end_appearance_preview")
        self.end_preview_mode()

    @Slot()
    def saveNow(self):
        self._log_user_action("save_now")
        self._save_config("Налаштування збережено")
        self.saveAuxFiles()
    @Slot(str)
    def copyText(self, value: str):
        self._log_user_action("copy_text", {"length": len(str(value or ""))})
        QGuiApplication.clipboard().setText(str(value or ""))
    @Slot(str)
    def openUrl(self, url: str):
        raw = str(url or "").strip()
        self._log_user_action("open_url", {"url": raw[:300]})
        if raw:
            QDesktopServices.openUrl(QUrl(raw))
    @Slot(str)
    def openPath(self, key_or_path: str):
        raw = str(key_or_path or "").strip()
        self._log_user_action("open_path", {"path": raw[:300]})
        if not raw:
            return
        mapping = {
            "root": BASE_DIR,
            "screenshots": self._resolve_path(self._config.get("screenshots_path", "screenshots")),
            "log": EVENT_LOG_FILE,
            "sharex": self._resolve_path(self._config.get("sharex_exe", "sharex\\ShareX.exe")).parent,
            "signal_profile": self._signal_profile_dir(),
        }
        path = mapping.get(raw)
        if path is None:
            if raw in self._config:
                path = self._resolve_path(self._config.get(raw))
            else:
                path = self._resolve_path(raw)
        self._open_path(path)

    @Slot()
    def runForceUninstall(self):
        self._log_user_action("force_uninstall_requested")
        candidates = [
            BASE_DIR / "force_uninstall_pitushnya.cmd",
            RESOURCE_DIR / "force_uninstall_pitushnya.cmd",
            BASE_DIR.parent / "force_uninstall_pitushnya.cmd",
        ]
        script = next((p for p in candidates if p.exists()), None)

        if not script:
            self._append_log("ERROR", "Не знайшов force_uninstall_pitushnya.cmd поруч із встановленою PITUSHNYA MCC.", also_file=False)
            return

        try:
            if self._main_window is not None:
                self._main_window.hide()
        except Exception:
            pass

        try:
            self._append_log("WARN", "Запускаю примусове видалення PITUSHNYA MCC", also_file=False)

            if sys.platform == "win32":
                subprocess.Popen(
                    ["cmd.exe", "/c", "start", "", "/min", str(script)],
                    cwd=str(script.parent),
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
            else:
                subprocess.Popen([str(script)], cwd=str(script.parent))

            app = QApplication.instance()
            if app is not None:
                QTimer.singleShot(350, app.quit)
        except Exception as e:
            self._append_log("ERROR", f"Не зміг запустити force_uninstall_pitushnya.cmd: {e}", also_file=False)
def main() -> int:
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    icon_path = RESOURCE_DIR / "icons" / "PITUSHNYA.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))
    engine = QQmlApplicationEngine()
    backend = Backend()
    app.aboutToQuit.connect(backend.shutdownEverything)
    engine.rootContext().setContextProperty("backend", backend)
    qml_file = RESOURCE_DIR / "qml" / "Main.qml"
    engine.addImportPath(str(RESOURCE_DIR / "qml"))
    engine.load(QUrl.fromLocalFile(str(qml_file)))
    if not engine.rootObjects():
        print("QML не завантажився")
        return -1

    backend.set_main_window(engine.rootObjects()[0])
    root = engine.rootObjects()[0]

    if bool(backend.configMap.get("start_maximized_after_install", True)) and not bool(backend.configMap.get("first_run_done", False)):
        try:
            root.showMaximized()
        except Exception:
            pass

    if bool(backend.configMap.get("minimize_to_tray_on_launch", False)):
        QTimer.singleShot(900, backend.minimizeToTray)

    return app.exec()
if __name__ == "__main__":
    raise SystemExit(main())
