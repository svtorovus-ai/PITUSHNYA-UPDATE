@echo off
setlocal EnableExtensions

title PITUSHNYA MCC uninstall

set "APPDIR=%LOCALAPPDATA%\Programs\PITUSHNYA MCC"
set "DESKTOP_SHORTCUT=%USERPROFILE%\Desktop\PITUSHNYA MCC.lnk"
set "STARTMENU_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\PITUSHNYA MCC"

echo.
echo Закриваю PITUSHNYA MCC...

taskkill /f /im "PITUSHNYA MCC.exe" /t >nul 2>nul
taskkill /f /im "target_prompt.exe" /t >nul 2>nul
taskkill /f /im "pitushnya_updater.exe" /t >nul 2>nul
taskkill /f /im "AutoHotkey64.exe" /t >nul 2>nul
taskkill /f /im "python.exe" /t >nul 2>nul
taskkill /f /im "pythonw.exe" /t >nul 2>nul

timeout /t 1 /nobreak >nul

echo Видаляю ярлики...

if exist "%DESKTOP_SHORTCUT%" del /f /q "%DESKTOP_SHORTCUT%" >nul 2>nul
if exist "%STARTMENU_DIR%" rmdir /s /q "%STARTMENU_DIR%" >nul 2>nul

echo Видаляю папку додатку...

if exist "%APPDIR%" (
    attrib -r -s -h "%APPDIR%\*" /s /d >nul 2>nul
    rmdir /s /q "%APPDIR%" >nul 2>nul
)

if exist "%APPDIR%" (
    echo.
    echo Не зміг повністю видалити папку:
    echo %APPDIR%
    echo.
    echo Можливо якийсь процес ще тримає файли.
    echo Перезапусти Windows і повтори видалення.
    timeout /t 6 /nobreak >nul
    exit
)

echo.
echo PITUSHNYA MCC видалено.
timeout /t 1 /nobreak >nul
exit