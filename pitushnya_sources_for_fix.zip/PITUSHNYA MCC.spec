# -*- mode: python ; coding: utf-8 -*-

from PyInstaller.utils.hooks import collect_all

pyside_datas, pyside_binaries, pyside_hiddenimports = collect_all('PySide6')
shiboken_datas, shiboken_binaries, shiboken_hiddenimports = collect_all('shiboken6')
requests_datas, requests_binaries, requests_hiddenimports = collect_all('requests')
mgrs_datas, mgrs_binaries, mgrs_hiddenimports = collect_all('mgrs')
shapefile_datas, shapefile_binaries, shapefile_hiddenimports = collect_all('shapefile')
shapely_datas, shapely_binaries, shapely_hiddenimports = collect_all('shapely')
try:
    ess_datas, ess_binaries, ess_hiddenimports = collect_all('PySide6_Essentials')
except Exception:
    ess_datas, ess_binaries, ess_hiddenimports = [], [], []
try:
    add_datas, add_binaries, add_hiddenimports = collect_all('PySide6_Addons')
except Exception:
    add_datas, add_binaries, add_hiddenimports = [], [], []

datas = []
datas += pyside_datas + shiboken_datas + requests_datas + mgrs_datas + shapefile_datas + shapely_datas + ess_datas + add_datas
datas += [
    ('qml', 'qml'),
    ('assets', 'assets'),
    ('icons', 'icons'),
]

binaries = []
binaries += pyside_binaries + shiboken_binaries + requests_binaries + mgrs_binaries + shapefile_binaries + shapely_binaries + ess_binaries + add_binaries

hiddenimports = []
hiddenimports += pyside_hiddenimports + shiboken_hiddenimports + requests_hiddenimports + mgrs_hiddenimports + shapefile_hiddenimports + shapely_hiddenimports + ess_hiddenimports + add_hiddenimports

# Прибираємо дублікати, бо PyInstaller любить розводити цирк.
datas = list(dict.fromkeys(datas))
binaries = list(dict.fromkeys(binaries))
hiddenimports = list(dict.fromkeys(hiddenimports))

a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='PITUSHNYA MCC',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    icon=['icons\\PITUSHNYA.ico'],
    version='version_info.txt',
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='PITUSHNYA MCC',
)
