import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root
    property var themeObj
    property string title: ""
    property real uiScale: 1.0
    property int radiusValue: 10
    property int titleFontSize: 16
    property string fontFamilyName: "Segoe UI"
    default property alias contentData: body.data

    radius: Math.round(radiusValue * uiScale)
    color: themeObj && themeObj.name === "Hello Kitty" ? Qt.rgba(1.0, 0.84, 0.92, 0.72) : themeObj.panelAlt
    border.color: themeObj.cardBorder
    border.width: 1
    implicitHeight: layout.implicitHeight + Math.round(22 * uiScale)

    ColumnLayout {
        id: layout
        anchors.fill: parent
        anchors.margins: Math.round(12 * root.uiScale)
        spacing: Math.round(8 * root.uiScale)

        Text {
            visible: root.title.length > 0
            text: root.title
            color: root.themeObj.text
            font.family: root.fontFamilyName
            font.pixelSize: Math.max(12, Math.round(root.titleFontSize * root.uiScale))
            font.bold: true
        }

        ColumnLayout {
            id: body
            Layout.fillWidth: true
            spacing: Math.round(8 * root.uiScale)
        }
    }
}
