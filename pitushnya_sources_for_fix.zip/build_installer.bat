@echo off
setlocal
cd /d "%~dp0"
py -3 build_installer.py
if errorlevel 1 pause
