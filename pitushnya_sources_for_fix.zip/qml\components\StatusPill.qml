import QtQuick

Rectangle {
    id: root
    property string label: ""
    property string hint: ""
    property bool ok: true
    property var themeObj
    property real uiScale: 1.0
    property string fontFamilyName: "Segoe UI"

    implicitWidth: textItem.implicitWidth + Math.round(22 * uiScale)
    implicitHeight: Math.round(28 * uiScale)
    radius: Math.round(8 * uiScale)
    color: ok ? Qt.rgba(0.15, 0.85, 0.42, 0.12) : Qt.rgba(1, 0.2, 0.25, 0.12)
    border.color: ok ? themeObj.accent : themeObj.danger
    border.width: 1

    HoverHandler { id: hover }
    HintToolTip {
        visible: root.hint.length > 0 && hover.hovered
        text: root.hint
        themeObj: root.themeObj
        uiScale: root.uiScale
        fontFamilyName: root.fontFamilyName
    }

    Text {
        id: textItem
        anchors.centerIn: parent
        text: root.label
        color: root.ok ? root.themeObj.accent : root.themeObj.danger
        font.family: root.fontFamilyName
        font.pixelSize: Math.max(11, Math.round(13 * root.uiScale))
        font.bold: true
    }
}
