import QtQuick
import QtQuick.Controls

ToolTip {
    id: tip
    property var themeObj
    property real uiScale: 1.0
    property string fontFamilyName: "Segoe UI"
    readonly property bool helloKitty: themeObj && themeObj.name === "Hello Kitty"
    readonly property bool lightTheme: themeObj && (themeObj.name === "Hello Kitty" || themeObj.name === "Молочний графіт")
    readonly property int maxTextWidth: Math.round(360 * uiScale)

    delay: 1700
    timeout: 12000
    margins: Math.round(12 * uiScale)
    padding: Math.round(11 * uiScale)

    contentItem: Text {
        text: tip.text
        color: tip.themeObj ? tip.themeObj.text : "#f1f7ff"
        font.family: tip.fontFamilyName
        font.pixelSize: Math.max(11, Math.round(13 * tip.uiScale))
        font.bold: true
        wrapMode: Text.Wrap
        width: Math.min(implicitWidth, tip.maxTextWidth)
    }

    background: Item {
        implicitWidth: bg.implicitWidth
        implicitHeight: bg.implicitHeight + shadow.y

        Rectangle {
            id: shadow
            anchors.fill: bg
            anchors.leftMargin: Math.round(2 * tip.uiScale)
            anchors.topMargin: Math.round(4 * tip.uiScale)
            radius: bg.radius + Math.round(1 * tip.uiScale)
            color: "#000000"
            opacity: tip.lightTheme ? 0.12 : 0.20
        }

        Rectangle {
            id: bg
            anchors.fill: parent
            anchors.bottomMargin: Math.round(4 * tip.uiScale)
            radius: Math.round(10 * tip.uiScale)
            color: tip.helloKitty
                   ? Qt.rgba(1.0, 0.96, 0.98, 0.98)
                   : (tip.lightTheme
                      ? Qt.rgba(0.97, 0.98, 1.0, 0.98)
                      : (tip.themeObj ? Qt.darker(tip.themeObj.panel, 1.12) : "#0c1420"))
            border.color: tip.themeObj ? tip.themeObj.accent2 : "#3f9cff"
            border.width: 1
            opacity: 0.99
        }
    }
}
