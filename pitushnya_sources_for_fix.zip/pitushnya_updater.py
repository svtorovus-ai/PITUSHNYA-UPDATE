import argparse
import os
import sys
import time
import subprocess
import urllib.request
import urllib.parse
import http.cookiejar
import re
import threading
import shutil
import queue
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox


def log_write(log_file: Path, text: str):
    try:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {text}\n")
    except Exception:
        pass


def build_google_drive_confirm_url(html: str, base_url: str) -> str | None:
    patterns = [
        r'href="([^"]*confirm=[^"]+export=download[^"]*)"',
        r'href="([^"]*export=download[^"]*confirm=[^"]+)"',
        r'action="([^"]*/uc)"[^>]*',
    ]
    for pat in patterns:
        m = re.search(pat, html, re.I)
        if m:
            href = m.group(1)
            href = href.replace('&amp;', '&')
            if '/uc' in href and 'confirm=' in href:
                return urllib.parse.urljoin(base_url, href)
    m_id = re.search(r'[?&]id=([A-Za-z0-9_-]+)', base_url)
    m_token = re.search(r'confirm=([0-9A-Za-z_]+)', html)
    if m_id and m_token:
        return f'https://drive.google.com/uc?export=download&confirm={m_token.group(1)}&id={m_id.group(1)}'
    return None


def cleanup_temp_update_dir(temp_dir: Path, current_installer: Path, log_file: Path):
    try:
        temp_dir.mkdir(parents=True, exist_ok=True)
        patterns = [
            "PITUSHNYA_MCC_*.exe",
            "pitushnya_updater_launcher.log",
            "inno_setup.log",
            "pitushnya_updater.ps1",
            "pitushnya_updater_launcher.bat",
            "run_update.cmd",
        ]
        current_name = current_installer.name.lower()
        for pattern in patterns:
            for item in temp_dir.glob(pattern):
                try:
                    if item.name.lower() == current_name:
                        continue
                    if item.resolve() == log_file.resolve():
                        continue
                except Exception:
                    pass
                try:
                    if item.is_file():
                        item.unlink()
                except Exception as e:
                    log_write(log_file, f'cleanup temp failed for {item}: {e}')
    except Exception as e:
        log_write(log_file, f'cleanup temp dir exception: {e}')


def download_with_google_drive_support(url: str, installer_path: Path, progress_cb):
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    headers = {'User-Agent': 'PITUSHNYA-MCC-Updater/1.0'}

    def fetch(target_url: str, attempt: int = 1):
        req = urllib.request.Request(target_url, headers=headers)
        with opener.open(req, timeout=60) as resp:
            ctype = (resp.headers.get('Content-Type') or '').lower()
            total = int(resp.headers.get('Content-Length') or 0)
            data = resp.read()
            if (b'<html' in data[:4096].lower() or 'text/html' in ctype) and 'drive.google.com' in target_url and attempt < 4:
                html = data.decode('utf-8', errors='ignore')
                confirm_url = build_google_drive_confirm_url(html, target_url)
                if confirm_url:
                    progress_cb('Google Drive крутить дупою, тягну confirm-лінк...', None,
                                'Drive замість файла підсовує HTML-сміття. Обходжу це ще однією спробою.')
                    return fetch(confirm_url, attempt + 1)
            return data, total, ctype

    data, total, ctype = fetch(url)
    installer_path.parent.mkdir(parents=True, exist_ok=True)
    with open(installer_path, 'wb') as f:
        if total > 0 and len(data) == total:
            step = max(1, total // 20)
            written = 0
            for i in range(0, len(data), step):
                chunk = data[i:i + step]
                f.write(chunk)
                written += len(chunk)
                pct = 8 + int((written / total) * 72)
                progress_cb(f'Завантажую оновлення... {int((written / total) * 100)}%', min(pct, 80), None)
        else:
            f.write(data)
    return ctype


class UpdaterUI:
    def __init__(self, title: str, log_file: Path):
        self.title = title
        self.log_file = log_file
        self.q: queue.Queue[tuple] = queue.Queue()
        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry('760x400')
        self.root.resizable(False, False)
        self.root.configure(bg='#050607')
        self.root.attributes('-topmost', True)
        self.root.protocol('WM_DELETE_WINDOW', lambda: None)

        style = ttk.Style()
        try:
            style.theme_use('clam')
        except Exception:
            pass
        style.configure('Upd.Horizontal.TProgressbar', troughcolor='#141b23', background='#22c55e', bordercolor='#263040', lightcolor='#22c55e', darkcolor='#22c55e')

        main = tk.Frame(self.root, bg='#050607')
        main.pack(fill='both', expand=True, padx=16, pady=16)

        tk.Label(main, text=title, bg='#050607', fg='#e7edf5', font=('Segoe UI', 15, 'bold')).pack(anchor='w')
        self.status_var = tk.StringVar(value='Підготовка...')
        self.detail_var = tk.StringVar(value='Зараз ця поїбота спробує оновитись без ритуального самогубства.')
        tk.Label(main, textvariable=self.status_var, bg='#050607', fg='#98a2b3', font=('Segoe UI', 10), wraplength=700, justify='left').pack(anchor='w', pady=(12, 6))
        self.bar = ttk.Progressbar(main, orient='horizontal', mode='determinate', length=700, maximum=100, style='Upd.Horizontal.TProgressbar')
        self.bar.pack(anchor='w', fill='x')
        self.percent_var = tk.StringVar(value='0%')
        tk.Label(main, textvariable=self.percent_var, bg='#050607', fg='#e7edf5', font=('Segoe UI', 10, 'bold')).pack(anchor='e', pady=(4, 0))
        tk.Label(main, textvariable=self.detail_var, bg='#050607', fg='#98a2b3', font=('Segoe UI', 9), wraplength=700, justify='left').pack(anchor='w', pady=(8, 10))
        self.text = tk.Text(main, height=12, wrap='word', bg='#0d1117', fg='#e6edf3', insertbackground='#e6edf3', relief='flat')
        self.text.pack(fill='both', expand=True)

    def post(self, kind, *payload):
        self.q.put((kind, payload))

    def ui(self, msg, pct=None, detail=None):
        self.status_var.set(msg)
        if pct is not None:
            pct = max(0, min(100, int(pct)))
            self.bar.configure(mode='determinate')
            self.bar['value'] = pct
            self.percent_var.set(f'{pct}%')
        if detail is not None:
            self.detail_var.set(detail)
        self.text.insert('end', msg + '\n')
        self.text.see('end')
        log_write(self.log_file, msg + (f" | {detail}" if detail else ''))

    def process_queue(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == 'ui':
                    self.ui(*payload)
                elif kind == 'error':
                    messagebox.showerror(self.title, payload[0])
                    self.root.destroy()
                    return
                elif kind == 'done':
                    self.root.destroy()
                    return
        except queue.Empty:
            pass
        self.root.after(80, self.process_queue)

    def run(self):
        try:
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass
        self.root.after(80, self.process_queue)
        self.root.mainloop()


def wait_process_exit(pid: int, timeout_sec: float, progress_cb):
    start = time.time()
    while time.time() - start < timeout_sec:
        try:
            os.kill(pid, 0)
            time.sleep(0.35)
        except OSError:
            return True
    progress_cb('Стара версія ще висить, пробую добити процес...', 5,
                'Windows знов вдає, що все вже закрилось, хоча тримає файли зубами.')
    try:
        subprocess.run(['taskkill', '/PID', str(pid), '/F'], capture_output=True, text=True)
    except Exception:
        pass
    start2 = time.time()
    while time.time() - start2 < 10:
        try:
            os.kill(pid, 0)
            time.sleep(0.3)
        except OSError:
            return True
    return False


def safe_taskkill_by_name(name: str, log_file: Path):
    try:
        proc = subprocess.run(['taskkill', '/IM', name, '/F'], capture_output=True, text=True, timeout=12)
        out = ((proc.stdout or '') + ' ' + (proc.stderr or '')).strip()
        log_write(log_file, f'taskkill {name} -> code={proc.returncode} | {out[:500]}')
    except Exception as e:
        log_write(log_file, f'taskkill {name} -> exception: {e}')


def cleanup_blocking_processes(progress_cb, app_exe: Path, log_file: Path):
    progress_cb('Зачищаю хвости перед установкою...', 82,
                'Добиваю MCC, AHK, ShareX, java і signal-cli. Python тут не чіпаю, бо апдейтер сам на ньому сидить і не має вбити себе табуреткою.')
    targets_by_name = [
        app_exe.name,
        'AutoHotkey64.exe',
        'ShareX.exe',
        'java.exe',
        'signal-cli.exe',
    ]
    seen = set()
    for name in targets_by_name:
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        safe_taskkill_by_name(name, log_file)
    time.sleep(1.6)


def read_text_safe(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return ''


def monitor_inno_setup_log(proc: subprocess.Popen, setup_log: Path, progress_cb, stop_event: threading.Event):
    seen_lines = 0
    last_phase = None
    phase_map = [
        ('starting install', 88, 'Інсталятор реально стартував, не просто задумався.'),
        ('installing files', 90, 'Копіює файли нової версії. Тут уже не відмазується.'),
        ('creating directories', 91, 'Створює папки. Windows любить робити вигляд, що це важка філософія.'),
        ('replacing files', 92, 'Підміняє старі файли новими.'),
        ('registering', 93, 'Реєструє всяке системне сміття, бо без цього людям нудно жити.'),
        ('creating shortcuts', 94, 'Пиляє ярлики і фіналізує установку.'),
        ('saving uninstall information', 95, 'Пише дані деінсталяції, щоб потім було що ламати.'),
        ('finishing install', 96, 'Добиває останні кроки установки.'),
        ('installation process succeeded', 97, 'Інсталяція відпрацювала успішно, ще трошки.'),
    ]
    while not stop_event.is_set():
        if setup_log.exists():
            txt = read_text_safe(setup_log)
            lines = [x.strip() for x in txt.splitlines() if x.strip()]
            if len(lines) > seen_lines:
                new_lines = lines[seen_lines:]
                seen_lines = len(lines)
                for line in new_lines[-30:]:
                    ll = line.lower()
                    for marker, pct, detail in phase_map:
                        if marker in ll and last_phase != marker:
                            last_phase = marker
                            progress_cb('Встановлюю нову версію...', pct, detail)
                            break
        if proc.poll() is not None:
            break
        time.sleep(0.35)


def find_best_app_exe(app_exe: Path, install_dir: Path, log_file: Path) -> Path:
    candidates = []
    if app_exe.exists():
        candidates.append(app_exe)
    try:
        direct = install_dir / app_exe.name
        if direct.exists():
            candidates.append(direct)
    except Exception:
        pass
    for name in ['PITUSHNYA_MCC.exe', 'PITUSHNYA MCC.exe', app_exe.name]:
        try:
            for found in install_dir.rglob(name):
                if found.is_file():
                    candidates.append(found)
        except Exception:
            pass
    unique = []
    seen = set()
    for c in candidates:
        try:
            r = c.resolve()
        except Exception:
            r = c
        if str(r).lower() in seen:
            continue
        seen.add(str(r).lower())
        unique.append(c)

    if not unique:
        log_write(log_file, f'find_best_app_exe fallback to original: {app_exe}')
        return app_exe

    unique.sort(key=lambda p: (0 if p.parent == install_dir else 1, len(str(p))))
    chosen = unique[0]
    log_write(log_file, f'find_best_app_exe chosen: {chosen}')
    return chosen


def launch_updated_app(app_exe: Path, install_dir: Path, progress_cb, log_file: Path):
    chosen = find_best_app_exe(app_exe, install_dir, log_file)
    attempts = []

    if str(chosen).lower().endswith('.exe'):
        attempts.append((['cmd', '/c', 'start', '', str(chosen)], str(chosen.parent)))
        attempts.append(([str(chosen)], str(chosen.parent)))
    else:
        attempts.append(([str(chosen)], str(chosen.parent)))

    try:
        install_root_exe = install_dir / chosen.name
        if install_root_exe != chosen and install_root_exe.exists():
            attempts.append(([str(install_root_exe)], str(install_root_exe.parent)))
    except Exception:
        pass

    last_error = None
    progress_cb('Запускаю оновлену версію...', 98, 'Повертаю тобі MCC. Якщо Windows знов вирішить повикобенюватись, спробую ще кілька варіантів запуску.')
    for cmd, cwd in attempts:
        try:
            flags = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
            subprocess.Popen(cmd, cwd=cwd, creationflags=flags)
            log_write(log_file, f'restarted app with: {cmd} | cwd={cwd}')
            return True
        except Exception as e:
            last_error = e
            log_write(log_file, f'restart attempt failed: {cmd} | {e}')
            time.sleep(0.8)

    if last_error:
        raise RuntimeError(f'Нова версія встановилась, але не стартанула сама: {last_error}')
    raise RuntimeError('Нова версія встановилась, але не стартанула сама.')


def wait_for_relaunched_app(process_name: str, timeout_sec: float) -> bool:
    deadline = time.time() + max(0.5, float(timeout_sec or 0))
    wanted = str(process_name or "").strip().lower()
    if not wanted:
        return False
    while time.time() < deadline:
        try:
            proc = subprocess.run(
                ["tasklist", "/FI", f"IMAGENAME eq {process_name}"],
                capture_output=True,
                text=True,
                timeout=4,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if wanted in (proc.stdout or "").lower():
                return True
        except Exception:
            pass
        time.sleep(0.4)
    return False


def backup_user_state(install_dir: Path, backup_dir: Path, progress_cb, log_file: Path):
    backup_dir.mkdir(parents=True, exist_ok=True)
    targets = [
        install_dir / 'config.json',
        install_dir / 'data',
    ]
    copied = 0
    for src in targets:
        if not src.exists():
            continue
        dst = backup_dir / src.name
        try:
            if src.is_dir():
                if dst.exists():
                    shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            copied += 1
            log_write(log_file, f'backup copied: {src} -> {dst}')
        except Exception as e:
            log_write(log_file, f'backup failed for {src}: {e}')
    progress_cb('Зберігаю користувацькі налаштування...', 82,
                'Пакую config і data, щоб оновлення не відкусило твої шляхи, шаблони і службові файли.')
    return copied


def restore_user_state(install_dir: Path, backup_dir: Path, progress_cb, log_file: Path):
    if not backup_dir.exists():
        return
    restored = 0
    for name in ['config.json', 'data']:
        src = backup_dir / name
        if not src.exists():
            continue
        dst = install_dir / name
        try:
            if src.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
                for item in src.rglob('*'):
                    rel = item.relative_to(src)
                    target = dst / rel
                    if item.is_dir():
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(item, target)
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            restored += 1
            log_write(log_file, f'restore copied: {src} -> {dst}')
        except Exception as e:
            log_write(log_file, f'restore failed for {src}: {e}')
    progress_cb('Повертаю твої налаштування поверх нової версії...', 97,
                'Після установки повертаю config, data і робочі хвости, щоб не налаштовувати це все по новій.')
    try:
        shutil.rmtree(backup_dir, ignore_errors=True)
    except Exception as e:
        log_write(log_file, f'backup cleanup failed: {e}')
    return restored


def worker(args, app: UpdaterUI):
    log_file = Path(args.log_file)
    installer_path = Path(args.installer_path)
    app_exe = Path(args.app_exe)
    install_dir = Path(args.install_dir)
    setup_log = log_file.parent / 'inno_setup.log'
    backup_dir = log_file.parent / 'user_state_backup'

    def progress(msg, pct=None, detail=None):
        app.post('ui', msg, pct, detail)

    try:
        log_write(log_file, f'worker start | pid={os.getpid()} | exe={sys.executable}')
        progress('Чекаю закриття старої версії...', 3,
                 'MCC має вмерти культурно, щоб інсталятор міг переписати файли.')
        if not wait_process_exit(args.app_pid, 60, progress):
            raise RuntimeError('Стара версія так і не закрилась. Файли лишились заблокованими.')
        time.sleep(1.2)

        cleanup_temp_update_dir(installer_path.parent, installer_path, log_file)
        progress('Почистив тимчасову папку оновлення...', 6,
                 'Прибираю старі інсталяги і логи, щоб temp не виглядав як стихійне звалище.')

        if installer_path.exists():
            try:
                installer_path.unlink()
                log_write(log_file, f'old installer removed: {installer_path}')
            except Exception as e:
                log_write(log_file, f'old installer remove failed: {e}')

        progress('Завантажую оновлення...', 8,
                 'Тягну інсталяху з version.json. Якщо сервер не влаштує цирк, зараз побіжать відсотки.')
        ctype = download_with_google_drive_support(args.download_url, installer_path, progress)
        log_write(log_file, f'download done | ctype={ctype} | path={installer_path}')

        if not installer_path.exists():
            raise RuntimeError('Інсталятор не завантажився.')
        size = installer_path.stat().st_size
        log_write(log_file, f'installer size={size}')
        if size < 102400:
            if 'drive.google.com' in args.download_url:
                raise RuntimeError(f'Google Drive віддав не інсталятор, а свою сторінку/заглушку. Розмір файла: {size} байт.')
            raise RuntimeError(f'Завантажений файл підозріло малий: {size} байт. Схоже, прилетіла не інсталяга, а якась хєрня.')
        if 'html' in (ctype or '').lower():
            raise RuntimeError('Сервер повернув HTML замість інсталятора. Перевір лінк у version.json.')

        cleanup_blocking_processes(progress, app_exe, log_file)
        log_write(log_file, 'cleanup complete')
        backup_user_state(install_dir, backup_dir, progress, log_file)

        progress('Інсталятор уже на підході...', 84,
                 'Старі хвости прибрані. Зараз піде нормальна установка, не тільки завантаження.')
        progress('Встановлюю нову версію...', 86,
                 f'Запускаю інсталятор тихо. Повний лог Inno буде тут: {setup_log}')

        if setup_log.exists():
            try:
                setup_log.unlink()
                log_write(log_file, f'old setup log removed: {setup_log}')
            except Exception as e:
                log_write(log_file, f'old setup log remove failed: {e}')

        install_cmd = [
            str(installer_path),
            '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/SP-',
            '/CLOSEAPPLICATIONS', '/FORCECLOSEAPPLICATIONS', '/NOCANCEL',
            '/RELAUNCHAPP=1',
            f'/LOG={setup_log}',
            f'/DIR={install_dir}'
        ]
        log_write(log_file, 'RUN INSTALLER: ' + ' '.join(install_cmd))
        proc = subprocess.Popen(install_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stop_event = threading.Event()
        monitor = threading.Thread(target=monitor_inno_setup_log, args=(proc, setup_log, progress, stop_event), daemon=True)
        monitor.start()
        stdout, stderr = proc.communicate()
        stop_event.set()
        monitor.join(timeout=1.0)

        log_write(log_file, f'installer exit code={proc.returncode}')
        if stdout:
            log_write(log_file, stdout[:4000])
        if stderr:
            log_write(log_file, stderr[:4000])
        if proc.returncode != 0:
            extra = f'Інсталятор завершився з кодом {proc.returncode}.'
            if setup_log.exists():
                extra += f' Дивись лог: {setup_log}'
            raise RuntimeError(extra)

        restore_user_state(install_dir, backup_dir, progress, log_file)
        progress('Фіналізую інсталяцію...', 98, 'Inno відстрілявся. Перевіряю запуск нової версії після повернення налаштувань.')
        relaunched = wait_for_relaunched_app(app_exe.name, 10.0)
        if relaunched:
            log_write(log_file, f'app relaunched by installer: {app_exe.name}')
        else:
            log_write(log_file, f'app did not relaunch itself, fallback start: {app_exe.name}')
            launch_updated_app(app_exe, install_dir, progress, log_file)
        progress('Готово', 100, 'Оновлення завершено. MCC має вже піднятись без ручного стусана.')
        time.sleep(2.2)
        app.post('done')
    except Exception as e:
        log_write(log_file, f'ERROR: {e}')
        app.post('error', f'Не вдалося оновити PITUSHNYA MCC:\n{e}')
    finally:
        try:
            if installer_path.exists():
                installer_path.unlink()
                log_write(log_file, f'installer temp removed: {installer_path}')
        except Exception as e:
            log_write(log_file, f'installer temp remove failed: {e}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--app-pid', type=int, required=True)
    parser.add_argument('--download-url', required=True)
    parser.add_argument('--installer-path', required=True)
    parser.add_argument('--install-dir', required=True)
    parser.add_argument('--app-exe', required=True)
    parser.add_argument('--log-file', required=True)
    args = parser.parse_args()

    ui = UpdaterUI('Оновлення PITUSHNYA MCC', Path(args.log_file))
    ui.root.after(300, lambda: threading.Thread(target=worker, args=(args, ui), daemon=True).start())
    ui.run()


if __name__ == '__main__':
    main()
