import QtQuick
import QtQuick.Controls

ScrollBar {
    id: root

    property var themeObj
    property real uiScale: 1.0

    function c(name, fallback) {
        return root.themeObj && root.themeObj[name] ? root.themeObj[name] : fallback
    }

    policy: ScrollBar.AsNeeded
    interactive: true
    minimumSize: 0.08
    implicitWidth: Math.max(10, Math.round(12 * uiScale))
    implicitHeight: Math.max(10, Math.round(12 * uiScale))

    contentItem: Rectangle {
        implicitWidth: Math.max(10, Math.round(12 * root.uiScale))
        implicitHeight: Math.max(10, Math.round(12 * root.uiScale))
        radius: width / 2
        color: root.pressed
               ? root.c("accent", "#3f9cff")
               : (root.hovered ? root.c("accent2", "#53ea74") : root.c("cardBorder", "#1f4f72"))
        opacity: root.active ? 0.95 : 0.72
    }

    background: Rectangle {
        radius: width / 2
        color: root.themeObj && root.themeObj.name === "Hello Kitty"
               ? Qt.rgba(1.0, 0.92, 0.97, 0.55)
               : Qt.rgba(0, 0, 0, 0.18)
        border.color: root.c("inputBorder", "#2d5c82")
        border.width: 1
        opacity: root.active || root.hovered ? 1.0 : 0.72
    }
}